window.addEventListener('DOMContentLoaded', function () {
	var element = document.getElementById('disable');
	chrome.storage.sync.get('disabled', function(items) {
		if(items.disabled==undefined || items.disabled==false){
			element.innerHTML = 'Disable Extension';
		} else {
			element.innerHTML = 'Enable Extension';
		}
	});
	element.addEventListener('click', function () {
		chrome.storage.sync.get('disabled', function(items) {
			if(items.disabled==undefined || items.disabled==false){
				chrome.storage.sync.set({'disabled':true});
				element.innerHTML = 'Enable Extension';
			} else {
				chrome.storage.sync.set({'disabled':false});
				element.innerHTML = 'Disable Extension';
			}
		});
	}, false);
}, false);
