	
chrome.storage.sync.get('disabled', function(items) {
	// If user turns off extension in the popup, do not modify page.
	if(!items.disabled){	
		//Load extension, and retry upon failure.
		function loadExtension()
		{
			var script = document.createElement("script");
			script.type = "text/javascript";
			script.src = location.protocol + "//jimboy3100.github.io/extension/extension.js?ts="+Date.now();
			script.onerror = function(err)
			{
				setTimeout(loadExtension, 100);
			};
			document.head.appendChild(script);
		}

		//Only load on an actual web page.
		if(location.pathname.includes(".htm") || location.pathname.includes(".php") || !location.pathname.includes("."))
		{
			window.stop();
			document.documentElement.innerHTML = "";
			loadExtension();
		}
	}
});