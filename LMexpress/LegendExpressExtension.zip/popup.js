document.getElementById('website').addEventListener('click', () => {
    window.open('https://jimboy3100.github.io', '_blank');
});

document.getElementById('library').addEventListener('click', () => {
    window.open('https://github.com/jimboy3100/jimboy3100.github.io/', '_blank');
});

document.getElementById('donate').addEventListener('click', () => {
    window.open('https://www.buymeacoffee.com/legendmod', '_blank');
});
