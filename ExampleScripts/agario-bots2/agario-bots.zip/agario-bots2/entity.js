module.exports = class {
    constructor(){
        this.id = 0
        this.x = 0
        this.y = 0
        this.size = 0
        this.name = ''
        this.isVirus = false
        this.isPellet = false
    }
}
