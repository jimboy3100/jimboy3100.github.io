/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var m, aa = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    },
    n = function(a) {
        var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        return b ? b.call(a) : {
            next: aa(a)
        }
    },
    ba = "function" == typeof Object.create ? Object.create : function(a) {
        var b = function() {};
        b.prototype = a;
        return new b
    },
    ca;
if ("function" == typeof Object.setPrototypeOf) ca = Object.setPrototypeOf;
else {
    var da;
    a: {
        var ea = {
                a: !0
            },
            fa = {};
        try {
            fa.__proto__ = ea;
            da = fa.a;
            break a
        } catch (a) {}
        da = !1
    }
    ca = da ? function(a, b) {
        a.__proto__ = b;
        if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
        return a
    } : null
}
var ha = ca,
    ia = function(a, b) {
        a.prototype = ba(b.prototype);
        a.prototype.constructor = a;
        if (ha) ha(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.nb = b.prototype
    },
    ja = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    },
    ka = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window &&
            window, "object" == typeof self && self, "object" == typeof global && global
        ];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    },
    la = ka(this),
    ma = function(a, b) {
        if (b) {
            var c = la;
            a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                e in c || (c[e] = {});
                c = c[e]
            }
            a = a[a.length - 1];
            d = c[a];
            b = b(d);
            b != d && null != b && ja(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    };
ma("Symbol", function(a) {
    if (a) return a;
    var b = function(e, g) {
        this.Vb = e;
        ja(this, "description", {
            configurable: !0,
            writable: !0,
            value: g
        })
    };
    b.prototype.toString = function() {
        return this.Vb
    };
    var c = 0,
        d = function(e) {
            if (this instanceof d) throw new TypeError("Symbol is not a constructor");
            return new b("jscomp_symbol_" + (e || "") + "_" + c++, e)
        };
    return d
});
var na = function() {
        na = function() {};
        var a = Symbol.iterator;
        a || (a = Symbol.iterator = Symbol("Symbol.iterator"));
        "function" != typeof Array.prototype[a] && ja(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return oa(aa(this))
            }
        })
    },
    oa = function(a) {
        na();
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        };
        return a
    },
    q = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
ma("WeakMap", function(a) {
    function b() {}

    function c(k) {
        var l = typeof k;
        return "object" === l && null !== k || "function" === l
    }

    function d(k) {
        if (!q(k, g)) {
            var l = new b;
            ja(k, g, {
                value: l
            })
        }
    }

    function e(k) {
        var l = Object[k];
        l && (Object[k] = function(p) {
            if (p instanceof b) return p;
            d(p);
            return l(p)
        })
    }
    if (function() {
            if (!a || !Object.seal) return !1;
            try {
                var k = Object.seal({}),
                    l = Object.seal({}),
                    p = new a([
                        [k, 2],
                        [l, 3]
                    ]);
                if (2 != p.get(k) || 3 != p.get(l)) return !1;
                p.delete(k);
                p.set(l, 4);
                return !p.has(k) && 4 == p.get(l)
            } catch (r) {
                return !1
            }
        }()) return a;
    var g = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var f = 0,
        h = function(k) {
            this.na = (f += Math.random() + 1).toString();
            if (k) {
                k = n(k);
                for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
            }
        };
    h.prototype.set = function(k, l) {
        if (!c(k)) throw Error("Invalid WeakMap key");
        d(k);
        if (!q(k, g)) throw Error("WeakMap key fail: " + k);
        k[g][this.na] = l;
        return this
    };
    h.prototype.get = function(k) {
        return c(k) && q(k, g) ? k[g][this.na] : void 0
    };
    h.prototype.has = function(k) {
        return c(k) && q(k, g) && q(k[g],
            this.na)
    };
    h.prototype.delete = function(k) {
        return c(k) && q(k, g) && q(k[g], this.na) ? delete k[g][this.na] : !1
    };
    return h
});
ma("Map", function(a) {
    if (function() {
            if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
            try {
                var h = Object.seal({
                        x: 4
                    }),
                    k = new a(n([
                        [h, "s"]
                    ]));
                if ("s" != k.get(h) || 1 != k.size || k.get({
                        x: 4
                    }) || k.set({
                        x: 4
                    }, "t") != k || 2 != k.size) return !1;
                var l = k.entries(),
                    p = l.next();
                if (p.done || p.value[0] != h || "s" != p.value[1]) return !1;
                p = l.next();
                return p.done || 4 != p.value[0].x || "t" != p.value[1] || !l.next().done ? !1 : !0
            } catch (r) {
                return !1
            }
        }()) return a;
    na();
    var b = new WeakMap,
        c = function(h) {
            this.ka = {};
            this.R =
                g();
            this.size = 0;
            if (h) {
                h = n(h);
                for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
            }
        };
    c.prototype.set = function(h, k) {
        h = 0 === h ? 0 : h;
        var l = d(this, h);
        l.list || (l.list = this.ka[l.id] = []);
        l.v ? l.v.value = k : (l.v = {
            next: this.R,
            S: this.R.S,
            head: this.R,
            key: h,
            value: k
        }, l.list.push(l.v), this.R.S.next = l.v, this.R.S = l.v, this.size++);
        return this
    };
    c.prototype.delete = function(h) {
        h = d(this, h);
        return h.v && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this.ka[h.id], h.v.S.next = h.v.next, h.v.next.S = h.v.S, h.v.head = null,
            this.size--, !0) : !1
    };
    c.prototype.clear = function() {
        this.ka = {};
        this.R = this.R.S = g();
        this.size = 0
    };
    c.prototype.has = function(h) {
        return !!d(this, h).v
    };
    c.prototype.get = function(h) {
        return (h = d(this, h).v) && h.value
    };
    c.prototype.entries = function() {
        return e(this, function(h) {
            return [h.key, h.value]
        })
    };
    c.prototype.keys = function() {
        return e(this, function(h) {
            return h.key
        })
    };
    c.prototype.values = function() {
        return e(this, function(h) {
            return h.value
        })
    };
    c.prototype.forEach = function(h, k) {
        for (var l = this.entries(), p; !(p = l.next()).done;) p =
            p.value, h.call(k, p[1], p[0], this)
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function(h, k) {
            var l = k && typeof k;
            "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++f, b.set(k, l)) : l = "p_" + k;
            var p = h.ka[l];
            if (p && q(h.ka, l))
                for (h = 0; h < p.length; h++) {
                    var r = p[h];
                    if (k !== k && r.key !== r.key || k === r.key) return {
                        id: l,
                        list: p,
                        index: h,
                        v: r
                    }
                }
            return {
                id: l,
                list: p,
                index: -1,
                v: void 0
            }
        },
        e = function(h, k) {
            var l = h.R;
            return oa(function() {
                if (l) {
                    for (; l.head != h.R;) l = l.S;
                    for (; l.next != l.head;) return l = l.next, {
                        done: !1,
                        value: k(l)
                    };
                    l = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        },
        g = function() {
            var h = {};
            return h.S = h.next = h.head = h
        },
        f = 0;
    return c
});
ma("Set", function(a) {
    if (function() {
            if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
            try {
                var c = Object.seal({
                        x: 4
                    }),
                    d = new a(n([c]));
                if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                        x: 4
                    }) != d || 2 != d.size) return !1;
                var e = d.entries(),
                    g = e.next();
                if (g.done || g.value[0] != c || g.value[1] != c) return !1;
                g = e.next();
                return g.done || g.value[0] == c || 4 != g.value[0].x || g.value[1] != g.value[0] ? !1 : e.next().done
            } catch (f) {
                return !1
            }
        }()) return a;
    na();
    var b = function(c) {
        this.N = new Map;
        if (c) {
            c = n(c);
            for (var d; !(d = c.next()).done;) this.add(d.value)
        }
        this.size = this.N.size
    };
    b.prototype.add = function(c) {
        c = 0 === c ? 0 : c;
        this.N.set(c, c);
        this.size = this.N.size;
        return this
    };
    b.prototype.delete = function(c) {
        c = this.N.delete(c);
        this.size = this.N.size;
        return c
    };
    b.prototype.clear = function() {
        this.N.clear();
        this.size = 0
    };
    b.prototype.has = function(c) {
        return this.N.has(c)
    };
    b.prototype.entries = function() {
        return this.N.entries()
    };
    b.prototype.values = function() {
        return this.N.values()
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function(c, d) {
        var e = this;
        this.N.forEach(function(g) {
            return c.call(d, g, g, e)
        })
    };
    return b
});
ma("Promise", function(a) {
    function b() {
        this.T = null
    }

    function c(f) {
        return f instanceof e ? f : new e(function(h) {
            h(f)
        })
    }
    if (a) return a;
    b.prototype.yb = function(f) {
        if (null == this.T) {
            this.T = [];
            var h = this;
            this.zb(function() {
                h.sc()
            })
        }
        this.T.push(f)
    };
    var d = la.setTimeout;
    b.prototype.zb = function(f) {
        d(f, 0)
    };
    b.prototype.sc = function() {
        for (; this.T && this.T.length;) {
            var f = this.T;
            this.T = [];
            for (var h = 0; h < f.length; ++h) {
                var k = f[h];
                f[h] = null;
                try {
                    k()
                } catch (l) {
                    this.hc(l)
                }
            }
        }
        this.T = null
    };
    b.prototype.hc = function(f) {
        this.zb(function() {
            throw f;
        })
    };
    var e = function(f) {
        this.va = 0;
        this.ib = void 0;
        this.ea = [];
        var h = this.Qa();
        try {
            f(h.resolve, h.reject)
        } catch (k) {
            h.reject(k)
        }
    };
    e.prototype.Qa = function() {
        function f(l) {
            return function(p) {
                k || (k = !0, l.call(h, p))
            }
        }
        var h = this,
            k = !1;
        return {
            resolve: f(this.Xc),
            reject: f(this.hb)
        }
    };
    e.prototype.Xc = function(f) {
        if (f === this) this.hb(new TypeError("A Promise cannot resolve to itself"));
        else if (f instanceof e) this.ed(f);
        else {
            a: switch (typeof f) {
                case "object":
                    var h = null != f;
                    break a;
                case "function":
                    h = !0;
                    break a;
                default:
                    h = !1
            }
            h ?
            this.Wc(f) : this.Db(f)
        }
    };
    e.prototype.Wc = function(f) {
        var h = void 0;
        try {
            h = f.then
        } catch (k) {
            this.hb(k);
            return
        }
        "function" == typeof h ? this.fd(h, f) : this.Db(f)
    };
    e.prototype.hb = function(f) {
        this.Tb(2, f)
    };
    e.prototype.Db = function(f) {
        this.Tb(1, f)
    };
    e.prototype.Tb = function(f, h) {
        if (0 != this.va) throw Error("Cannot settle(" + f + ", " + h + "): Promise already settled in state" + this.va);
        this.va = f;
        this.ib = h;
        this.tc()
    };
    e.prototype.tc = function() {
        if (null != this.ea) {
            for (var f = 0; f < this.ea.length; ++f) g.yb(this.ea[f]);
            this.ea = null
        }
    };
    var g =
        new b;
    e.prototype.ed = function(f) {
        var h = this.Qa();
        f.ya(h.resolve, h.reject)
    };
    e.prototype.fd = function(f, h) {
        var k = this.Qa();
        try {
            f.call(h, k.resolve, k.reject)
        } catch (l) {
            k.reject(l)
        }
    };
    e.prototype.then = function(f, h) {
        function k(I, V) {
            return "function" == typeof I ? function(gb) {
                try {
                    l(I(gb))
                } catch (hb) {
                    p(hb)
                }
            } : V
        }
        var l, p, r = new e(function(I, V) {
            l = I;
            p = V
        });
        this.ya(k(f, l), k(h, p));
        return r
    };
    e.prototype.catch = function(f) {
        return this.then(void 0, f)
    };
    e.prototype.ya = function(f, h) {
        function k() {
            switch (l.va) {
                case 1:
                    f(l.ib);
                    break;
                case 2:
                    h(l.ib);
                    break;
                default:
                    throw Error("Unexpected state: " + l.va);
            }
        }
        var l = this;
        null == this.ea ? g.yb(k) : this.ea.push(k)
    };
    e.resolve = c;
    e.reject = function(f) {
        return new e(function(h, k) {
            k(f)
        })
    };
    e.race = function(f) {
        return new e(function(h, k) {
            for (var l = n(f), p = l.next(); !p.done; p = l.next()) c(p.value).ya(h, k)
        })
    };
    e.all = function(f) {
        var h = n(f),
            k = h.next();
        return k.done ? c([]) : new e(function(l, p) {
            function r(gb) {
                return function(hb) {
                    I[gb] = hb;
                    V--;
                    0 == V && l(I)
                }
            }
            var I = [],
                V = 0;
            do I.push(void 0), V++, c(k.value).ya(r(I.length -
                1), p), k = h.next(); while (!k.done)
        })
    };
    return e
});
var t = this || self,
    pa = function() {},
    qa = function(a) {
        var b = typeof a;
        if ("object" == b)
            if (a) {
                if (a instanceof Array) return "array";
                if (a instanceof Object) return b;
                var c = Object.prototype.toString.call(a);
                if ("[object Window]" == c) return "object";
                if ("[object Array]" == c || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("splice")) return "array";
                if ("[object Function]" == c || "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable &&
                    !a.propertyIsEnumerable("call")) return "function"
            } else return "null";
        else if ("function" == b && "undefined" == typeof a.call) return "object";
        return b
    },
    ra = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    },
    u = function(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.nb = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a
    };
var sa = function(a) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, sa);
    else {
        var b = Error().stack;
        b && (this.stack = b)
    }
    a && (this.message = String(a))
};
u(sa, Error);
sa.prototype.name = "CustomError";
var ta = function(a, b) {
    a = a.split("%s");
    for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
    sa.call(this, c + a[d])
};
u(ta, sa);
ta.prototype.name = "AssertionError";
var ua = function(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var g = d
        } else a && (e += ": " + a, g = b);
        throw new ta("" + e, g || []);
    },
    v = function(a, b, c) {
        a || ua("", null, b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    va = function(a, b) {
        throw new ta("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
    },
    wa = function(a, b, c) {
        "string" !== typeof a && ua("Expected string but got %s: %s.", [qa(a), a], b, Array.prototype.slice.call(arguments, 2))
    };
var xa = Array.prototype.indexOf ? function(a, b) {
    v(null != a.length);
    return Array.prototype.indexOf.call(a, b, void 0)
} : function(a, b) {
    if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
    for (var c = 0; c < a.length; c++)
        if (c in a && a[c] === b) return c;
    return -1
};
var ya = function(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
        var e = a.charCodeAt(d);
        255 < e && (b[c++] = e & 255, e >>= 8);
        b[c++] = e
    }
    return b
};
var za = function(a, b) {
    for (var c in a)
        if (b.call(void 0, a[c], c, a)) return !0;
    return !1
};
var Ca = function(a, b) {
    this.mb = a === Aa && b || "";
    this.ec = Ba
};
Ca.prototype.ca = !0;
Ca.prototype.ba = function() {
    return this.mb
};
Ca.prototype.toString = function() {
    return "Const{" + this.mb + "}"
};
var Da = function(a) {
        if (a instanceof Ca && a.constructor === Ca && a.ec === Ba) return a.mb;
        va("expected object of type Const, got '" + a + "'");
        return "type_error:Const"
    },
    Ba = {},
    Aa = {};
var Ea = String.prototype.trim ? function(a) {
        return a.trim()
    } : function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    },
    Ma = function(a, b) {
        if (b) a = a.replace(Fa, "&amp;").replace(Ga, "&lt;").replace(Ha, "&gt;").replace(Ia, "&quot;").replace(Ja, "&#39;").replace(Ka, "&#0;");
        else {
            if (!La.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(Fa, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(Ga, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Ha, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Ia, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Ja,
                "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Ka, "&#0;"))
        }
        return a
    },
    Fa = /&/g,
    Ga = /</g,
    Ha = />/g,
    Ia = /"/g,
    Ja = /'/g,
    Ka = /\x00/g,
    La = /[\x00&<>"']/,
    Na = function(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
var Qa = function(a, b) {
    this.fb = a === Oa && b || "";
    this.dc = Pa
};
m = Qa.prototype;
m.ca = !0;
m.ba = function() {
    return this.fb.toString()
};
m.Ib = !0;
m.Wa = function() {
    return 1
};
m.toString = function() {
    return "SafeUrl{" + this.fb + "}"
};
var Ra = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
    Pa = {},
    Oa = {};
var Sa = function() {
    this.eb = ""
};
Sa.prototype.ca = !0;
Sa.prototype.ba = function() {
    return this.eb
};
Sa.prototype.toString = function() {
    return "SafeStyle{" + this.eb + "}"
};
Sa.prototype.da = function(a) {
    this.eb = a;
    return this
};
(new Sa).da("");
var Ta = function() {
    this.cb = ""
};
Ta.prototype.ca = !0;
Ta.prototype.ba = function() {
    return this.cb
};
Ta.prototype.toString = function() {
    return "SafeStyleSheet{" + this.cb + "}"
};
Ta.prototype.da = function(a) {
    this.cb = a;
    return this
};
(new Ta).da("");
var w;
a: {
    var Ua = t.navigator;
    if (Ua) {
        var Va = Ua.userAgent;
        if (Va) {
            w = Va;
            break a
        }
    }
    w = ""
};
var x = function() {
    this.pa = "";
    this.cc = Wa;
    this.Ta = null
};
m = x.prototype;
m.Ib = !0;
m.Wa = function() {
    return this.Ta
};
m.ca = !0;
m.ba = function() {
    return this.pa.toString()
};
m.toString = function() {
    return "SafeHtml{" + this.pa + "}"
};
var Xa = function(a) {
        if (a instanceof x && a.constructor === x && a.cc === Wa) return a.pa;
        va("expected object of type SafeHtml, got '" + a + "' of type " + qa(a));
        return "type_error:SafeHtml"
    },
    Ya = function(a) {
        if (a instanceof x) return a;
        var b = "object" == typeof a,
            c = null;
        b && a.Ib && (c = a.Wa());
        a = Ma(b && a.ca ? a.ba() : String(a));
        return (new x).da(a, c)
    },
    Wa = {};
x.prototype.da = function(a, b) {
    this.pa = a;
    this.Ta = b;
    return this
};
var Za = new x;
Za.pa = t.trustedTypes && t.trustedTypes.emptyHTML ? t.trustedTypes.emptyHTML : "";
Za.Ta = 0;
var $a = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }(function() {
        if ("undefined" === typeof document) return !1;
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        if (!a.firstChild) return !1;
        b = a.firstChild.firstChild;
        a.innerHTML = Xa(Za);
        return !b.parentElement
    }),
    ab = function(a) {
        var b = document.location;
        a: {
            try {
                var c = b && b.ownerDocument,
                    d = c && (c.defaultView || c.parentWindow);
                d = d || t;
                if (d.Element && d.Location) {
                    var e =
                        d;
                    break a
                }
            } catch (f) {}
            e = null
        }
        if (e && (!b || !(b instanceof e.Location) && b instanceof e.Element)) {
            if (ra(b)) try {
                var g = b.constructor.displayName || b.constructor.name || Object.prototype.toString.call(b)
            } catch (f) {
                g = "<object could not be stringified>"
            } else g = void 0 === b ? "undefined" : null === b ? "null" : typeof b;
            va("Argument is not a Location (or a non-Element mock); got: %s", g)
        }
        a instanceof Qa || a instanceof Qa || (a = "object" == typeof a && a.ca ? a.ba() : String(a), v(Ra.test(a), "%s does not match the safe URL pattern", a) || (a =
            "about:invalid#zClosurez"), a = new Qa(Oa, a));
        a instanceof Qa && a.constructor === Qa && a.dc === Pa ? a = a.fb : (va("expected object of type SafeUrl, got '" + a + "' of type " + qa(a)), a = "type_error:SafeUrl");
        b.href = a
    };
var bb = function(a) {
    bb[" "](a);
    return a
};
bb[" "] = pa;
var cb = -1 != w.indexOf("Opera"),
    db = -1 != w.indexOf("Trident") || -1 != w.indexOf("MSIE"),
    eb = -1 != w.indexOf("Edge"),
    fb = -1 != w.indexOf("Gecko") && !(-1 != w.toLowerCase().indexOf("webkit") && -1 == w.indexOf("Edge")) && !(-1 != w.indexOf("Trident") || -1 != w.indexOf("MSIE")) && -1 == w.indexOf("Edge"),
    ib = -1 != w.toLowerCase().indexOf("webkit") && -1 == w.indexOf("Edge"),
    jb = function() {
        var a = t.document;
        return a ? a.documentMode : void 0
    },
    kb;
a: {
    var lb = "",
        mb = function() {
            var a = w;
            if (fb) return /rv:([^\);]+)(\)|;)/.exec(a);
            if (eb) return /Edge\/([\d\.]+)/.exec(a);
            if (db) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
            if (ib) return /WebKit\/(\S+)/.exec(a);
            if (cb) return /(?:Version)[ \/]?(\S+)/.exec(a)
        }();mb && (lb = mb ? mb[1] : "");
    if (db) {
        var nb = jb();
        if (null != nb && nb > parseFloat(lb)) {
            kb = String(nb);
            break a
        }
    }
    kb = lb
}
var ob = kb,
    pb = {},
    qb;
if (t.document && db) {
    var rb = jb();
    qb = rb ? rb : parseInt(ob, 10) || void 0
} else qb = void 0;
var sb = qb;
var tb = {},
    ub = null;
var vb = function() {
    this.u = -1
};
var wb = function(a, b, c) {
    this.u = -1;
    this.F = a;
    this.u = c || a.u || 16;
    this.Kb = Array(this.u);
    this.bb = Array(this.u);
    a = b;
    a.length > this.u && (this.F.update(a), a = this.F.digest(), this.F.reset());
    for (c = 0; c < this.u; c++) b = c < a.length ? a[c] : 0, this.Kb[c] = b ^ 92, this.bb[c] = b ^ 54;
    this.F.update(this.bb)
};
u(wb, vb);
wb.prototype.reset = function() {
    this.F.reset();
    this.F.update(this.bb)
};
wb.prototype.update = function(a, b) {
    this.F.update(a, b)
};
wb.prototype.digest = function() {
    var a = this.F.digest();
    this.F.reset();
    this.F.update(this.Kb);
    this.F.update(a);
    return this.F.digest()
};
var xb = function() {
    this.u = 64;
    this.o = Array(4);
    this.jc = Array(this.u);
    this.Fa = this.ja = 0;
    this.reset()
};
u(xb, vb);
xb.prototype.reset = function() {
    this.o[0] = 1732584193;
    this.o[1] = 4023233417;
    this.o[2] = 2562383102;
    this.o[3] = 271733878;
    this.Fa = this.ja = 0
};
var yb = function(a, b, c) {
    c || (c = 0);
    var d = Array(16);
    if ("string" === typeof b)
        for (var e = 0; 16 > e; ++e) d[e] = b.charCodeAt(c++) | b.charCodeAt(c++) << 8 | b.charCodeAt(c++) << 16 | b.charCodeAt(c++) << 24;
    else
        for (e = 0; 16 > e; ++e) d[e] = b[c++] | b[c++] << 8 | b[c++] << 16 | b[c++] << 24;
    b = a.o[0];
    c = a.o[1];
    e = a.o[2];
    var g = a.o[3];
    var f = b + (g ^ c & (e ^ g)) + d[0] + 3614090360 & 4294967295;
    b = c + (f << 7 & 4294967295 | f >>> 25);
    f = g + (e ^ b & (c ^ e)) + d[1] + 3905402710 & 4294967295;
    g = b + (f << 12 & 4294967295 | f >>> 20);
    f = e + (c ^ g & (b ^ c)) + d[2] + 606105819 & 4294967295;
    e = g + (f << 17 & 4294967295 | f >>>
        15);
    f = c + (b ^ e & (g ^ b)) + d[3] + 3250441966 & 4294967295;
    c = e + (f << 22 & 4294967295 | f >>> 10);
    f = b + (g ^ c & (e ^ g)) + d[4] + 4118548399 & 4294967295;
    b = c + (f << 7 & 4294967295 | f >>> 25);
    f = g + (e ^ b & (c ^ e)) + d[5] + 1200080426 & 4294967295;
    g = b + (f << 12 & 4294967295 | f >>> 20);
    f = e + (c ^ g & (b ^ c)) + d[6] + 2821735955 & 4294967295;
    e = g + (f << 17 & 4294967295 | f >>> 15);
    f = c + (b ^ e & (g ^ b)) + d[7] + 4249261313 & 4294967295;
    c = e + (f << 22 & 4294967295 | f >>> 10);
    f = b + (g ^ c & (e ^ g)) + d[8] + 1770035416 & 4294967295;
    b = c + (f << 7 & 4294967295 | f >>> 25);
    f = g + (e ^ b & (c ^ e)) + d[9] + 2336552879 & 4294967295;
    g = b + (f << 12 & 4294967295 |
        f >>> 20);
    f = e + (c ^ g & (b ^ c)) + d[10] + 4294925233 & 4294967295;
    e = g + (f << 17 & 4294967295 | f >>> 15);
    f = c + (b ^ e & (g ^ b)) + d[11] + 2304563134 & 4294967295;
    c = e + (f << 22 & 4294967295 | f >>> 10);
    f = b + (g ^ c & (e ^ g)) + d[12] + 1804603682 & 4294967295;
    b = c + (f << 7 & 4294967295 | f >>> 25);
    f = g + (e ^ b & (c ^ e)) + d[13] + 4254626195 & 4294967295;
    g = b + (f << 12 & 4294967295 | f >>> 20);
    f = e + (c ^ g & (b ^ c)) + d[14] + 2792965006 & 4294967295;
    e = g + (f << 17 & 4294967295 | f >>> 15);
    f = c + (b ^ e & (g ^ b)) + d[15] + 1236535329 & 4294967295;
    c = e + (f << 22 & 4294967295 | f >>> 10);
    f = b + (e ^ g & (c ^ e)) + d[1] + 4129170786 & 4294967295;
    b = c + (f <<
        5 & 4294967295 | f >>> 27);
    f = g + (c ^ e & (b ^ c)) + d[6] + 3225465664 & 4294967295;
    g = b + (f << 9 & 4294967295 | f >>> 23);
    f = e + (b ^ c & (g ^ b)) + d[11] + 643717713 & 4294967295;
    e = g + (f << 14 & 4294967295 | f >>> 18);
    f = c + (g ^ b & (e ^ g)) + d[0] + 3921069994 & 4294967295;
    c = e + (f << 20 & 4294967295 | f >>> 12);
    f = b + (e ^ g & (c ^ e)) + d[5] + 3593408605 & 4294967295;
    b = c + (f << 5 & 4294967295 | f >>> 27);
    f = g + (c ^ e & (b ^ c)) + d[10] + 38016083 & 4294967295;
    g = b + (f << 9 & 4294967295 | f >>> 23);
    f = e + (b ^ c & (g ^ b)) + d[15] + 3634488961 & 4294967295;
    e = g + (f << 14 & 4294967295 | f >>> 18);
    f = c + (g ^ b & (e ^ g)) + d[4] + 3889429448 & 4294967295;
    c =
        e + (f << 20 & 4294967295 | f >>> 12);
    f = b + (e ^ g & (c ^ e)) + d[9] + 568446438 & 4294967295;
    b = c + (f << 5 & 4294967295 | f >>> 27);
    f = g + (c ^ e & (b ^ c)) + d[14] + 3275163606 & 4294967295;
    g = b + (f << 9 & 4294967295 | f >>> 23);
    f = e + (b ^ c & (g ^ b)) + d[3] + 4107603335 & 4294967295;
    e = g + (f << 14 & 4294967295 | f >>> 18);
    f = c + (g ^ b & (e ^ g)) + d[8] + 1163531501 & 4294967295;
    c = e + (f << 20 & 4294967295 | f >>> 12);
    f = b + (e ^ g & (c ^ e)) + d[13] + 2850285829 & 4294967295;
    b = c + (f << 5 & 4294967295 | f >>> 27);
    f = g + (c ^ e & (b ^ c)) + d[2] + 4243563512 & 4294967295;
    g = b + (f << 9 & 4294967295 | f >>> 23);
    f = e + (b ^ c & (g ^ b)) + d[7] + 1735328473 & 4294967295;
    e = g + (f << 14 & 4294967295 | f >>> 18);
    f = c + (g ^ b & (e ^ g)) + d[12] + 2368359562 & 4294967295;
    c = e + (f << 20 & 4294967295 | f >>> 12);
    f = b + (c ^ e ^ g) + d[5] + 4294588738 & 4294967295;
    b = c + (f << 4 & 4294967295 | f >>> 28);
    f = g + (b ^ c ^ e) + d[8] + 2272392833 & 4294967295;
    g = b + (f << 11 & 4294967295 | f >>> 21);
    f = e + (g ^ b ^ c) + d[11] + 1839030562 & 4294967295;
    e = g + (f << 16 & 4294967295 | f >>> 16);
    f = c + (e ^ g ^ b) + d[14] + 4259657740 & 4294967295;
    c = e + (f << 23 & 4294967295 | f >>> 9);
    f = b + (c ^ e ^ g) + d[1] + 2763975236 & 4294967295;
    b = c + (f << 4 & 4294967295 | f >>> 28);
    f = g + (b ^ c ^ e) + d[4] + 1272893353 & 4294967295;
    g = b + (f << 11 & 4294967295 |
        f >>> 21);
    f = e + (g ^ b ^ c) + d[7] + 4139469664 & 4294967295;
    e = g + (f << 16 & 4294967295 | f >>> 16);
    f = c + (e ^ g ^ b) + d[10] + 3200236656 & 4294967295;
    c = e + (f << 23 & 4294967295 | f >>> 9);
    f = b + (c ^ e ^ g) + d[13] + 681279174 & 4294967295;
    b = c + (f << 4 & 4294967295 | f >>> 28);
    f = g + (b ^ c ^ e) + d[0] + 3936430074 & 4294967295;
    g = b + (f << 11 & 4294967295 | f >>> 21);
    f = e + (g ^ b ^ c) + d[3] + 3572445317 & 4294967295;
    e = g + (f << 16 & 4294967295 | f >>> 16);
    f = c + (e ^ g ^ b) + d[6] + 76029189 & 4294967295;
    c = e + (f << 23 & 4294967295 | f >>> 9);
    f = b + (c ^ e ^ g) + d[9] + 3654602809 & 4294967295;
    b = c + (f << 4 & 4294967295 | f >>> 28);
    f = g + (b ^ c ^ e) + d[12] +
        3873151461 & 4294967295;
    g = b + (f << 11 & 4294967295 | f >>> 21);
    f = e + (g ^ b ^ c) + d[15] + 530742520 & 4294967295;
    e = g + (f << 16 & 4294967295 | f >>> 16);
    f = c + (e ^ g ^ b) + d[2] + 3299628645 & 4294967295;
    c = e + (f << 23 & 4294967295 | f >>> 9);
    f = b + (e ^ (c | ~g)) + d[0] + 4096336452 & 4294967295;
    b = c + (f << 6 & 4294967295 | f >>> 26);
    f = g + (c ^ (b | ~e)) + d[7] + 1126891415 & 4294967295;
    g = b + (f << 10 & 4294967295 | f >>> 22);
    f = e + (b ^ (g | ~c)) + d[14] + 2878612391 & 4294967295;
    e = g + (f << 15 & 4294967295 | f >>> 17);
    f = c + (g ^ (e | ~b)) + d[5] + 4237533241 & 4294967295;
    c = e + (f << 21 & 4294967295 | f >>> 11);
    f = b + (e ^ (c | ~g)) + d[12] + 1700485571 &
        4294967295;
    b = c + (f << 6 & 4294967295 | f >>> 26);
    f = g + (c ^ (b | ~e)) + d[3] + 2399980690 & 4294967295;
    g = b + (f << 10 & 4294967295 | f >>> 22);
    f = e + (b ^ (g | ~c)) + d[10] + 4293915773 & 4294967295;
    e = g + (f << 15 & 4294967295 | f >>> 17);
    f = c + (g ^ (e | ~b)) + d[1] + 2240044497 & 4294967295;
    c = e + (f << 21 & 4294967295 | f >>> 11);
    f = b + (e ^ (c | ~g)) + d[8] + 1873313359 & 4294967295;
    b = c + (f << 6 & 4294967295 | f >>> 26);
    f = g + (c ^ (b | ~e)) + d[15] + 4264355552 & 4294967295;
    g = b + (f << 10 & 4294967295 | f >>> 22);
    f = e + (b ^ (g | ~c)) + d[6] + 2734768916 & 4294967295;
    e = g + (f << 15 & 4294967295 | f >>> 17);
    f = c + (g ^ (e | ~b)) + d[13] + 1309151649 &
        4294967295;
    c = e + (f << 21 & 4294967295 | f >>> 11);
    f = b + (e ^ (c | ~g)) + d[4] + 4149444226 & 4294967295;
    b = c + (f << 6 & 4294967295 | f >>> 26);
    f = g + (c ^ (b | ~e)) + d[11] + 3174756917 & 4294967295;
    g = b + (f << 10 & 4294967295 | f >>> 22);
    f = e + (b ^ (g | ~c)) + d[2] + 718787259 & 4294967295;
    e = g + (f << 15 & 4294967295 | f >>> 17);
    f = c + (g ^ (e | ~b)) + d[9] + 3951481745 & 4294967295;
    a.o[0] = a.o[0] + b & 4294967295;
    a.o[1] = a.o[1] + (e + (f << 21 & 4294967295 | f >>> 11)) & 4294967295;
    a.o[2] = a.o[2] + e & 4294967295;
    a.o[3] = a.o[3] + g & 4294967295
};
xb.prototype.update = function(a, b) {
    void 0 === b && (b = a.length);
    for (var c = b - this.u, d = this.jc, e = this.ja, g = 0; g < b;) {
        if (0 == e)
            for (; g <= c;) yb(this, a, g), g += this.u;
        if ("string" === typeof a)
            for (; g < b;) {
                if (d[e++] = a.charCodeAt(g++), e == this.u) {
                    yb(this, d);
                    e = 0;
                    break
                }
            } else
                for (; g < b;)
                    if (d[e++] = a[g++], e == this.u) {
                        yb(this, d);
                        e = 0;
                        break
                    }
    }
    this.ja = e;
    this.Fa += b
};
xb.prototype.digest = function() {
    var a = Array((56 > this.ja ? this.u : 2 * this.u) - this.ja);
    a[0] = 128;
    for (var b = 1; b < a.length - 8; ++b) a[b] = 0;
    var c = 8 * this.Fa;
    for (b = a.length - 8; b < a.length; ++b) a[b] = c & 255, c /= 256;
    this.update(a);
    a = Array(16);
    for (b = c = 0; 4 > b; ++b)
        for (var d = 0; 32 > d; d += 8) a[c++] = this.o[b] >>> d & 255;
    return a
};
var zb = function(a, b, c) {
        for (; 0 <= (b = a.indexOf("hl", b)) && b < c;) {
            var d = a.charCodeAt(b - 1);
            if (38 == d || 63 == d)
                if (d = a.charCodeAt(b + 2), !d || 61 == d || 38 == d || 35 == d) return b;
            b += 3
        }
        return -1
    },
    Ab = /#|$/,
    Bb = /[?&]($|#)/,
    Cb = function(a) {
        var b = document.location.href;
        for (var c = b.search(Ab), d = 0, e, g = []; 0 <= (e = zb(b, d, c));) g.push(b.substring(d, e)), d = Math.min(b.indexOf("&", e) + 1 || c, c);
        g.push(b.substr(d));
        b = g.join("").replace(Bb, "$1");
        (a = "hl" + (null != a ? "=" + encodeURIComponent(String(a)) : "")) ? (c = b.indexOf("#"), 0 > c && (c = b.length), d = b.indexOf("?"),
            0 > d || d > c ? (d = c, e = "") : e = b.substring(d + 1, c), b = [b.substr(0, d), e, b.substr(c)], c = b[1], b[1] = a ? c ? c + "&" + a : a : c, a = b[0] + (b[1] ? "?" + b[1] : "") + b[2]) : a = b;
        return a
    };
var Db = {
        qd: !0
    },
    y = function() {
        throw Error("Do not instantiate directly");
    };
y.prototype.Pa = null;
y.prototype.toString = function() {
    return this.content
};
var Eb = function() {
    y.call(this)
};
u(Eb, y);
Eb.prototype.Y = Db;
var Fb = function(a) {
    var b = null != a && a.Y === Db;
    b && v(a.constructor === Eb);
    return b
};
var Gb = Object.freeze || function(a) {
    return a
};
var Hb = function(a) {
        if (null != a) switch (a.Pa) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    },
    Jb = function(a) {
        return Fb(a) ? a : a instanceof x ? z(Xa(a).toString(), a.Wa()) : z(Ib(String(a)), Hb(a))
    },
    z = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            void 0 !== d && (c.Pa = d);
            return c
        }
    }(Eb),
    A = function(a) {
        return Fb(a) ? String(String(a.content).replace(Kb, "").replace(Lb, "&lt;")).replace(Mb, Nb) : Ib(a)
    },
    Ob = function(a, b) {
        a || (a = b instanceof Function ? b.displayName ||
            b.name || "unknown type name" : b instanceof Object ? b.constructor.displayName || b.constructor.name || Object.prototype.toString.call(b) : null === b ? "null" : typeof b, va("expected param origin of type string, but got " + a + "."));
        return b
    },
    Ib = function(a) {
        a = String(a);
        return a = Ma(a, void 0)
    },
    Pb = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\x0B": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    },
    Nb = function(a) {
        return Pb[a]
    },
    Mb = /[\x00\x22\x27\x3c\x3e]/g,
    Kb = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
    Lb = /</g;
var Qb = function(a) {
    var b = document;
    return "string" === typeof a ? b.getElementById(a) : a
};
var Sb = function(a, b, c, d) {
        c = b(c || Rb, d);
        if (ra(c))
            if (c instanceof y) {
                if (c.Y !== Db) throw Error("Sanitized content was not of kind HTML.");
                b = c.toString();
                c = c.Pa;
                d = new Ca(Aa, "Soy SanitizedContent of kind HTML produces SafeHtml-contract-compliant value.");
                wa(Da(d), "must provide justification");
                v(!/^[\s\xa0]*$/.test(Da(d)), "must provide non-empty justification");
                b = (new x).da(b, c || null)
            } else va("Soy template output is unsafe for use as HTML: " + c), b = Ya("zSoyz");
        else b = Ya(String(c));
        a = v(a);
        if ($a())
            for (; a.lastChild;) a.removeChild(a.lastChild);
        a.innerHTML = Xa(b)
    },
    Rb = {};
var Tb = function() {
        var a = '<div class="' + A("dialog-header") + '"><div class="' + A("google-icon") + '">';
        var b = z('<svg class="' + A("icon") + '" xmlns="https://www.w3.org/2000/svg" viewBox="0 0 48 48"><path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/><path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/><path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z"/><path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/><path fill="none" d="M2 2h44v44H2z"/></svg>');
        return z(a + b + "</div><p>Continue with Google</p></div>")
    },
    Ub = function(a) {
        var b = z,
            c = '<div class="' + A("dialog-footer") + '">',
            d = a.Ra;
        a = a.languages;
        var e = '<div id="language_selector" class="' + A("language-selector") + '"><div class="' + A("language-selected") + '">';
        if ((d instanceof y ? d.content : d) && (a instanceof y ? a.content : a)) {
            for (var g = "", f = a.length, h = 0; h < f; h++) {
                var k = a[h],
                    l = k.code;
                g += (l && d && l.Ic && d.Ic ? l.Y !== d.Y ? 0 : l.toString() === d.toString() : l instanceof y && d instanceof y ? l.Y != d.Y ? 0 : l.toString() == d.toString() :
                    l == d) ? "" + k.displayName : ""
            }
            e += "<div>" + Jb(g) + "</div>"
        }
        e += '<div class="' + A("chevron") + '"></div></div><div id="language_list" class="' + A("language-list") + '">';
        if (a)
            for (d = a.length, g = 0; g < d; g++) f = a[g], e += '<div class="' + A("language-option") + '" data-languagecode="' + A(f.code) + '">' + Jb(f.displayName) + "</div>";
        a = z(e + "</div></div>");
        c += a;
        a = '<ul class="' + A("footer-menu") + '"><li class="' + A("menu-item") + '"><a class="' + A("menu-content") + '" href="#">';
        a = a + 'Help</a></li><li class="' + (A("menu-item") + '"><a class="' + A("menu-content") +
            '" href="#">');
        a = a + 'Privacy</a></li><li class="' + (A("menu-item") + '"><a class="' + A("menu-content") + '" href="#">');
        a = z(a + "Terms</a></li></ul>");
        return b(c + a + "</div>")
    };
var Vb = function(a, b) {
    var c = Ob("string" === typeof a.origin, a.origin);
    a = z;
    var d = '<div class="' + A("dialog-container dialog-modal") + '"><div class="' + A("dialog inflated-dialog") + '"><div class="' + A("dialog-body") + '">' + Tb() + '<div class="' + A("dialog-content") + '">';
    var e = '<h1 class="' + A("title") + '">';
    e = z(e + "You'll need to give Safari permission to continue</h1>");
    d += e;
    e = Ob("string" === typeof c, c);
    c = '<div class="' + A("consent-form") + '"><p class="' + A("consent-text") + '">';
    e = "In order to continue with your Google Account, Safari will ask if it's ok for Google to use cookies on " +
        (Jb(e) + ".");
    c = z(c + e + "</p></div>");
    d += c;
    c = '<div class="' + A("button-group") + '"><div class="' + A("button button-cancel") + '" id="confirm_no">';
    c = c + 'Cancel</div><div class="' + (A("button button-confirm") + '" id="confirm_yes">');
    c = z(c + "Continue</div></div>");
    return a(d + c + "</div></div>" + Ub(b) + "</div></div>")
};
Vb.jd = "oauth2.gsi.soy.itp.newgrant.dialog";
var Wb = function(a, b) {
    var c = Ob("string" === typeof a.origin, a.origin);
    a = z;
    var d = '<div class="' + A("dialog-container dialog-modal") + '"><div class="' + A("dialog") + '"><div class="' + A("dialog-body") + '">' + Tb() + '<div class="' + A("dialog-content") + '">',
        e = Ob("string" === typeof c, c);
    c = '<h1 class="' + A("title") + '">';
    e = "Do you still want Safari to let Google use cookies on " + (Jb(e) + "?");
    c = z(c + e + "</h1>");
    d += c;
    c = '<div class="' + A("button-group button-group-high") + '"><div class="' + A("button button-cancel") + '" id="confirm_no">';
    c = c + 'No thanks</div><div class="' + (A("button button-confirm") + '" id="confirm_yes">');
    c = z(c + "Yes</div></div>");
    return a(d + c + "</div></div>" + Ub(b) + "</div></div>")
};
Wb.jd = "oauth2.gsi.soy.itp.regrant.dialog";
var Xb;
(Xb = !db) || (Xb = 9 <= Number(sb));
var Yb = Xb,
    Zb;
if (Zb = db) {
    var $b;
    if (Object.prototype.hasOwnProperty.call(pb, "9")) $b = pb["9"];
    else {
        for (var ac = 0, bc = Ea(String(ob)).split("."), cc = Ea("9").split("."), dc = Math.max(bc.length, cc.length), ec = 0; 0 == ac && ec < dc; ec++) {
            var fc = bc[ec] || "",
                gc = cc[ec] || "";
            do {
                var hc = /(\d*)(\D*)(.*)/.exec(fc) || ["", "", "", ""],
                    ic = /(\d*)(\D*)(.*)/.exec(gc) || ["", "", "", ""];
                if (0 == hc[0].length && 0 == ic[0].length) break;
                ac = Na(0 == hc[1].length ? 0 : parseInt(hc[1], 10), 0 == ic[1].length ? 0 : parseInt(ic[1], 10)) || Na(0 == hc[2].length, 0 == ic[2].length) || Na(hc[2], ic[2]);
                fc = hc[3];
                gc = ic[3]
            } while (0 == ac)
        }
        $b = pb["9"] = 0 <= ac
    }
    Zb = !$b
}
var jc = Zb,
    kc = function() {
        if (!t.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            t.addEventListener("test", pa, b), t.removeEventListener("test", pa, b)
        } catch (c) {}
        return a
    }();
var lc = function(a, b) {
    this.type = a;
    this.currentTarget = this.target = b;
    this.defaultPrevented = this.gb = !1
};
lc.prototype.stopPropagation = function() {
    this.gb = !0
};
lc.prototype.preventDefault = function() {
    this.defaultPrevented = !0
};
var mc;
mc = ib ? "webkitTransitionEnd" : cb ? "otransitionend" : "transitionend";
var B = function(a, b) {
    lc.call(this, a ? a.type : "");
    this.relatedTarget = this.currentTarget = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
    this.key = "";
    this.charCode = this.keyCode = 0;
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.ma = null;
    a && this.H(a, b)
};
u(B, lc);
var nc = Gb({
    2: "touch",
    3: "pen",
    4: "mouse"
});
B.prototype.H = function(a, b) {
    var c = this.type = a.type,
        d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    if (b = a.relatedTarget) {
        if (fb) {
            a: {
                try {
                    bb(b.nodeName);
                    var e = !0;
                    break a
                } catch (g) {}
                e = !1
            }
            e || (b = null)
        }
    } else "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
    this.relatedTarget = b;
    d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX, this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY =
        d.screenY || 0) : (this.offsetX = ib || void 0 !== a.offsetX ? a.offsetX : a.layerX, this.offsetY = ib || void 0 !== a.offsetY ? a.offsetY : a.layerY, this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
    this.button = a.button;
    this.keyCode = a.keyCode || 0;
    this.key = a.key || "";
    this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId =
        a.pointerId || 0;
    this.pointerType = "string" === typeof a.pointerType ? a.pointerType : nc[a.pointerType] || "";
    this.state = a.state;
    this.ma = a;
    a.defaultPrevented && this.preventDefault()
};
B.prototype.stopPropagation = function() {
    B.nb.stopPropagation.call(this);
    this.ma.stopPropagation ? this.ma.stopPropagation() : this.ma.cancelBubble = !0
};
B.prototype.preventDefault = function() {
    B.nb.preventDefault.call(this);
    var a = this.ma;
    if (a.preventDefault) a.preventDefault();
    else if (a.returnValue = !1, jc) try {
        if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) a.keyCode = -1
    } catch (b) {}
};
var oc = "closure_listenable_" + (1E6 * Math.random() | 0),
    pc = 0;
var qc = function(a, b, c, d, e) {
        this.listener = a;
        this.Ca = null;
        this.src = b;
        this.type = c;
        this.capture = !!d;
        this.i = e;
        this.key = ++pc;
        this.ta = this.Oa = !1
    },
    rc = function(a) {
        a.ta = !0;
        a.listener = null;
        a.Ca = null;
        a.src = null;
        a.i = null
    };
var sc = function(a) {
    this.src = a;
    this.I = {};
    this.Ga = 0
};
sc.prototype.add = function(a, b, c, d, e) {
    var g = a.toString();
    a = this.I[g];
    a || (a = this.I[g] = [], this.Ga++);
    var f = tc(a, b, d, e); - 1 < f ? (b = a[f], c || (b.Oa = !1)) : (b = new qc(b, this.src, g, !!d, e), b.Oa = c, a.push(b));
    return b
};
sc.prototype.remove = function(a, b, c, d) {
    a = a.toString();
    if (!(a in this.I)) return !1;
    var e = this.I[a];
    b = tc(e, b, c, d);
    return -1 < b ? (rc(e[b]), v(null != e.length), Array.prototype.splice.call(e, b, 1), 0 == e.length && (delete this.I[a], this.Ga--), !0) : !1
};
sc.prototype.hasListener = function(a, b) {
    var c = void 0 !== a,
        d = c ? a.toString() : "",
        e = void 0 !== b;
    return za(this.I, function(g) {
        for (var f = 0; f < g.length; ++f)
            if (!(c && g[f].type != d || e && g[f].capture != b)) return !0;
        return !1
    })
};
var tc = function(a, b, c, d) {
    for (var e = 0; e < a.length; ++e) {
        var g = a[e];
        if (!g.ta && g.listener == b && g.capture == !!c && g.i == d) return e
    }
    return -1
};
var uc = "closure_lm_" + (1E6 * Math.random() | 0),
    vc = {},
    wc = 0,
    yc = function(a, b, c, d, e) {
        if (d && d.once) return xc(a, b, c, d, e);
        if (Array.isArray(b)) {
            for (var g = 0; g < b.length; g++) yc(a, b[g], c, d, e);
            return null
        }
        c = zc(c);
        return a && a[oc] ? C(a, b, c, ra(d) ? !!d.capture : !!d) : Ac(a, b, c, !1, d, e)
    },
    Ac = function(a, b, c, d, e, g) {
        if (!b) throw Error("Invalid event type");
        var f = ra(e) ? !!e.capture : !!e,
            h = Bc(a);
        h || (a[uc] = h = new sc(a));
        c = h.add(b, c, d, f, g);
        if (c.Ca) return c;
        d = Cc();
        c.Ca = d;
        d.src = a;
        d.listener = c;
        if (a.addEventListener) kc || (e = f), void 0 === e && (e = !1), a.addEventListener(b.toString(), d, e);
        else if (a.attachEvent) a.attachEvent(Dc(b.toString()), d);
        else if (a.addListener && a.removeListener) v("change" === b, "MediaQueryList only has a change event"), a.addListener(d);
        else throw Error("addEventListener and attachEvent are unavailable.");
        wc++;
        return c
    },
    Cc = function() {
        var a = Ec,
            b = Yb ? function(c) {
                return a.call(b.src, b.listener, c)
            } : function(c) {
                c = a.call(b.src, b.listener, c);
                if (!c) return c
            };
        return b
    },
    xc = function(a, b, c, d, e) {
        if (Array.isArray(b)) {
            for (var g = 0; g < b.length; g++) xc(a,
                b[g], c, d, e);
            return null
        }
        c = zc(c);
        return a && a[oc] ? a.pd(b, c, ra(d) ? !!d.capture : !!d, e) : Ac(a, b, c, !0, d, e)
    },
    Fc = function(a) {
        if ("number" !== typeof a && a && !a.ta) {
            var b = a.src;
            if (b && b[oc]) b.rd(a);
            else {
                var c = a.type,
                    d = a.Ca;
                b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Dc(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                wc--;
                if (c = Bc(b)) {
                    d = a.type;
                    if (d in c.I) {
                        var e = c.I[d],
                            g = xa(e, a),
                            f;
                        if (f = 0 <= g) v(null != e.length), Array.prototype.splice.call(e, g, 1);
                        f && (rc(a), 0 == c.I[d].length &&
                            (delete c.I[d], c.Ga--))
                    }
                    0 == c.Ga && (c.src = null, b[uc] = null)
                } else rc(a)
            }
        }
    },
    Dc = function(a) {
        return a in vc ? vc[a] : vc[a] = "on" + a
    },
    Hc = function(a, b, c, d) {
        var e = !0;
        if (a = Bc(a))
            if (b = a.I[b.toString()])
                for (b = b.concat(), a = 0; a < b.length; a++) {
                    var g = b[a];
                    g && g.capture == c && !g.ta && (g = Gc(g, d), e = e && !1 !== g)
                }
        return e
    },
    Gc = function(a, b) {
        var c = a.listener,
            d = a.i || a.src;
        a.Oa && Fc(a);
        return c.call(d, b)
    },
    Ec = function(a, b) {
        if (a.ta) return !0;
        if (!Yb) {
            if (!b) a: {
                b = ["window", "event"];
                for (var c = t, d = 0; d < b.length; d++)
                    if (c = c[b[d]], null == c) {
                        b = null;
                        break a
                    }
                b = c
            }
            d = b;
            b = new B(d, this);
            c = !0;
            if (!(0 > d.keyCode || void 0 != d.returnValue)) {
                a: {
                    var e = !1;
                    if (0 == d.keyCode) try {
                        d.keyCode = -1;
                        break a
                    } catch (f) {
                        e = !0
                    }
                    if (e || void 0 == d.returnValue) d.returnValue = !0
                }
                d = [];
                for (e = b.currentTarget; e; e = e.parentNode) d.push(e);a = a.type;
                for (e = d.length - 1; !b.gb && 0 <= e; e--) {
                    b.currentTarget = d[e];
                    var g = Hc(d[e], a, !0, b);
                    c = c && g
                }
                for (e = 0; !b.gb && e < d.length; e++) b.currentTarget = d[e],
                g = Hc(d[e], a, !1, b),
                c = c && g
            }
            return c
        }
        return Gc(a, new B(b, this))
    },
    Bc = function(a) {
        a = a[uc];
        return a instanceof sc ? a : null
    },
    Ic = "__closure_events_fn_" + (1E9 * Math.random() >>> 0),
    zc = function(a) {
        v(a, "Listener can not be null.");
        if ("function" == qa(a)) return a;
        v(a.handleEvent, "An object listener must have handleEvent method.");
        a[Ic] || (a[Ic] = function(b) {
            return a.handleEvent(b)
        });
        return a[Ic]
    };
var Jc = function() {
        this.Aa = new Set
    },
    C = function(a, b, c, d) {
        b = yc(b, c, d);
        a.Aa.add(b);
        return b
    },
    Kc = function(a, b) {
        Fc(b);
        a.Aa.delete(b)
    };
var Lc = function() {
    this.Aa = new Set;
    this.Bb = null
};
ia(Lc, Jc);
var Mc = function(a, b) {
    if (a.Bb) throw Error("Component already rendered.");
    a.Bb = b
};
var Nc = function() {
    this.Aa = new Set;
    this.V = this.kb = this.Da = null;
    this.Qb = !1
};
ia(Nc, Jc);
Nc.prototype.register = function(a, b) {
    var c = this;
    if (this.Qb) throw Error("LanguageSelectorModel is already registered.");
    this.Qb = !0;
    this.kb = a;
    this.V = b;
    this.Nb = C(this, this.kb, "click", function() {
        return Oc(c)
    })
};
var Oc = function(a) {
        a.V.style.visibility = "visible";
        a.V.style.opacity = 1;
        Kc(a, a.Nb);
        a.Kc = C(a, document, "mouseup", function(b) {
            return Pc(a, b)
        })
    },
    Pc = function(a, b) {
        a.Da = b.target.getAttribute("data-languagecode");
        if (null != a.Da || b.target != a.V) Kc(a, a.Kc), a.Jc = C(a, a.V, mc, function() {
            return Qc(a)
        }), a.V.style.opacity = 0
    },
    Qc = function(a) {
        Kc(a, a.Jc);
        a.V.style.visibility = "hidden";
        a.Nb = C(a, a.kb, "click", function() {
            return Oc(a)
        });
        if (null != a.Da) {
            var b = Cb(a.Da);
            ab(b)
        }
    };
var Rc = function(a) {
    var b = a.origin,
        c = a.Ra;
    a = a.languages;
    Lc.call(this);
    this.h = b;
    this.Cb = c;
    this.Ob = a
};
ia(Rc, Lc);
Rc.prototype.Uc = function(a, b, c) {
    Mc(this, a);
    Sb(a, Vb, {
        origin: this.h
    }, {
        Ra: this.Cb,
        languages: this.Ob
    });
    a = Qb("confirm_yes");
    C(this, a, "click", function() {
        (void 0 == document.hasStorageAccess ? Promise.resolve() : document.requestStorageAccess()).then(function() {
            return b()
        }, function() {
            return c()
        })
    });
    a = Qb("confirm_no");
    C(this, a, "click", function() {
        return c()
    });
    Sc(this)
};
Rc.prototype.Vc = function(a, b, c) {
    Mc(this, a);
    Sb(a, Wb, {
        origin: this.h
    }, {
        Ra: this.Cb,
        languages: this.Ob
    });
    a = Qb("confirm_yes");
    C(this, a, "click", function() {
        return b()
    });
    a = Qb("confirm_no");
    C(this, a, "click", function() {
        return c()
    });
    Sc(this)
};
var Sc = function(a) {
    void 0 == a.Mb && (a.Mb = new Nc);
    var b = Qb("language_selector"),
        c = Qb("language_list");
    a.Mb.register(b, c)
};
var Tc, Uc, Vc = void 0,
    D = function(a) {
        try {
            return t.JSON.parse.call(t.JSON, a)
        } catch (b) {
            return !1
        }
    },
    E = function(a) {
        return Object.prototype.toString.call(a)
    },
    Wc = E(0),
    Xc = E(new Date(0)),
    Yc = E(!0),
    Zc = E(""),
    $c = E({}),
    ad = E([]),
    bd = function(a, b) {
        if (b)
            for (var c = 0, d = b.length; c < d; ++c)
                if (a === b[c]) throw new TypeError("Converting circular structure to JSON");
        d = typeof a;
        if ("undefined" !== d) {
            c = Array.prototype.slice.call(b || [], 0);
            c[c.length] = a;
            b = [];
            var e = E(a);
            if (null != a && "function" === typeof a.toJSON && (Object.prototype.hasOwnProperty.call(a,
                    "toJSON") || (e !== ad || a.constructor !== Array && a.constructor !== Object) && (e !== $c || a.constructor !== Array && a.constructor !== Object) && e !== Zc && e !== Wc && e !== Yc && e !== Xc)) return bd(a.toJSON.call(a), c);
            if (null == a) b[b.length] = "null";
            else if (e === Wc) a = Number(a), isNaN(a) || isNaN(a - a) ? a = "null" : -0 === a && 0 > 1 / a && (a = "-0"), b[b.length] = String(a);
            else if (e === Yc) b[b.length] = String(!!Number(a));
            else {
                if (e === Xc) return bd(a.toISOString.call(a), c);
                if (e === ad && E(a.length) === Wc) {
                    b[b.length] = "[";
                    var g = 0;
                    for (d = Number(a.length) >> 0; g < d; ++g) g &&
                        (b[b.length] = ","), b[b.length] = bd(a[g], c) || "null";
                    b[b.length] = "]"
                } else if (e == Zc && E(a.length) === Wc) {
                    b[b.length] = '"';
                    g = 0;
                    for (c = Number(a.length) >> 0; g < c; ++g) d = String.prototype.charAt.call(a, g), e = String.prototype.charCodeAt.call(a, g), b[b.length] = "\b" === d ? "\\b" : "\f" === d ? "\\f" : "\n" === d ? "\\n" : "\r" === d ? "\\r" : "\t" === d ? "\\t" : "\\" === d || '"' === d ? "\\" + d : 31 >= e ? "\\u" + (e + 65536).toString(16).substr(1) : 32 <= e && 65535 >= e ? d : "\ufffd";
                    b[b.length] = '"'
                } else if ("object" === d) {
                    b[b.length] = "{";
                    d = 0;
                    for (g in a) Object.prototype.hasOwnProperty.call(a,
                        g) && (e = bd(a[g], c), void 0 !== e && (d++ && (b[b.length] = ","), b[b.length] = bd(g), b[b.length] = ":", b[b.length] = e));
                    b[b.length] = "}"
                } else return
            }
            return b.join("")
        }
    },
    cd = /[\0-\x07\x0b\x0e-\x1f]/,
    dd = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*[\0-\x1f]/,
    ed = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\[^\\\/"bfnrtu]/,
    fd = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\u([0-9a-fA-F]{0,3}[^0-9a-fA-F])/,
    gd = /"([^\0-\x1f\\"]|\\[\\\/"bfnrt]|\\u[0-9a-fA-F]{4})*"/g,
    hd = /-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?/g,
    id = /[ \t\n\r]+/g,
    jd = /[^"]:/,
    kd = /""/g,
    ld = /true|false|null/g,
    md = /00/,
    nd = /[\{]([^0\}]|0[^:])/,
    od = /(^|\[)[,:]|[,:](\]|\}|[,:]|$)/,
    pd = /[^\[,:][\[\{]/,
    qd = /^(\{|\}|\[|\]|,|:|0)+/,
    rd = /\u2028/g,
    sd = /\u2029/g,
    td = function(a) {
        a = String(a);
        if (cd.test(a) || dd.test(a) || ed.test(a) || fd.test(a)) return !1;
        var b = a.replace(gd, '""');
        b = b.replace(hd, "0");
        b = b.replace(id, "");
        if (jd.test(b)) return !1;
        b = b.replace(kd, "0");
        b = b.replace(ld, "0");
        if (md.test(b) || nd.test(b) || od.test(b) || pd.test(b) || !b || (b = b.replace(qd, ""))) return !1;
        a = a.replace(rd, "\\u2028").replace(sd,
            "\\u2029");
        b = void 0;
        try {
            b = Vc ? [D(a)] : eval("(function (var_args) {\n  return Array.prototype.slice.call(arguments, 0);\n})(\n" + a + "\n)")
        } catch (c) {
            return !1
        }
        return b && 1 === b.length ? b[0] : !1
    },
    ud = function() {
        var a = ((t.document || {}).scripts || []).length;
        if ((void 0 === Tc || void 0 === Vc || Uc !== a) && -1 !== Uc) {
            Tc = Vc = !1;
            Uc = -1;
            try {
                try {
                    Vc = !!t.JSON && '{"a":[3,true,"1970-01-01T00:00:00.000Z"]}' === t.JSON.stringify.call(t.JSON, {
                        a: [3, !0, new Date(0)],
                        c: function() {}
                    }) && !0 === D("true") && 3 === D('[{"a":3}]')[0].a
                } catch (b) {}
                Tc = Vc && !D("[00]") &&
                    !D('"\u0007"') && !D('"\\0"') && !D('"\\v"')
            } finally {
                Uc = a
            }
        }
    },
    vd = !Date.prototype.toISOString || "function" !== typeof Date.prototype.toISOString || "1970-01-01T00:00:00.000Z" !== (new Date(0)).toISOString(),
    wd = function() {
        var a = Date.prototype.getUTCFullYear.call(this);
        return [0 > a ? "-" + String(1E6 - a).substr(1) : 9999 >= a ? String(1E4 + a).substr(1) : "+" + String(1E6 + a).substr(1), "-", String(101 + Date.prototype.getUTCMonth.call(this)).substr(1), "-", String(100 + Date.prototype.getUTCDate.call(this)).substr(1), "T", String(100 + Date.prototype.getUTCHours.call(this)).substr(1),
            ":", String(100 + Date.prototype.getUTCMinutes.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCSeconds.call(this)).substr(1), ".", String(1E3 + Date.prototype.getUTCMilliseconds.call(this)).substr(1), "Z"
        ].join("")
    };
Date.prototype.toISOString = vd ? wd : Date.prototype.toISOString;
var xd, yd = !1,
    F = function(a) {
        try {
            yd && window.console && window.console.log && window.console.log(a)
        } catch (b) {}
    },
    G = function(a, b) {
        if (!a) return -1;
        if (a.indexOf) return a.indexOf(b, void 0);
        for (var c = 0, d = a.length; c < d; c++)
            if (a[c] === b) return c;
        return -1
    },
    H = function(a, b) {
        function c() {}
        if (!a) throw "Child class cannot be empty.";
        if (!b) throw "Parent class cannot be empty.";
        c.prototype = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a
    },
    zd = function(a) {
        return "[object Function]" === Object.prototype.toString.call(a)
    },
    Ad =
    function(a) {
        var b = [],
            c;
        for (c in a)
            if (a.hasOwnProperty(c)) {
                var d = a[c];
                if (null === d || void 0 === d) d = "";
                b.push(encodeURIComponent(c) + "=" + encodeURIComponent(d))
            }
        return b.join("&")
    },
    Bd = function(a) {
        var b = window.location.hash;
        a = new RegExp("[&#]" + a + "=([^&]*)");
        b = decodeURIComponent(b);
        b = a.exec(b);
        return null == b ? "" : b[1].replace(/\+/g, " ")
    },
    Cd = function(a, b, c) {
        if (a.addEventListener) a.addEventListener(b, c, !1);
        else if (a.attachEvent) a.attachEvent("on" + b, c);
        else throw "Add event handler for " + b + " failed.";
    },
    Dd = function(a,
        b) {
        a = (a || "").split(" ");
        b = (b || "").split(" ");
        for (var c = 0; c < b.length; c++)
            if (b[c] && 0 > G(a, b[c])) return !1;
        return !0
    },
    Ed = function() {
        if ("undefined" != typeof xd) return xd;
        a: {
            try {
                if (window.localStorage) {
                    var a = window.localStorage;
                    break a
                }
            } catch (b) {}
            a = void 0
        }
        if (!a) return xd = !1;
        try {
            a.setItem("test", "test"), a.removeItem("test"), xd = !0
        } catch (b) {
            xd = !1
        }
        return xd
    },
    Fd = function() {
        var a = navigator.userAgent.toLowerCase();
        return -1 != a.indexOf("msie") && 8 == parseInt(a.split("msie")[1], 10)
    },
    Gd = function() {
        return Object.hasOwnProperty.call(window,
            "ActiveXObject") && !window.ActiveXObject
    },
    Hd = function() {
        var a = navigator.userAgent.toLowerCase();
        return 0 > a.indexOf("edge/") && (-1 < a.indexOf("chrome/") || -1 < a.indexOf("crios/"))
    },
    Id = function() {
        var a = navigator.userAgent,
            b;
        if (b = !!a && -1 != a.indexOf("CriOS")) b = -1, (a = a.match(/CriOS\/(\d+)/)) && a[1] && (b = parseInt(a[1], 10) || -1), b = 48 > b;
        return b
    },
    Jd = function() {
        var a = navigator.userAgent.toLowerCase();
        return -1 < a.indexOf("safari/") && 0 > a.indexOf("chrome/") && 0 > a.indexOf("crios/") && 0 > a.indexOf("android")
    },
    J = window.JSON,
    K = function(a) {
        this.qb = a || [];
        this.G = {}
    };
K.prototype.addEventListener = function(a, b) {
    if (!(0 <= G(this.qb, a))) throw "Unrecognized event type: " + a;
    if (!zd(b)) throw "The listener for event '" + a + "' is not a function.";
    this.G[a] || (this.G[a] = []);
    0 > G(this.G[a], b) && this.G[a].push(b)
};
K.prototype.removeEventListener = function(a, b) {
    if (!(0 <= G(this.qb, a))) throw "Unrecognized event type: " + a;
    zd(b) && this.G[a] && this.G[a].length && (b = G(this.G[a], b), 0 <= b && this.G[a].splice(b, 1))
};
K.prototype.dispatchEvent = function(a) {
    var b = a.type;
    if (!(b && 0 <= G(this.qb, b))) throw "Failed to dispatch unrecognized event type: " + b;
    if (this.G[b] && this.G[b].length)
        for (var c = 0, d = this.G[b].length; c < d; c++) this.G[b][c](a)
};
J = {
    parse: function(a) {
        a = "[" + String(a) + "]"; - 1 === Uc ? a = !1 : (ud(), a = (Tc ? D : td)(a));
        if (!1 === a || 1 !== a.length) throw new SyntaxError("JSON parsing failed.");
        return a[0]
    },
    stringify: function(a) {
        -1 !== Uc ? (ud(), a = Vc ? t.JSON.stringify.call(t.JSON, a) : bd(a)) : a = void 0;
        return a
    }
};
var L = {
        nd: {}
    },
    M = M || {};
M.Na = "APISID";
M.Ma = "SAPISID";
M.Ka = "__Secure-3PAPISID";
M.M = function(a) {
    a = encodeURIComponent(a);
    var b = M.Eb();
    if (b && (a = b.match("(^|;) ?" + a + "=([^;]*)(;|$)")) && 2 < a.length && (a = a[2])) return decodeURIComponent(a)
};
M.Ua = function(a) {
    var b;
    (a = M.M(a)) && (b = String(Kd(a)));
    return b
};
M.Eb = function() {
    return document.cookie
};
M.bd = function(a) {
    document.cookie = a
};
L = L || {};
L.Gc = function(a, b, c) {
    if (!0 === L.Za) a();
    else {
        var d = 2,
            e = function() {
                d--;
                0 == d && (L.Za = !0, a())
            },
            g = function(f) {
                b(f)
            };
        switch (Ld()) {
            case "sessionStorage":
                L.wa = new Md;
                L.wa.H(e, g);
                if (c) try {
                    L.wa.clear()
                } catch (f) {}
                break;
            case "inMemoryStorage":
                L.wa = new Nd;
                L.wa.H(e, g);
                break;
            default:
                c = Error("Unsupported storage type: " + Ld());
                b(c);
                return
        }
        switch (Od()) {
            case "localStorage":
                L.fa = new Pd;
                L.fa.H(e, g);
                break;
            case "indexedDb":
                L.fa = new Qd;
                L.fa.H(e, g);
                break;
            case "cookieStorage":
                L.fa = new Rd;
                L.fa.H(e, g);
                break;
            default:
                c = Error("Unsupported storage type: " +
                    Od()), b(c)
        }
    }
};
L.Gb = function() {
    if (!L.Za) throw Error("Storages are not initialized yet!");
    return L.fa
};
L.Dc = function() {
    if (!L.Za) throw Error("Storages are not initialized yet!");
    return L.wa
};
var Pd = function() {};
m = Pd.prototype;
m.H = function(a, b) {
    Ed() ? (this.la = window.localStorage, a()) : b && b(Error("localStorage is not available in the current environment."))
};
m.getItem = function(a, b) {
    b(this.la.getItem(a))
};
m.setItem = function(a, b, c) {
    void 0 === b || null === b ? this.la.removeItem(a) : this.la.setItem(a, b);
    c && c()
};
m.removeItem = function(a, b) {
    this.la.removeItem(a);
    b && b()
};
m.clear = function(a) {
    this.la.clear();
    a && a()
};
var Qd = function() {};
m = Qd.prototype;
m.H = function(a, b) {
    var c = this,
        d = window.indexedDB.open("oauth");
    d.onsuccess = function(e) {
        c.za = e.target.result;
        a()
    };
    d.onupgradeneeded = function(e) {
        e.target.result.createObjectStore("oauth")
    };
    d.onerror = function(e) {
        e = e.target.errorCode;
        b && b(Error("IndexedDb initialization failed: " + e))
    }
};
m.getItem = function(a, b) {
    var c = this.za.transaction("oauth", "readwrite").objectStore("oauth").get(a);
    c.onsuccess = function() {
        b(c.result)
    }
};
m.setItem = function(a, b, c) {
    var d = this.za.transaction("oauth", "readwrite").objectStore("oauth");
    if (void 0 === b || null === b) d["delete"](a);
    else d.put(b, a);
    d.transaction.oncomplete = function() {
        c && c()
    }
};
m.removeItem = function(a, b) {
    var c = this.za.transaction("oauth", "readwrite").objectStore("oauth");
    c["delete"](a);
    c.transaction.oncomplete = function() {
        b && b()
    }
};
m.clear = function(a) {
    var b = this.za.transaction("oauth", "readwrite").objectStore("oauth");
    b.clear();
    b.transaction.oncomplete = function() {
        a && a()
    }
};
var Nd = function() {};
m = Nd.prototype;
m.H = function(a) {
    this.Ea = {};
    a()
};
m.getItem = function(a, b) {
    b(this.Ea[a] || null)
};
m.setItem = function(a, b, c) {
    this.Ea[a] = b;
    c && c()
};
m.removeItem = function(a, b) {
    delete this.Ea[a];
    b && b()
};
m.clear = function(a) {
    this.Ea = {};
    a && a()
};
var Md = function() {};
m = Md.prototype;
m.H = function(a, b) {
    Ed() ? (this.ua = window.sessionStorage, a()) : b && b(Error("sessionStorage is not available in the current environment."))
};
m.getItem = function(a, b) {
    b(this.ua.getItem(a))
};
m.setItem = function(a, b, c) {
    void 0 === b || null === b ? this.ua.removeItem(a) : this.ua.setItem(a, b);
    c && c()
};
m.removeItem = function(a, b) {
    this.ua.removeItem(a);
    b && b()
};
m.clear = function(a) {
    this.ua.clear();
    a && a()
};
var Rd = function() {
    this.Nc = N.Xb
};
m = Rd.prototype;
m.H = function(a, b) {
    navigator.cookieEnabled ? a() : b && b(Error("Cookies are not enabled in current environment."))
};
m.getItem = function(a, b) {
    for (var c = null, d = Sd(a), e = 0; e < d.length; e++)
        if (d[e].key == a) {
            c = d[e].value;
            break
        }
    b(c)
};
m.setItem = function(a, b, c) {
    var d = N.Va(a.split(N.m)[0]);
    if (d) {
        var e = Td(d);
        b = {
            key: a,
            value: b
        };
        for (var g = 0; g < e.length; g++)
            if (e[g].key == a) {
                e.splice(g, 1);
                break
            }
        e.push(b);
        Ud(this, d, e)
    }
    c && c()
};
m.removeItem = function(a, b) {
    for (var c = Sd(a), d = 0; d < c.length; d++)
        if (c[d].key == a) {
            c.splice(d, 1);
            break
        }(a = N.Va(a.split(N.m)[0])) && Ud(this, a, c);
    b && b()
};
m.clear = function(a) {
    L.mc();
    a && a()
};
var Sd = function(a) {
        return (a = N.Va(a.split(N.m)[0])) ? Td(a) : []
    },
    Td = function(a) {
        a = M.M(a);
        return L.oc(a || null)
    },
    Ud = function(a, b, c) {
        var d = L.rc(c);
        d.length > a.Nc ? (c.splice(0, 1), 0 < c.length ? Ud(a, b, c) : F("Failed to write Cookie based cache due to the big size.")) : L.Sb(b, d)
    };
L.nc = function(a) {
    try {
        return atob(a)
    } catch (b) {
        return a
    }
};
L.qc = function(a) {
    try {
        return btoa(a)
    } catch (b) {
        return a
    }
};
L.oc = function(a) {
    if (!a) return [];
    a = L.nc(a);
    try {
        return J.parse(a).items || []
    } catch (b) {
        return F("Error while parsing items from cookie:" + b.message), []
    }
};
L.rc = function(a) {
    return L.qc(J.stringify({
        items: a
    }))
};
L.Sb = function(a, b) {
    var c = window.location.hostname,
        d = window.location.pathname;
    a = encodeURIComponent(a) + "=" + encodeURIComponent(b) + "; domain=" + c + ";"; - 1 != navigator.userAgent.toLowerCase().indexOf("msie") || Gd() || (a += " path=" + d + ";");
    "https:" == window.location.protocol && (a += " secure;");
    M.bd(a)
};
L.mc = function() {
    var a = N.Ia,
        b = M.Eb();
    if (b) {
        b = b.replace(/((?:^|\s*;)[^=]+)(?=;|$)|^\s*|\s*(?:=[^;]*)?(?:\1|$)/g, "").split(/\s*(?:=[^;]*)?;\s*/);
        for (var c = 0; c < b.length; c++) {
            var d = decodeURIComponent(b[c]);
            0 == d.indexOf(a) && L.Sb(d, "")
        }
    }
};
var Vd = function(a) {
    this.Lb = a;
    K.call(this, ["storageValueChanged"])
};
H(Vd, K);
var Wd = function(a, b) {
    L.Gb().getItem(a.Lb, b)
};
Vd.prototype.addListener = function(a) {
    this.addEventListener("storageValueChanged", a)
};
Vd.prototype.start = function() {
    var a = this;
    Wd(this, function(b) {
        a.Rc = b;
        a.Pb = 0;
        a.$a = window.setInterval(Xd(a), 200)
    })
};
Vd.prototype.stop = function() {
    void 0 !== this.$a && (clearInterval(this.$a), this.$a = void 0)
};
var Xd = function(a) {
        return function() {
            a.Pb++;
            Wd(a, function(b) {
                b != a.Rc ? (a.dispatchEvent({
                    type: "storageValueChanged",
                    key: a.Lb,
                    newValue: b
                }), a.stop()) : 1500 <= a.Pb && a.stop()
            })
        }
    },
    Kd = function(a) {
        var b = 0,
            c;
        if (a) {
            var d = 0;
            for (c = a.length; d < c; d++) {
                var e = a.charCodeAt(d);
                b = (b << 5) - b + e;
                b |= 0
            }
        }
        return b
    },
    O = function(a) {
        return !!a && 0 <= a.indexOf(N.m)
    },
    Yd = function(a, b) {
        if (!a && !b) return !0;
        if (!a || !b) return !1;
        a = a.extraQueryParams;
        b = b.extraQueryParams;
        if (!a && !b) return !0;
        if (!a || !b || Object.keys && Object.keys(a).length != Object.keys(b).length) return !1;
        for (var c in a)
            if (a[c] !== b[c]) return !1;
        if (!Object.keys)
            for (c in b)
                if (a[c] !== b[c]) return !1;
        return !0
    },
    N = N || {};
N.Wb = 100;
N.xb = "/oauth2/sessionstate/action/updateState";
N.rb = "/oauth2/sessionstate/action/checkOrigin";
N.vb = "/oauth2/permission/action/refresh";
N.ub = "/oauth2/permission/action/code";
N.La = "/oauth2/permission/action/listSessions";
N.bc = "/o/oauth2/revoke";
N.xa = "response_type login_hint client_id origin scope ss_domain authuser hd enable_serial_consent include_granted_scopes nonce".split(" ");
N.Zb = "login_hint client_id origin scope ss_domain authuser hd enable_serial_consent include_granted_scopes".split(" ");
N.$b = "client_id origin scope ss_domain authuser hd enable_serial_consent".split(" ");
N.m = "::";
N.Ja = "_ss_";
N.tb = "_tr_";
N.ia = "oauth2_ss";
N.sb = "oauth2_cs";
N.wb = "oauth2_tr";
N.Yb = "oauth2_is";
N.ha = "oauth2_ar";
N.Ia = "oauth2c_";
N.Xb = 1500;
N.md = function() {
    var a = {
            Ja: 1,
            tb: 2,
            ia: 3,
            sb: 4,
            wb: 5,
            ha: 6
        },
        b;
    for (b in a)
        if (a = N[b], !a || 0 <= a.indexOf(N.m)) throw "Invalid value for 'oauth2.spi." + b + "'.";
};
N.md();
N.ac = 512;
N.fc = function(a) {
    var b;
    (b = void 0 === a.hint) || (b = a.hint, b = ("" === b ? !0 : b ? "string" == typeof b || "object" == typeof b && b.constructor === String : !1) && a.hint.length <= N.ac);
    return !a.id && b
};
N.Bc = function() {
    var a = M.M("https:" == window.location.protocol ? M.Ma : M.Na);
    a || (a = M.M(M.Ka));
    return a
};
N.Va = function(a) {
    switch (a) {
        case N.ha:
            return N.Ia + N.ha;
        case N.ia:
            return N.Ia + N.ia;
        default:
            return null
    }
};
var Od = function() {
        return (Jd() || Hd()) && !Ed() || Gd() && !window.indexedDB ? "cookieStorage" : Gd() ? "indexedDb" : "localStorage"
    },
    Ld = function() {
        return !Jd() && !Hd() || Ed() ? "sessionStorage" : "inMemoryStorage"
    };
M = M || {};
M.Ha = "cookieValueChanged";
var Zd = function(a) {
    this.Hc = a;
    K.call(this, [M.Ha])
};
H(Zd, K);
Zd.prototype.M = function() {
    return M.M(M.Na) || M.M(M.Ma) || M.M(M.Ka)
};
var P = function() {
    return M.Ua(M.Na) || M.Ua(M.Ma) || M.Ua(M.Ka)
};
Zd.prototype.addListener = function(a) {
    this.addEventListener(M.Ha, a)
};
var be = function(a) {
        $d(a);
        a.Ba = a.M();
        a.ob = window.setInterval(ae(a), a.Hc);
        F("IDP Session Cookie monitor is started.")
    },
    $d = function(a) {
        void 0 !== a.ob && (window.clearInterval(a.ob), a.ob = void 0, F("IDP Session Cookie monitor is stoped."))
    },
    ae = function(a) {
        return function() {
            var b = a.M();
            if (a.Ba != b) {
                var c = {
                    type: M.Ha,
                    newHash: b && Kd(b),
                    oldHash: a.Ba && Kd(a.Ba)
                };
                a.Ba = b;
                a.dispatchEvent(c)
            }
        }
    },
    ce = function(a) {
        this.h = a;
        this.Ub = void 0
    },
    de = function(a, b, c) {
        var d = N.bc,
            e = new XMLHttpRequest;
        e.onreadystatechange = function() {
            if (4 ==
                e.readyState && 200 == e.status) {
                var h;
                e.responseText && (h = J.parse(e.responseText));
                c(h)
            } else 4 == e.readyState && 0 == e.status ? c({
                error: "network_error"
            }) : 4 == e.readyState && c({
                error: "server_error",
                error_subtype: e.responseText
            })
        };
        e.open("POST", d, !0);
        e.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        var g = "xsrfToken=";
        a.Ub && (g += a.Ub);
        if (b)
            for (var f in b) f && b[f] && (g += "&" + f + "=" + encodeURIComponent(b[f]));
        F("Call " + d + " with postData: " + g);
        e.send(g)
    },
    ee = function(a, b, c, d) {
        var e = new XMLHttpRequest;
        e.onreadystatechange = function() {
            if (4 == e.readyState && 200 == e.status) {
                var f;
                if (e.responseText && (f = J.parse(e.responseText))) {
                    var h = f;
                    if (h.error) {
                        h.thrown_by = "server";
                        try {
                            h.error = h.error.toLowerCase()
                        } catch (k) {}
                    }
                }
                d(f)
            } else 4 == e.readyState && 0 == e.status ? d({
                error: "network_error"
            }) : 4 == e.readyState && d({
                error: "server_error",
                error_subtype: e.responseText
            })
        };
        if (b = Ad(b)) a += 0 > a.indexOf("?") ? "?" : "&", a += b;
        e.open("GET", a, !0);
        e.setRequestHeader("X-Requested-With", "XmlHttpRequest");
        if (c)
            for (var g in c)
                if (c.hasOwnProperty(g)) {
                    b =
                        c[g];
                    if (null === b || void 0 === b) b = "";
                    e.setRequestHeader(g, b)
                }
        F("Call " + a + " with Get method.");
        e.send()
    },
    fe = function(a, b, c) {
        ee(N.rb, {
            origin: a.h,
            client_id: b
        }, null, c)
    },
    ge = function(a, b, c) {
        b && b.length ? ee(N.xb, {
            login_hint: b.join(" "),
            origin: a.h
        }, null, c) : c({
            activeHints: {}
        })
    },
    ie = function(a, b, c) {
        b.origin = a.h;
        0 > N.xa.indexOf("enable_serial_consent") && N.xa.push("enable_serial_consent");
        b = he(b, N.xa);
        ee(N.vb, b, null, c)
    },
    je = function(a, b, c) {
        b.origin = a.h;
        b = he(b, N.Zb);
        ee(N.ub, b, null, c)
    },
    ke = function(a, b, c) {
        b.origin = a.h;
        b = he(b, N.$b);
        ee(N.La, b, null, c)
    },
    le = function(a, b, c) {
        de(a, {
            token: b
        }, c)
    },
    he = function(a, b) {
        for (var c = {}, d = 0; d < b.length; d++) {
            var e = b[d];
            void 0 !== a[e] && null !== a[e] && (c[e] = a[e])
        }
        return c
    };
L = L || {};
var me = function() {};
me.prototype.D = function() {
    return !1
};
var ne = {};
L.Tc = function() {
    var a = new oe;
    if (!a) throw "policy cannot be empty.";
    if (L.Jb("DEFAULT")) throw "Duplicate policyName [DEFAULT].";
    ne.DEFAULT = a
};
L.Jb = function(a) {
    for (var b in ne)
        if (a == b) return !0;
    return !1
};
L.Fb = function(a) {
    return a && L.Jb(a) ? a : "DEFAULT"
};
L.yc = function(a) {
    return ne[L.Fb(a)]
};
L.D = function(a, b, c, d) {
    return L.yc(d).D(a, b, c)
};
L.od = function(a, b, c, d) {
    if (!L.D(a, b, c, d)) throw "permission_error";
};
var pe = function() {};
H(pe, me);
pe.prototype.D = function(a, b, c) {
    a = c ? this.Xa(a) : this.Ya(a);
    return 0 <= G(a, b)
};
pe.prototype.Ya = function(a) {
    var b = [];
    if (a && (b.push(a), "http://" == a.substring(0, 7) || "https://" == a.substring(0, 8))) {
        var c = document.createElement("a");
        c.href = a;
        a != c.protocol + "//" + c.hostname && b.push(c.protocol + "//" + c.hostname);
        "https:" == c.protocol && b.push("http://" + c.hostname)
    }
    return b
};
pe.prototype.Xa = function(a) {
    var b = [];
    if (a) {
        b.push(a);
        var c = document.createElement("a");
        c.href = a;
        if ("http:" == c.protocol || "https:" == c.protocol)
            for (a = c.hostname.split("."); 1 < a.length;) b.push(c.protocol + "//" + a.join(".")), "https:" == c.protocol && b.push("http://" + a.join(".")), a.shift()
    }
    return b
};
var oe = function() {};
H(oe, me);
oe.prototype.D = function(a, b, c) {
    a = c ? this.Xa(a) : this.Ya(a);
    return 0 <= G(a, b)
};
oe.prototype.Ya = function(a) {
    var b = [];
    if (a && (b.push(a), "https://" == a.substring(0, 8))) {
        var c = document.createElement("a");
        c.href = a;
        "" != c.port && 0 != c.port && 443 != c.port || b.push("http://" + c.hostname)
    }
    return b
};
oe.prototype.Xa = function(a) {
    var b = [];
    if (a) {
        var c = document.createElement("a");
        c.href = a;
        if ("https:" == c.protocol && ("" == c.port || 0 == c.port || 443 == c.port) || "http:" == c.protocol && ("" == c.port || 0 == c.port || 80 == c.port))
            for (a = c.hostname.split("."); 1 < a.length;) b.push(c.protocol + "//" + a.join(".")), "https:" == c.protocol && b.push("http://" + a.join(".")), a.shift();
        else b.push(a)
    }
    return b
};
L.Tc();
var Q = function() {};
Q.prototype.ab = function() {
    return !0
};
var R = function(a) {
    return a.ab() ? L.Dc() : L.Gb()
};
Q.prototype.l = function() {
    throw Error("unimplemented abstract method");
};
Q.prototype.aa = function() {
    throw Error("unimplemented abstract method");
};
Q.prototype.A = function() {
    throw Error("unimplemented abstract method");
};
Q.prototype.B = function() {
    throw Error("unimplemented abstract method");
};
var S = function() {};
H(S, Q);
S.prototype.A = function(a, b, c) {
    var d = this,
        e = this.l(a);
    R(this).getItem(e, function(g) {
        if (g) try {
            var f = J.parse(g);
            if (f.cookieHash != b) {
                R(d).removeItem(e, function() {
                    c(void 0)
                });
                return
            }
            var h = f && f.cachedValue
        } catch (k) {}
        c(h)
    })
};
S.prototype.B = function(a, b, c, d) {
    a = this.l(a);
    void 0 === b || null === b ? R(this).removeItem(a, d) : (b = J.stringify({
        cookieHash: c,
        cachedValue: b
    }), R(this).setItem(a, b, d))
};
var qe = function() {};
H(qe, Q);
qe.prototype.A = function(a, b, c) {
    R(this).getItem(this.l(a), function(d) {
        if (d) try {
            var e = J.parse(d);
            var g = e && e.cachedValue
        } catch (f) {}
        c(g)
    })
};
qe.prototype.B = function(a, b, c, d) {
    a = this.l(a);
    void 0 === b || null === b ? R(this).removeItem(a, d) : (b = J.stringify({
        cachedValue: b
    }), R(this).setItem(a, b, d))
};
var re = function() {};
H(re, qe);
re.prototype.ab = function() {
    return !1
};
re.prototype.l = function(a) {
    return [N.ha, a.origin, a.clientId, a.id].join(N.m)
};
re.prototype.aa = function(a) {
    var b = {};
    a && (a = a.split(N.m), 4 == a.length && (b.origin = a[1], b.clientId = a[2], b.id = a[3]));
    return b
};
var se = function() {};
H(se, S);
se.prototype.l = function(a) {
    return [N.sb, a.origin, a.clientId].join(N.m)
};
se.prototype.aa = function(a) {
    a = a.split(N.m);
    var b = {};
    3 == a.length && (b.origin = a[1], b.clientId = a[2]);
    return b
};
var te = function() {};
H(te, S);
te.prototype.l = function(a) {
    return [N.Yb, a.origin, a.clientId].join(N.m)
};
te.prototype.A = function(a, b, c) {
    var d = this;
    S.prototype.A.call(this, a, b, function(e) {
        e && e.expires_at ? 6E4 > e.expires_at - (new Date).getTime() ? R(d).removeItem(d.l(a), c) : Dd(e.scope, a.scope) && Dd(a.scope, e.scope) ? (e.expires_in = Math.floor((e.expires_at - (new Date).getTime()) / 1E3), c && c(e)) : R(d).removeItem(d.l(a), c) : c && c(void 0)
    })
};
te.prototype.B = function(a, b, c, d) {
    var e;
    b && b.expires_at && 18E4 < b.expires_at - (new Date).getTime() && (e = b);
    S.prototype.B.call(this, a, e, c, d)
};
var ue = function() {};
H(ue, qe);
ue.prototype.ab = function() {
    return !1
};
ue.prototype.l = function(a) {
    return [N.ia, a.domain, a.crossSubDomains ? "1" : "0", L.Fb(a.policy), a.id || N.Ja].join(N.m)
};
ue.prototype.aa = function(a) {
    a = a.split(N.m);
    var b = {};
    5 == a.length && (b.domain = a[1], b.crossSubDomains = "1" == a[2], b.policy = a[3], b.id = a[4]);
    "DEFAULT" == b.policy && delete b.policy;
    b.id == N.Ja && delete b.id;
    return b
};
var ve = function(a) {
    this.Qc = a || N.wb
};
H(ve, S);
ve.prototype.l = function(a) {
    return [this.Qc, a.origin, a.clientId, a.id || N.tb].join(N.m)
};
ve.prototype.A = function(a, b, c) {
    var d = this;
    S.prototype.A.call(this, a, b, function(e) {
        e && e.ga && e.ga.expires_at ? a.loginHint != e.ga.login_hint ? R(d).removeItem(d.l(a), c) : 6E4 > e.ga.expires_at - (new Date).getTime() ? R(d).removeItem(d.l(a), c) : Dd(e.ga.scope, a.scope) ? Dd(e.responseType, a.responseType) ? (e = e.ga, e.expires_in = Math.floor((e.expires_at - (new Date).getTime()) / 1E3), c && c(e)) : R(d).removeItem(d.l(a), c) : R(d).removeItem(d.l(a), c) : c && c(void 0)
    })
};
ve.prototype.B = function(a, b, c, d) {
    var e;
    b && b.expires_at && 18E4 < b.expires_at - (new Date).getTime() && (e = {
        ga: b,
        responseType: a.responseType
    });
    S.prototype.B.call(this, a, e, c, d)
};
var we = function(a, b) {
        this.h = a;
        this.jb = b;
        this.Sa = !1;
        this.sa = {};
        this.ra = {};
        this.qa = {}
    },
    xe = function(a, b) {
        if (!b) throw "message object cannot be null.";
        b.rpcToken = a.jb;
        b = J.stringify(b);
        F("IDP IFrame sends message: " + b);
        window.parent.postMessage(b, a.h)
    },
    T = function(a, b, c) {
        b && xe(a, {
            id: b,
            result: c
        })
    };
we.prototype.Sc = function(a) {
    if (a.source == window.parent && a.origin == this.h) {
        F("IDP Session State IFrame receive message:" + a.data);
        try {
            var b = J.parse(a.data)
        } catch (d) {
            return
        }
        if ((b.rpcToken || this.jb) && b.rpcToken != this.jb) F("RPC token mismatch.");
        else if (b && b.method && ("showDialog" == b.method || this.sa[b.method]))
            if ("showDialog" == b.method)
                if (this.Sa) xe(this, {
                    id: b.id,
                    error: "dialog_already_displayed"
                });
                else if (a = b.params, b.id && a && a.dialogType && this.qa[a.dialogType]) {
            var c = this.qa[a.dialogType];
            c.s && !c.s(a) ?
                (F("Bad request."), xe(this, {
                    id: b.id,
                    error: "bad_request"
                })) : c.i(b)
        } else F("Bad dialog request.");
        else a = this.sa[b.method], a.O && !b.id ? F("Bad request.") : a.s && !a.s(b) ? (F("Bad request."), xe(this, {
            id: b.id,
            error: "bad_request"
        })) : a.i(b);
        else F("Bad request.")
    }
};
var U = function(a, b) {
        if (b && b.type && a.ra[b.type]) {
            var c = a.ra[b.type].filter;
            c && !c(b) || xe(a, {
                method: "fireIdpEvent",
                params: b
            })
        } else F("Invalid event type.")
    },
    ye = function(a) {
        U(a, {
            type: "displayIFrame",
            Fc: !1,
            options: {
                fullScreen: !0
            }
        });
        a.Sa = !0
    },
    ze = function(a) {
        U(a, {
            type: "displayIFrame",
            Fc: !0
        });
        a.Sa = !1
    },
    Ae = function(a, b) {
        a.sa = {};
        a.ra = {};
        a.qa = {};
        if (b) {
            if (b.w)
                for (var c = 0; c < b.w.length; c++) {
                    var d = b.w[c];
                    if (!d.method || !d.i) throw "Error in RPC policy: method or handler is empty.";
                    if (a.sa[d.method]) throw "Error in RPC policy: duplicate entry for RPC '" +
                        d.method + "'.";
                    var e = d.method;
                    a.sa[e] = {
                        i: d.i,
                        O: d.O,
                        s: d.s,
                        method: e
                    }
                }
            if (b.L)
                for (c = 0; c < b.L.length; c++) {
                    d = b.L[c];
                    if (!d.type) throw "Error in Event policy: type is empty.";
                    if (a.ra[d.type]) throw "Error in Event policy: duplicate entry for type '" + d.type + "'.";
                    e = d.type;
                    a.ra[e] = {
                        filter: d.filter,
                        type: e
                    }
                }
            if (b.Z)
                for (c = 0; c < b.Z.length; c++) {
                    d = b.Z[c];
                    if (!d.$) throw "Error in Dialog policy: dialogType is empty.";
                    if (a.qa[d.$]) throw "Error in Dialog policy: duplicate entry for dialogType '" + d.$ + "'.";
                    e = d.$;
                    a.qa[e] = {
                        $: e,
                        i: d.i,
                        s: d.s
                    }
                }
        }
    },
    Be = function(a, b, c, d) {
        U(a, {
            type: "sessionStateChanged",
            clientId: b,
            user: c,
            sessionState: d
        })
    },
    Ce = function(a) {
        var b = new ue,
            c = N.ia + N.m;
        return function(d) {
            if (d.key && 0 === d.key.indexOf(c)) {
                var e = b.aa(d.key);
                if (L.D(a.h, e.domain, e.crossSubDomains, e.policy)) {
                    var g;
                    if (d.newValue) try {
                        var f = J.parse(d.newValue);
                        f && (g = f.cachedValue)
                    } catch (h) {
                        return
                    }
                    U(a, {
                        type: "sessionSelectorChanged",
                        newValue: g,
                        crossSubDomains: e.crossSubDomains,
                        domain: e.domain,
                        policy: e.policy,
                        id: e.id
                    })
                }
            }
        }
    },
    De = function(a) {
        var b = new re,
            c = [N.ha,
                a.h
            ].join(N.m) + N.m;
        return function(d) {
            if (!d.key && Fd()) {
                var e = null,
                    g = [];
                for (d = 0; d < window.localStorage.length; d++) {
                    var f = window.localStorage.key(d);
                    if (0 === f.indexOf(c))
                        if (e) g.push(f);
                        else {
                            var h = window.localStorage.getItem(f);
                            g.push(f);
                            if (h) {
                                try {
                                    var k = J.parse(h)
                                } catch (l) {
                                    continue
                                }
                                k && k.cachedValue && (e = b.aa(f), e = {
                                    type: "authResult",
                                    clientId: e.clientId,
                                    id: e.id,
                                    authResult: k.cachedValue
                                })
                            }
                        }
                }
                for (d = 0; d < g.length; d++) window.localStorage.removeItem(g[d]);
                (k = e) && U(a, k)
            } else if (d.key && 0 === d.key.indexOf(c) && d.newValue) {
                try {
                    g =
                        J.parse(d.newValue)
                } catch (l) {
                    return
                }
                g && g.cachedValue && (k = b.aa(d.key), k = {
                    type: "authResult",
                    clientId: k.clientId,
                    id: k.id,
                    authResult: g.cachedValue
                }, U(a, k))
            }
        }
    },
    Ee = function(a, b) {
        this.h = a;
        this.U = b;
        this.Ab = new se;
        this.Rb = new ue;
        this.pb = new ve;
        this.Hb = new te
    },
    Fe = function(a, b, c, d, e) {
        a.Ab.B({
            origin: a.h,
            clientId: b
        }, {
            user: c.K,
            session: c.K ? c.W : void 0
        }, d, e)
    },
    Ge = function(a, b, c) {
        a.Ab.A({
            origin: a.h,
            clientId: b
        }, P(), c)
    },
    He = function(a, b, c, d, e, g, f) {
        a.pb.A({
                loginHint: b,
                origin: a.h,
                clientId: c,
                responseType: d,
                scope: e,
                id: g
            },
            P(), f)
    },
    Ie = function(a, b, c, d, e, g, f) {
        a.pb.B({
            origin: a.h,
            clientId: c,
            responseType: d,
            id: g
        }, e, b, f)
    },
    Je = function(a, b, c) {
        var d = a.pb;
        a = {
            origin: a.h,
            clientId: b
        };
        R(d).removeItem(d.l(a), c)
    },
    Ke = function(a, b, c, d, e, g) {
        if (!a.D(b, c, e)) throw "Permission denied for '" + a.h + "' to read session selector for domain '" + b + "'.";
        a.Rb.A({
            domain: b,
            crossSubDomains: c,
            policy: e,
            id: d
        }, void 0, function(f) {
            g && g(f)
        })
    },
    Le = function(a, b, c, d, e, g, f) {
        if (!a.D(b, c, g)) throw "Permission denied for '" + a.h + "' to write session selector for domain '" +
            b + "'.";
        a.Rb.B({
            domain: b,
            crossSubDomains: c,
            policy: g,
            id: e
        }, d, void 0, f)
    };
Ee.prototype.D = function(a, b, c) {
    return L.D(this.h, a, b, c)
};
var Me = function(a, b, c, d) {
        a.Hb.A({
            origin: a.h,
            clientId: b,
            scope: c
        }, P(), d)
    },
    Ne = function(a, b, c, d, e) {
        a.Hb.B({
            origin: a.h,
            clientId: c
        }, d, b, e)
    },
    Oe = function(a, b, c) {
        this.X = a;
        this.g = b;
        this.j = c
    },
    Pe = function(a, b, c) {
        a.K ? c && void 0 !== c[a.K] ? (c = c[a.K], Yd(a.W, c) || (a.W = c, Fe(a.j, a.X, a, b, function() {
            Be(a.g, a.X, a.K, a.W)
        }))) : a.W && (a.W = void 0, Fe(a.j, a.X, a, b, function() {
            Be(a.g, a.X, a.K, void 0)
        })) : b && Be(a.g, a.X, a.K, void 0)
    },
    Re = function(a, b, c, d) {
        this.U = a;
        this.g = b;
        this.J = c;
        this.j = d;
        this.oa = void 0;
        this.C = {};
        this.lb = [];
        var e = this;
        this.U.addListener(function(g) {
            Qe(e, g)
        })
    },
    Se = function(a) {
        var b = [],
            c;
        for (c in a.C) {
            var d = a.C[c].K;
            d && b.push(d)
        }
        return b
    },
    Qe = function(a, b) {
        if (b.newHash) ge(a.J, Se(a), function(d) {
            for (var e in a.C) Pe(a.C[e], b.newHash, d && d.activeHints)
        });
        else
            for (var c in a.C) Pe(a.C[c], b.newHash, void 0)
    },
    Te = function(a, b, c, d, e) {
        var g = a.C[b];
        g || (g = new Oe(b, a.g, a.j), a.C[b] = g);
        a = g;
        b = c.login_hint;
        c = c.session_state;
        a.K != b ? (a.K = b, a.W = b ? c : void 0, Fe(a.j, a.X, a, d, e)) : e && e()
    },
    Ue = function(a, b, c) {
        var d = a.C[b];
        d ? c(!0) : Ge(a.j, b, function(e) {
            e ?
                (d = new Oe(b, a.g, a.j), a.C[b] = d, d.K = e.user, d.W = e.session, c(!0)) : fe(a.J, b, function(g) {
                    g && g.valid ? (g = new Oe(b, a.g, a.j), a.C[b] = g, Fe(a.j, b, g, P(), function() {
                        c(!0)
                    })) : c(!1)
                })
        })
    },
    Ve = function(a, b) {
        Gd() || Id() ? a.lb.push(b) : Cd(Fd() ? document : window, "storage", b)
    },
    W = function(a, b, c) {
        this.h = a;
        this.lc = c;
        this.g = new we(a, b);
        this.U = new Zd(N.Wb);
        this.J = new ce(a);
        this.j = new Ee(a, this.U);
        this.P = new Re(this.U, this.g, this.J, this.j)
    };
m = W.prototype;
m.start = function() {
    var a = this,
        b = function() {
            a.g.Sc.apply(a.g, arguments)
        },
        c = function() {
            U(a.g, {
                type: "idpReady"
            });
            F("Initialize IDP IFrame successfully.")
        },
        d = function(e) {
            var g = window;
            if (g.removeEventListener) g.removeEventListener("message", b, !1);
            else if (g.detachEvent) g.detachEvent("onmessage", b);
            else throw "Remove event handler for message failed.";
            $d(a.U);
            U(a.g, {
                type: "idpError",
                error: e.message
            })
        };
    try {
        Ae(this.g, this.createPolicy()), Cd(window, "message", b), Ve(this.P, Ce(this.g)), Ve(this.P, De(this.g)), be(this.U),
            L.Gc(c, d, this.lc)
    } catch (e) {
        d(e)
    }
};
m.Oc = function(a) {
    var b = this;
    Ue(this.P, (a.params || {}).clientId, function(c) {
        T(b.g, a.id, c)
    })
};
m.xc = function(a) {
    var b = a.params || {},
        c = this,
        d = function(r) {
            T(c.g, a.id, r)
        },
        e = b.clientId,
        g = b.loginHint,
        f = b.request,
        h = b.sessionSelector;
    f.client_id = e;
    f.login_hint = g;
    f.ss_domain = h.domain;
    var k = P();
    if (k) {
        var l = !!f.enable_serial_consent,
            p = function(r) {
                r && !r.error && r.login_hint ? (r.first_issued_at = (new Date).getTime(), r.expires_at = r.first_issued_at + 1E3 * r.expires_in, r.session_state || (r.session_state = {}), l || r.scope || (r.scope = f.scope), b.skipCache ? Te(c.P, e, r, k, function() {
                    d(r)
                }) : Ie(c.j, k, e, f.response_type, r, b.id,
                    function() {
                        Te(c.P, e, r, k, function() {
                            d(r)
                        })
                    })) : (r = r || {}, d(r))
            };
        b.forceRefresh ? ie(this.J, f, p) : He(this.j, g, e, f.response_type, f.scope, b.id, function(r) {
            r && 18E4 < r.expires_at - (new Date).getTime() ? Te(c.P, e, r, k, function() {
                d(r)
            }) : ie(c.J, f, p)
        })
    } else T(c.g, a.id, {
        error: "user_logged_out"
    })
};
m.zc = function(a) {
    var b = this,
        c = function(f) {
            T(b.g, a.id, f)
        };
    if (P()) {
        var d = a.params || {},
            e = d.request,
            g = d.sessionSelector;
        e.client_id = d.clientId;
        e.login_hint = d.loginHint;
        e.ss_domain = g.domain;
        je(this.J, e, c)
    } else c({
        error: "user_logged_out"
    })
};
m.Yc = function(a) {
    var b = a.params || {},
        c = b.clientId,
        d = this;
    le(this.J, b.token, function(e) {
        Je(d.j, c, function() {
            T(d.g, a.id, e)
        })
    })
};
m.kd = function(a) {
    if (Gd() || Id()) {
        var b = a.params || {},
            c = (new re).l({
                clientId: b.clientId,
                id: b.id,
                origin: b.origin
            });
        b = this.P;
        if (Gd() || Id()) {
            b.oa && b.oa.stop();
            b.oa = new Vd(c);
            for (c = 0; c < b.lb.length; c++) b.oa.addListener(b.lb[c]);
            b.oa.start()
        }
    }
    T(this.g, a.id, !0)
};
m.wc = function(a) {
    var b = this,
        c = a.params || {};
    Ke(this.j, c.domain, c.crossSubDomains, c.id, c.policy, function(d) {
        T(b.g, a.id, d)
    })
};
m.cd = function(a) {
    var b = a.params || {},
        c = b.hint,
        d = !!b.disabled,
        e = b.domain,
        g = b.crossSubDomains,
        f = b.id,
        h = b.policy,
        k = this;
    if (c || d) var l = {
        hint: c,
        disabled: d
    };
    Le(this.j, e, g, l, f, h, function() {
        U(k.g, {
            type: "sessionSelectorChanged",
            newValue: l,
            domain: e,
            crossSubDomains: g,
            id: f,
            policy: h
        });
        T(k.g, a.id, !0)
    })
};
m.Lc = function(a) {
    var b = a.params || {},
        c = this,
        d = function(l) {
            T(c.g, a.id, l)
        },
        e = b.clientId,
        g = b.request,
        f = b.sessionSelector;
    g.client_id = e;
    g.response_type = "id_token";
    g.ss_domain = f.domain;
    var h = P();
    if (h) {
        var k = function(l) {
            l && !l.error ? (l.first_issued_at = (new Date).getTime(), l.expires_at = l.first_issued_at + 1E3 * l.expires_in, l.scope = g.scope, Ne(c.j, h, e, l, function() {
                d(l)
            })) : (l = l || {
                error: "No response returned from Server."
            }, d(l))
        };
        b.forceRefresh ? ke(this.J, g, k) : Me(this.j, e, g.scope, function(l) {
            l ? d(l) : ke(c.J, g, k)
        })
    } else d({
        scope: g.scope,
        sessions: []
    })
};
m.kc = function(a) {
    if (document.hasStorageAccess && zd(document.hasStorageAccess)) {
        var b = this;
        document.hasStorageAccess().then(function(c) {
            T(b.g, a.id, {
                hasAccess: c
            })
        }, function(c) {
            F("CheckStorageAccess failed: " + c);
            T(b.g, a.id, {
                hasAccess: !1
            })
        })
    } else T(this.g, a.id, {
        hasAccess: !0
    })
};
m.Pc = function(a) {
    a = a && a.params || {};
    return a.clientId && !O(a.clientId)
};
m.Ec = function(a) {
    var b = a && a.params || {};
    a = b.loginHint;
    var c = !O(b.id),
        d = b.clientId && !O(b.clientId),
        e = !!b.request,
        g = e && b.request.scope;
    (b = (e = e && b.request.response_type) && 0 <= b.request.response_type.indexOf("code")) && F("Bad request: 'code' response_type is not supported.");
    return a && c && d && g && e && !b
};
m.Ac = function(a) {
    a = a && a.params || {};
    var b = !O(a.id),
        c = a.clientId && !O(a.clientId),
        d = !!a.request && a.request.scope;
    return a.loginHint && b && c && d
};
m.Cc = function(a) {
    a = a && a.params || {};
    var b = a.domain && !O(a.domain),
        c = !O(a.policy);
    return !O(a.id) && b && c && this.j.D(a.domain, !!a.crossSubDomains, a.policy)
};
m.dd = function(a) {
    a = a && a.params || {};
    var b = a.domain && !O(a.domain),
        c = !O(a.policy);
    return !O(a.id) && b && c && this.j.D(a.domain, !!a.crossSubDomains, a.policy) && N.fc(a)
};
m.Mc = function(a) {
    a = a && a.params || {};
    var b = a.clientId && !O(a.clientId),
        c = !!a.request && a.request.scope;
    return !O(a.id) && b && c
};
m.Zc = function(a) {
    a = a && a.params || {};
    var b = !!a.token,
        c = a.clientId && !O(a.clientId);
    return !O(a.id) && b && c
};
m.ld = function(a) {
    a = a && a.params || {};
    var b = a.origin && !O(a.origin),
        c = a.id && !O(a.id);
    return a.clientId && !O(a.clientId) && b && c
};
m.ad = function(a) {
    var b;
    if (b = a.clientId) a = a.clientId, b = !(!a || !this.P.C[a]);
    return b
};
m.ic = function(a) {
    var b;
    if (b = a.clientId) b = a.clientId, b = !(!b || !this.P.C[b]);
    return b && a.id && a.authResult
};
m.pc = function(a) {
    return !!a.hide || !!a.options
};
m.$c = function(a) {
    return a.domain && this.j.D(a.domain, a.crossSubDomains, a.policy)
};
var X = function(a, b) {
    return function() {
        return b.apply(a, arguments)
    }
};
W.prototype.createPolicy = function() {
    var a = {
        w: [],
        L: [],
        Z: []
    };
    We(this, a);
    return a
};
var We = function(a, b) {
    b.w.push({
        method: "monitorClient",
        i: X(a, a.Oc),
        O: !1,
        s: X(a, a.Pc)
    });
    b.w.push({
        method: "getTokenResponse",
        i: X(a, a.xc),
        O: !0,
        s: X(a, a.Ec)
    });
    b.w.push({
        method: "getOnlineCode",
        i: X(a, a.zc),
        O: !0,
        s: X(a, a.Ac)
    });
    b.w.push({
        method: "getSessionSelector",
        i: X(a, a.wc),
        O: !0,
        s: X(a, a.Cc)
    });
    b.w.push({
        method: "setSessionSelector",
        i: X(a, a.cd),
        O: !1,
        s: X(a, a.dd)
    });
    b.w.push({
        method: "listIdpSessions",
        i: X(a, a.Lc),
        O: !0,
        s: X(a, a.Mc)
    });
    b.w.push({
        method: "revoke",
        i: X(a, a.Yc),
        s: X(a, a.Zc)
    });
    b.w.push({
        method: "startPolling",
        i: X(a, a.kd),
        s: X(a, a.ld)
    });
    b.L.push({
        type: "idpReady"
    });
    b.L.push({
        type: "idpError"
    });
    b.L.push({
        type: "sessionStateChanged",
        filter: X(a, a.ad)
    });
    b.L.push({
        type: "sessionSelectorChanged",
        filter: X(a, a.$c)
    });
    b.L.push({
        type: "authResult",
        filter: X(a, a.ic)
    });
    b.L.push({
        type: "displayIFrame",
        filter: X(a, a.pc)
    });
    b.w.push({
        method: "checkStorageAccess",
        i: X(a, a.kc),
        O: !0
    })
};
var Xe = "client_id origin ss_domain scope privileged authuser".split(" ");
N.xa = "response_type login_hint client_id origin scope ss_domain authuser hd include_granted_scopes nonce spec_compliant".split(" ");
var Ze = function(a, b, c) {
    b.origin = a.h;
    b.privileged = !0;
    b = he(b, Xe);
    ee(N.La, b, Ye(a.h), function(d) {
        c(d)
    })
};

function Ye(a) {
    var b = {},
        c = N.Bc();
    if (c) {
        if (!c) throw Error("Session cookie value cannot be empty.");
        c = new wb(new xb, ya(c));
        a = ya(a);
        c.reset();
        c.update(a);
        a = c.digest();
        var d;
        c = qa(a);
        v("array" == c || "object" == c && "number" == typeof a.length, "encodeByteArray takes an array as a parameter");
        void 0 === d && (d = 0);
        if (!ub) {
            ub = {};
            c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split("");
            for (var e = ["+/=", "+/", "-_=", "-_.", "-_"], g = 0; 5 > g; g++) {
                var f = c.concat(e[g].split(""));
                tb[g] = f;
                for (var h = 0; h < f.length; h++) {
                    var k =
                        f[h],
                        l = ub[k];
                    void 0 === l ? ub[k] = h : v(l === h)
                }
            }
        }
        d = tb[d];
        c = [];
        for (e = 0; e < a.length; e += 3) {
            l = a[e];
            var p = (g = e + 1 < a.length) ? a[e + 1] : 0;
            k = (f = e + 2 < a.length) ? a[e + 2] : 0;
            h = l >> 2;
            l = (l & 3) << 4 | p >> 4;
            p = (p & 15) << 2 | k >> 6;
            k &= 63;
            f || (k = 64, g || (p = 64));
            c.push(d[h], d[l], d[p] || "", d[k] || "")
        }
        b["X-Csrf-Token"] = c.join("")
    }
    return b
};
var $e = function() {};
H($e, S);
$e.prototype.l = function(a) {
    a = void 0 === a ? {} : a;
    return ["gsi_gs", void 0 === a.origin ? null : a.origin, void 0 === a.clientId ? null : a.clientId].join(N.m)
};
$e.prototype.A = function(a, b, c) {
    var d = this;
    c = void 0 === c ? function() {} : c;
    S.prototype.A.call(this, a, b, function(e) {
        e ? !e.expires_at || e.expires_at <= (new Date).getTime() ? R(d).removeItem(d.l(a), function() {
            return c(null)
        }) : (e.expires_at = void 0, c(e)) : c(null)
    })
};
$e.prototype.B = function(a, b, c, d) {
    b && (b.expires_at = (new Date).getTime() + 864E5);
    S.prototype.B.call(this, a, b, c, d)
};
W.prototype.uc = function(a) {
    var b = this;
    a = void 0 === a ? {} : a;
    var c = a.id,
        d = void 0 === a.params ? {} : a.params,
        e = function(p) {
            p && p.sessions ? (p = af(g, p.sessions), T(b.g, c, p)) : T(b.g, c, null)
        },
        g = d.loginHint;
    delete d.loginHint;
    var f = P();
    if (f) {
        a = d.clientId;
        var h = d.request;
        d = d.sessionSelector;
        h.client_id = a;
        h.ss_domain = d.domain;
        var k = new $e,
            l = {
                clientId: a,
                origin: this.h
            };
        k.A(l, f, function(p) {
            p ? e(p) : Ze(b.J, h, function(r) {
                !r || r.error ? e(null) : k.B(l, r, f, function() {
                    e(r)
                })
            })
        })
    } else e(null)
};

function af(a, b) {
    if (!b.length) return null;
    var c = a.toLowerCase();
    b = n(b);
    for (var d = b.next(); !d.done; d = b.next())
        if (d = d.value, d.login_hint) {
            if (a === d.obfuscatedGaiaId) return d.login_hint;
            if (d.emails && d.emails.length)
                for (var e = n(d.emails), g = e.next(); !g.done; g = e.next())
                    if (c === g.value.toLowerCase()) return d.login_hint
        }
    return null
}
W.prototype.gd = function(a) {
    bf(this, a, !1)
};
W.prototype.hd = function(a) {
    bf(this, a, !0)
};
var bf = function(a, b, c) {
    document.requestStorageAccess && zd(document.requestStorageAccess) ? document.hasStorageAccess().then(function(d) {
        if (d) T(a.g, b.id, {
            hasAccess: !0
        });
        else {
            d = new Rc({
                origin: a.h
            });
            var e = document.getElementById("container");
            (c ? d.Vc : d.Uc).call(d, e, function() {
                ze(a.g);
                T(a.g, b.id, {
                    hasAccess: !0
                })
            }, function() {
                ze(a.g);
                T(a.g, b.id, {
                    hasAccess: !1
                })
            });
            ye(a.g)
        }
    }, function(d) {
        F("StorageAccess check failed: " + d);
        T(a.g, b.id, {
            hasAccess: !1
        })
    }) : T(a.g, b.id, {
        hasAccess: !0
    })
};
W.prototype.vc = function(a) {
    a = void 0 === a ? {} : a;
    a = void 0 === a.params ? {} : a.params;
    var b = !!a.clientId && !O(a.clientId),
        c = !!a.request,
        d = !!a.sessionSelector;
    return !!a.loginHint && b && c && d
};
W.prototype.createPolicy = function() {
    var a = {
        w: [],
        Z: [],
        L: []
    };
    We(this, a);
    a.w.push({
        method: "gsi:fetchLoginHint",
        i: X(this, this.uc),
        O: !0,
        s: X(this, this.vc)
    });
    a.Z.push({
        $: "itpNewGrant",
        i: X(this, this.gd)
    });
    a.Z.push({
        $: "itpRegrant",
        i: X(this, this.hd)
    });
    return a
};
N.xb = "/o/oauth2/iframerpc?action=sessionState";
N.rb = "/o/oauth2/iframerpc?action=checkOrigin";
N.vb = "/o/oauth2/iframerpc?action=issueToken";
N.ub = "/o/oauth2/iframerpc?action=issueOnlineCode";
N.La = "/o/oauth2/iframerpc?action=listSessions";
var cf = function() {
        var a = Bd("origin");
        if (!a) throw "Failed to get parent origin from URL hash!";
        var b = Bd("rpcToken");
        if (!b) throw "Failed to get rpcToken from URL hash!";
        var c = !!Bd("clearCache"),
            d = Bd("debug");
        yd = "0" != d && !!d;
        (new W(a, b, c)).start()
    },
    df = ["lso", "startIdpIFrame"],
    Y = t;
df[0] in Y || "undefined" == typeof Y.execScript || Y.execScript("var " + df[0]);
for (var Z; df.length && (Z = df.shift());) df.length || void 0 === cf ? Y = Y[Z] && Y[Z] !== Object.prototype[Z] ? Y[Z] : Y[Z] = {} : Y[Z] = cf;