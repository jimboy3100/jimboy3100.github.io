(function(g) {
    var window = this;
    var awa = function(a, b) {
            return g.Jb(a, b)
        },
        Y5 = function(a, b, c) {
            a.w.set(b, c)
        },
        Z5 = function(a) {
            Y5(a, "zx", Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ (0, g.B)()).toString(36));
            return a
        },
        $5 = function(a, b, c) {
            Array.isArray(c) || (c = [String(c)]);
            g.an(a.w, b, c)
        },
        bwa = function(a, b) {
            var c = [];
            g.hk(b, function(d) {
                try {
                    var e = g.$n.prototype.u.call(this, d, !0)
                } catch (f) {
                    if ("Storage: Invalid value was encountered" == f) return;
                    throw f;
                }
                void 0 === e ? c.push(d) : g.Zn(e) && c.push(d)
            }, a);
            return c
        },
        cwa = function(a, b) {
            var c = bwa(a, b);
            (0, g.x)(c, function(d) {
                g.$n.prototype.remove.call(this, d)
            }, a)
        },
        dwa = function(a) {
            if (a.Oc) {
                if (a.Oc.locationOverrideToken) return {
                    locationOverrideToken: a.Oc.locationOverrideToken
                };
                if (null != a.Oc.latitudeE7 && null != a.Oc.longitudeE7) return {
                    latitudeE7: a.Oc.latitudeE7,
                    longitudeE7: a.Oc.longitudeE7
                }
            }
            return null
        },
        ewa = function(a, b) {
            g.$a(a, b) || a.push(b)
        },
        a6 = function(a) {
            var b = 0,
                c;
            for (c in a) b++;
            return b
        },
        fwa = function(a, b) {
            var c = b instanceof g.tc ? b : g.yc(b, /^data:image\//i.test(b));
            a.src = g.uc(c)
        },
        b6 = function() {},
        gwa = function(a) {
            try {
                return g.v.JSON.parse(a)
            } catch (b) {}
            a = String(a);
            if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
                return eval("(" + a + ")")
            } catch (b) {}
            throw Error("Invalid JSON string: " + a);
        },
        hwa = function(a) {
            if (a.zd && "function" == typeof a.zd) return a.zd();
            if ("string" === typeof a) return a.split("");
            if (g.La(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            return g.Fb(a)
        },
        iwa = function(a, b) {
            if (a.forEach && "function" == typeof a.forEach) a.forEach(b, void 0);
            else if (g.La(a) || "string" === typeof a)(0, g.x)(a, b, void 0);
            else {
                if (a.ne && "function" == typeof a.ne) var c = a.ne();
                else if (a.zd && "function" == typeof a.zd) c = void 0;
                else if (g.La(a) || "string" === typeof a) {
                    c = [];
                    for (var d = a.length, e = 0; e < d; e++) c.push(e)
                } else c = g.Gb(a);
                d = hwa(a);
                e = d.length;
                for (var f = 0; f < e; f++) b.call(void 0, d[f], c && c[f], a)
            }
        },
        jwa = function(a, b, c, d) {
            var e = new g.Pm(null, void 0);
            a && g.Qm(e, a);
            b && g.Rm(e, b);
            c && g.Sm(e, c);
            d && (e.u = d);
            return e
        },
        c6 = function(a, b) {
            g.Mo[a] = !0;
            var c = g.Ko();
            c && c.publish.apply(c, arguments);
            g.Mo[a] = !1
        },
        d6 = function(a) {
            this.app = this.name = this.id = "";
            this.type = "REMOTE_CONTROL";
            this.obfuscatedGaiaId = this.avatar = this.username = "";
            this.capabilities = new Set;
            this.experiments = new Set;
            this.theme = "u";
            new g.Mm;
            a && (this.id = a.id || a.name, this.name = a.name, this.app = a.app, this.type = a.type || "REMOTE_CONTROL", this.username = a.user || "", this.avatar = a.userAvatarUri || "", this.obfuscatedGaiaId = a.obfuscatedGaiaId || "", this.theme = a.theme || "u", kwa(this, a.capabilities || ""), lwa(this, a.experiments || ""))
        },
        kwa = function(a, b) {
            a.capabilities.clear();
            (0, g.ue)(b.split(","), g.Qa(awa, mwa)).forEach(function(c) {
                a.capabilities.add(c)
            })
        },
        lwa = function(a, b) {
            a.experiments.clear();
            b.split(",").forEach(function(c) {
                a.experiments.add(c)
            })
        },
        e6 = function(a) {
            a = a || {};
            this.name = a.name || "";
            this.id = a.id || a.screenId || "";
            this.token = a.token || a.loungeToken || "";
            this.uuid = a.uuid || a.dialId || ""
        },
        f6 = function(a, b) {
            return !!b && (a.id == b || a.uuid == b)
        },
        nwa = function(a) {
            return {
                name: a.name,
                screenId: a.id,
                loungeToken: a.token,
                dialId: a.uuid
            }
        },
        owa = function(a) {
            return new e6(a)
        },
        pwa = function(a) {
            return Array.isArray(a) ? (0, g.Dc)(a, owa) : []
        },
        g6 = function(a) {
            return a ? '{name:"' + a.name + '",id:' + a.id.substr(0, 6) + "..,token:" + (a.token ? ".." + a.token.slice(-6) : "-") + ",uuid:" + (a.uuid ? ".." + a.uuid.slice(-6) : "-") + "}" : "null"
        },
        h6 = function(a) {
            return Array.isArray(a) ? "[" + (0, g.Dc)(a, g6).join(",") + "]" : "null"
        },
        i6 = function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
                var b = 16 * Math.random() |
                    0;
                return ("x" == a ? b : b & 3 | 8).toString(16)
            })
        },
        qwa = function(a) {
            return (0, g.Dc)(a, function(b) {
                return {
                    key: b.id,
                    name: b.name
                }
            })
        },
        j6 = function(a, b) {
            return g.Xa(a, function(c) {
                return c || b ? !c != !b ? !1 : c.id == b.id : !0
            })
        },
        k6 = function(a, b) {
            return g.Xa(a, function(c) {
                return f6(c, b)
            })
        },
        rwa = function() {
            var a = (0, g.ns)();
            a && cwa(a, a.o.Sf(!0))
        },
        l6 = function() {
            var a = g.qs("yt-remote-connected-devices") || [];
            g.rb(a);
            return a
        },
        swa = function(a) {
            if (g.ab(a)) return [];
            var b = a[0].indexOf("#"),
                c = -1 == b ? a[0] : a[0].substring(0, b);
            return (0, g.Dc)(a, function(d, e) {
                return 0 == e ? d : d.substring(c.length)
            })
        },
        twa = function(a) {
            g.ps("yt-remote-connected-devices", a, 86400)
        },
        n6 = function() {
            if (m6) return m6;
            var a = g.qs("yt-remote-device-id");
            a || (a = i6(), g.ps("yt-remote-device-id", a, 31536E3));
            for (var b = l6(), c = 1, d = a; g.$a(b, d);) c++, d = a + "#" + c;
            return m6 = d
        },
        o6 = function() {
            var a = l6(),
                b = n6();
            g.$a(a, b);
            g.ts() && g.tb(a, b);
            a = swa(a);
            if (g.ab(a)) try {
                g.Bq("remote_sid")
            } catch (c) {} else try {
                g.zq("remote_sid", a.join(","), -1)
            } catch (c) {}
        },
        uwa = function() {
            return g.qs("yt-remote-session-browser-channel")
        },
        vwa = function() {
            return g.qs("yt-remote-local-screens") || []
        },
        wwa = function() {
            g.ps("yt-remote-lounge-token-expiration", !0, 86400)
        },
        xwa = function(a) {
            5 < a.length && (a = a.slice(a.length - 5));
            var b = (0, g.Dc)(vwa(), function(d) {
                    return d.loungeToken
                }),
                c = (0, g.Dc)(a, function(d) {
                    return d.loungeToken
                });
            (0, g.ti)(c, function(d) {
                return !g.$a(b, d)
            }) && wwa();
            g.ps("yt-remote-local-screens", a, 31536E3)
        },
        ywa = function(a, b) {
            g.ps("yt-remote-session-browser-channel", a);
            g.ps("yt-remote-session-screen-id", b);
            var c = l6(),
                d = n6();
            g.$a(c, d) || c.push(d);
            twa(c);
            o6()
        },
        p6 = function(a) {
            a || (g.rs("yt-remote-session-screen-id"), g.rs("yt-remote-session-video-id"));
            o6();
            a = l6();
            g.db(a, n6());
            twa(a)
        },
        zwa = function() {
            if (!q6) {
                var a = g.ko();
                a && (q6 = new g.Un(a))
            }
            return q6 ? !!q6.get("yt-remote-use-staging-server") : !1
        },
        Awa = function(a) {
            return !!document.currentScript && (-1 != document.currentScript.src.indexOf("?" + a) || -1 != document.currentScript.src.indexOf("&" + a))
        },
        Bwa = function() {
            return "function" == typeof window.__onGCastApiAvailable ? window.__onGCastApiAvailable : null
        },
        r6 = function(a) {
            a.length ? Cwa(a.shift(), function() {
                r6(a)
            }) : s6()
        },
        Dwa = function(a) {
            return "chrome-extension://" + a + "/cast_sender.js"
        },
        Cwa = function(a, b, c) {
            var d = document.createElement("script");
            d.onerror = b;
            c && (d.onload = c);
            d.src = a;
            (document.head || document.documentElement).appendChild(d)
        },
        s6 = function() {
            var a = Bwa();
            a && a(!1, "No cast extension found")
        },
        Fwa = function() {
            if (Ewa) {
                var a = 2,
                    b = Bwa(),
                    c = function() {
                        a--;
                        0 == a && b && b(!0)
                    };
                window.__onGCastApiAvailable = c;
                Cwa("//www.gstatic.com/cast/sdk/libs/sender/1.0/cast_framework.js", s6, c)
            }
        },
        Gwa = function() {
            Fwa();
            var a = window.navigator.userAgent.match(/Chrome\/([0-9]+)/);
            r6(["//www.gstatic.com/eureka/clank/" + (a ? parseInt(a[1], 10) : 0) + "/cast_sender.js", "//www.gstatic.com/eureka/clank/cast_sender.js"])
        },
        t6 = function(a, b, c) {
            g.y.call(this);
            this.C = null != c ? (0, g.w)(a, c) : a;
            this.ud = b;
            this.B = (0, g.w)(this.bF, this);
            this.o = !1;
            this.u = 0;
            this.w = this.Ia = null;
            this.A = []
        },
        u6 = function(a, b, c) {
            g.y.call(this);
            this.w = null != c ? (0, g.w)(a, c) : a;
            this.ud = b;
            this.u = (0, g.w)(this.cF, this);
            this.o = []
        },
        v6 = function(a) {
            a.Ia = g.Uf(a.u, a.ud);
            a.w.apply(null, a.o)
        },
        w6 = function(a) {
            if (g.v.JSON) try {
                return g.v.JSON.parse(a)
            } catch (b) {}
            return gwa(a)
        },
        x6 = function() {},
        y6 = function() {},
        Hwa = function() {},
        Jwa = function(a) {
            return (a = Iwa(a)) ? new ActiveXObject(a) : new XMLHttpRequest
        },
        Iwa = function(a) {
            if (!a.u && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
                for (var b = ["MSXML2.XMLHTTP.6.0",
                        "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"
                    ], c = 0; c < b.length; c++) {
                    var d = b[c];
                    try {
                        return new ActiveXObject(d), a.u = d
                    } catch (e) {}
                }
                throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
            }
            return a.u
        },
        z6 = function(a, b, c, d) {
            this.o = a;
            this.w = b;
            this.G = c;
            this.F = d || 1;
            this.B = 45E3;
            this.A = new g.z1(this);
            this.u = new g.Tf;
            this.u.setInterval(250)
        },
        Lwa = function(a, b, c) {
            a.Ej = 1;
            a.Og = Z5(b.clone());
            a.Xi = c;
            a.C = !0;
            Kwa(a, null)
        },
        A6 = function(a, b, c, d, e) {
            a.Ej = 1;
            a.Og = Z5(b.clone());
            a.Xi = null;
            a.C = c;
            e && (a.PB = !1);
            Kwa(a, d)
        },
        Kwa = function(a, b) {
            a.vk = (0, g.B)();
            B6(a);
            a.Mh = a.Og.clone();
            $5(a.Mh, "t", a.F);
            a.Mm = 0;
            a.Hc = a.o.kr(a.o.Cm() ? b : null);
            0 < a.Wr && (a.Ep = new u6((0, g.w)(a.LC, a, a.Hc), a.Wr));
            a.A.la(a.Hc, "readystatechange", a.PN);
            var c = a.wi ? g.Pb(a.wi) : {};
            a.Xi ? (a.lq = "POST", c["Content-Type"] = "application/x-www-form-urlencoded", a.Hc.send(a.Mh, a.lq, a.Xi, c)) : (a.lq = "GET", a.PB && !g.je && (c.Connection = "close"), a.Hc.send(a.Mh, a.lq, null, c));
            a.o.We(1)
        },
        Owa = function(a, b, c) {
            for (var d = !0; !a.di && a.Mm < c.length;) {
                var e = Mwa(a, c);
                if (e == C6) {
                    4 == b && (a.fh = 4, D6(15), d = !1);
                    break
                } else if (e == Nwa) {
                    a.fh = 4;
                    D6(16);
                    d = !1;
                    break
                } else E6(a, e)
            }
            4 == b && 0 == c.length && (a.fh = 1, D6(17), d = !1);
            a.Ye = a.Ye && d;
            d || (F6(a), G6(a))
        },
        Mwa = function(a, b) {
            var c = a.Mm,
                d = b.indexOf("\n", c);
            if (-1 == d) return C6;
            c = Number(b.substring(c, d));
            if (isNaN(c)) return Nwa;
            d += 1;
            if (d + c > b.length) return C6;
            var e = b.substr(d, c);
            a.Mm = d + c;
            return e
        },
        Qwa = function(a, b) {
            a.vk = (0, g.B)();
            B6(a);
            var c = b ? window.location.hostname : "";
            a.Mh = a.Og.clone();
            Y5(a.Mh, "DOMAIN", c);
            Y5(a.Mh, "t", a.F);
            try {
                a.cf = new ActiveXObject("htmlfile")
            } catch (n) {
                F6(a);
                a.fh = 7;
                D6(22);
                G6(a);
                return
            }
            var d = "<html><body>";
            if (b) {
                for (var e = "", f = 0; f < c.length; f++) {
                    var k = c.charAt(f);
                    if ("<" == k) e += "\\x3c";
                    else if (">" == k) e += "\\x3e";
                    else {
                        var l = k;
                        if (l in H6) k = H6[l];
                        else if (l in Pwa) k = H6[l] = Pwa[l];
                        else {
                            var m = l.charCodeAt(0);
                            if (31 < m && 127 > m) k = l;
                            else {
                                if (256 > m) {
                                    if (k = "\\x", 16 > m || 256 < m) k += "0"
                                } else k = "\\u", 4096 > m && (k += "0");
                                k += m.toString(16).toUpperCase()
                            }
                            k =
                                H6[l] = k
                        }
                        e += k
                    }
                }
                d += '<script>document.domain="' + e + '"\x3c/script>'
            }
            c = g.Wc(g.Yb("b/12014412"), d + "</body></html>");
            a.cf.open();
            a.cf.write(g.Rc(c));
            a.cf.close();
            a.cf.parentWindow.m = (0, g.w)(a.kN, a);
            a.cf.parentWindow.d = (0, g.w)(a.XA, a, !0);
            a.cf.parentWindow.rpcClose = (0, g.w)(a.XA, a, !1);
            c = a.cf.createElement("DIV");
            a.cf.parentWindow.document.body.appendChild(c);
            d = g.xc(a.Mh.toString());
            d = g.dd(g.uc(d));
            d = g.Wc(g.Yb("b/12014412"), '<iframe src="' + d + '"></iframe>');
            g.Xc(c, d);
            a.o.We(1)
        },
        B6 = function(a) {
            a.Yu = (0, g.B)() + a.B;
            Rwa(a, a.B)
        },
        Rwa = function(a, b) {
            if (null != a.Jk) throw Error("WatchDog timer not null");
            a.Jk = I6((0, g.w)(a.sN, a), b)
        },
        J6 = function(a) {
            a.Jk && (g.v.clearTimeout(a.Jk), a.Jk = null)
        },
        G6 = function(a) {
            a.o.Fx() || a.di || a.o.bo(a)
        },
        F6 = function(a) {
            J6(a);
            g.He(a.Ep);
            a.Ep = null;
            a.u.stop();
            g.Vqa(a.A);
            if (a.Hc) {
                var b = a.Hc;
                a.Hc = null;
                b.abort();
                b.dispose()
            }
            a.cf && (a.cf = null)
        },
        E6 = function(a, b) {
            try {
                a.o.PA(a, b), a.o.We(4)
            } catch (c) {}
        },
        Twa = function(a, b, c, d, e) {
            if (0 == d) c(!1);
            else {
                var f = e || 0;
                d--;
                Swa(a, b, function(k) {
                    k ? c(!0) : g.v.setTimeout(function() {
                        Twa(a, b, c, d, f)
                    }, f)
                })
            }
        },
        Swa = function(a, b, c) {
            var d = new Image;
            d.onload = function() {
                try {
                    K6(d), c(!0)
                } catch (e) {}
            };
            d.onerror = function() {
                try {
                    K6(d), c(!1)
                } catch (e) {}
            };
            d.onabort = function() {
                try {
                    K6(d), c(!1)
                } catch (e) {}
            };
            d.ontimeout = function() {
                try {
                    K6(d), c(!1)
                } catch (e) {}
            };
            g.v.setTimeout(function() {
                if (d.ontimeout) d.ontimeout()
            }, b);
            fwa(d, a)
        },
        K6 = function(a) {
            a.onload = null;
            a.onerror = null;
            a.onabort = null;
            a.ontimeout = null
        },
        Uwa = function(a) {
            this.o = a;
            this.u = new x6
        },
        Vwa = function(a) {
            var b = L6(a.o, a.Tk, "/mail/images/cleardot.gif");
            Z5(b);
            Twa(b.toString(), 5E3, (0, g.w)(a.ZD, a), 3, 2E3);
            a.We(1)
        },
        N6 = function(a) {
            var b = a.o.H;
            if (null != b) D6(5), b ? (D6(11), M6(a.o, a, !1)) : (D6(12), M6(a.o, a, !0));
            else if (a.Od = new z6(a, void 0, void 0, void 0), a.Od.wi = a.Ur, b = a.o, b = L6(b, b.Cm() ? a.yl : null, a.Vr), D6(5), !g.he || g.Ld(10)) $5(b, "TYPE", "xmlhttp"), A6(a.Od, b, !1, a.yl, !1);
            else {
                $5(b, "TYPE", "html");
                var c = a.Od;
                a = !!a.yl;
                c.Ej = 3;
                c.Og = Z5(b.clone());
                Qwa(c, a)
            }
        },
        O6 = function(a) {
            g.gf.call(this);
            this.headers = new g.Mm;
            this.T = a || null;
            this.w = !1;
            this.R = this.o = null;
            this.ga = this.H = "";
            this.C = 0;
            this.A = "";
            this.B = this.Z = this.G = this.U = !1;
            this.F = 0;
            this.O = null;
            this.da = "";
            this.M = this.aa = !1
        },
        Wwa = function(a) {
            return g.he && g.Kd(9) && "number" === typeof a.timeout && void 0 !== a.ontimeout
        },
        Xwa = function(a) {
            return "content-type" == a.toLowerCase()
        },
        Zwa = function(a, b) {
            a.w = !1;
            a.o && (a.B = !0, a.o.abort(), a.B = !1);
            a.A = b;
            a.C = 5;
            Ywa(a);
            P6(a)
        },
        Ywa = function(a) {
            a.U || (a.U = !0, a.dispatchEvent("complete"), a.dispatchEvent("error"))
        },
        axa = function(a) {
            if (a.w && "undefined" != typeof g.E1)
                if (a.R[1] && 4 == Q6(a) && 2 == a.getStatus()) R6(a, "Local request error detected and ignored");
                else if (a.G && 4 == Q6(a)) g.Uf(a.LA, 0, a);
            else if (a.dispatchEvent("readystatechange"), 4 == Q6(a)) {
                R6(a, "Request complete");
                a.w = !1;
                try {
                    var b = a.getStatus();
                    a: switch (b) {
                        case 200:
                        case 201:
                        case 202:
                        case 204:
                        case 206:
                        case 304:
                        case 1223:
                            var c = !0;
                            break a;
                        default:
                            c = !1
                    }
                    var d;
                    if (!(d = c)) {
                        var e;
                        if (e = 0 === b) {
                            var f = g.nd(1, String(a.H));
                            if (!f && g.v.self && g.v.self.location) {
                                var k = g.v.self.location.protocol;
                                f = k.substr(0, k.length - 1)
                            }
                            e = !$wa.test(f ? f.toLowerCase() : "")
                        }
                        d = e
                    }
                    if (d) a.dispatchEvent("complete"), a.dispatchEvent("success");
                    else {
                        a.C = 6;
                        try {
                            var l = 2 < Q6(a) ? a.o.statusText : ""
                        } catch (m) {
                            l = ""
                        }
                        a.A = l + " [" + a.getStatus() + "]";
                        Ywa(a)
                    }
                } finally {
                    P6(a)
                }
            }
        },
        P6 = function(a, b) {
            if (a.o) {
                bxa(a);
                var c = a.o,
                    d = a.R[0] ? g.Ia : null;
                a.o = null;
                a.R = null;
                b || a.dispatchEvent("ready");
                try {
                    c.onreadystatechange = d
                } catch (e) {}
            }
        },
        bxa = function(a) {
            a.o && a.M && (a.o.ontimeout = null);
            a.O && (g.v.clearTimeout(a.O), a.O = null)
        },
        Q6 = function(a) {
            return a.o ? a.o.readyState : 0
        },
        S6 = function(a) {
            try {
                return a.o ? a.o.responseText : ""
            } catch (b) {
                return ""
            }
        },
        R6 = function(a, b) {
            return b + " [" + a.ga + " " + a.H + " " + a.getStatus() + "]"
        },
        T6 = function(a, b, c) {
            this.o = 1;
            this.u = [];
            this.A = [];
            this.B = new x6;
            this.G = a || null;
            this.H = null != b ? b : null;
            this.C = c || !1
        },
        cxa = function(a, b) {
            this.o = a;
            this.map = b;
            this.context = null
        },
        dxa = function(a) {
            g.Je.call(this, "statevent", a)
        },
        exa = function(a, b) {
            g.Je.call(this, "timingevent", a);
            this.size = b
        },
        fxa = function(a) {
            g.Je.call(this, "serverreachability", a)
        },
        ixa = function(a) {
            gxa(a);
            if (3 == a.o) {
                var b = a.hm++,
                    c = a.Nn.clone();
                Y5(c, "SID", a.w);
                Y5(c, "RID", b);
                Y5(c, "TYPE", "terminate");
                U6(a, c);
                b = new z6(a, a.w, b, void 0);
                b.Ej = 2;
                b.Og = Z5(c.clone());
                fwa(new Image, b.Og.toString());
                b.vk = (0, g.B)();
                B6(b)
            }
            hxa(a)
        },
        jxa = function(a) {
            a.wE(1, 0);
            a.Nn = L6(a, null, a.Tr);
            V6(a)
        },
        gxa = function(a) {
            a.Sg && (a.Sg.abort(), a.Sg = null);
            a.ac && (a.ac.cancel(), a.ac = null);
            a.Uf && (g.v.clearTimeout(a.Uf), a.Uf = null);
            W6(a);
            a.Hd && (a.Hd.cancel(), a.Hd = null);
            a.Wg && (g.v.clearTimeout(a.Wg), a.Wg = null)
        },
        kxa = function(a, b) {
            if (0 == a.o) throw Error("Invalid operation: sending map when state is closed");
            a.u.push(new cxa(a.CJ++, b));
            2 != a.o && 3 != a.o || V6(a)
        },
        V6 = function(a) {
            a.Hd || a.Wg || (a.Wg = I6((0, g.w)(a.WA, a), 0), a.wj = 0)
        },
        mxa = function(a, b) {
            if (1 == a.o) {
                if (!b) {
                    a.hm = Math.floor(1E5 * Math.random());
                    var c = a.hm++,
                        d = new z6(a, "", c, void 0);
                    d.wi = null;
                    var e = X6(a),
                        f = a.Nn.clone();
                    Y5(f, "RID", c);
                    Y5(f, "CVER", "1");
                    U6(a, f);
                    Lwa(d, f, e);
                    a.Hd = d;
                    a.o = 2
                }
            } else 3 == a.o && (b ? lxa(a, b) : 0 == a.u.length || a.Hd || lxa(a))
        },
        lxa = function(a, b) {
            if (b)
                if (6 < a.fi) {
                    a.u = a.A.concat(a.u);
                    a.A.length = 0;
                    var c = a.hm - 1;
                    var d = X6(a)
                } else c = b.G, d = b.Xi;
            else c = a.hm++, d = X6(a);
            var e = a.Nn.clone();
            Y5(e, "SID", a.w);
            Y5(e, "RID", c);
            Y5(e, "AID", a.Rj);
            U6(a, e);
            c = new z6(a, a.w, c, a.wj + 1);
            c.wi = null;
            c.setTimeout(1E4 + Math.round(1E4 * Math.random()));
            a.Hd = c;
            Lwa(c, e, d)
        },
        U6 = function(a, b) {
            if (a.qd) {
                var c = a.qd.ax();
                c && g.zb(c, function(d, e) {
                    Y5(b, e, d)
                })
            }
        },
        X6 = function(a) {
            var b = Math.min(a.u.length, 1E3),
                c = ["count=" + b];
            if (6 < a.fi && 0 < b) {
                var d = a.u[0].o;
                c.push("ofs=" + d)
            } else d = 0;
            for (var e = 0; e < b; e++) {
                var f = a.u[e].o,
                    k = a.u[e].map;
                f = 6 >= a.fi ? e : f - d;
                try {
                    g.zb(k, function(l, m) {
                        c.push("req" + f + "_" + m + "=" + encodeURIComponent(l))
                    })
                } catch (l) {
                    c.push("req" + f + "_type=" + encodeURIComponent("_badmap"))
                }
            }
            a.A = a.A.concat(a.u.splice(0, b));
            return c.join("&")
        },
        nxa = function(a) {
            a.ac || a.Uf || (a.F = 1, a.Uf = I6((0, g.w)(a.VA, a), 0), a.oj = 0)
        },
        Y6 = function(a) {
            if (a.ac || a.Uf || 3 <= a.oj) return !1;
            a.F++;
            a.Uf = I6((0, g.w)(a.VA, a), oxa(a, a.oj));
            a.oj++;
            return !0
        },
        M6 = function(a, b, c) {
            a.jq = c;
            a.qf = b.mg;
            a.C || jxa(a)
        },
        W6 = function(a) {
            null != a.ki && (g.v.clearTimeout(a.ki), a.ki = null)
        },
        oxa = function(a, b) {
            var c = 5E3 + Math.floor(1E4 * Math.random());
            a.isActive() || (c *= 2);
            return c * b
        },
        Z6 = function(a, b) {
            if (2 == b || 9 == b) {
                var c = null;
                a.qd && (c = null);
                var d = (0, g.w)(a.AO, a);
                c || (c = new g.Pm("//www.google.com/images/cleardot.gif"), Z5(c));
                Swa(c.toString(), 1E4, d)
            } else D6(2);
            pxa(a, b)
        },
        pxa = function(a, b) {
            a.o = 0;
            a.qd && a.qd.pw(b);
            hxa(a);
            gxa(a)
        },
        hxa = function(a) {
            a.o = 0;
            a.qf = -1;
            if (a.qd)
                if (0 == a.A.length && 0 == a.u.length) a.qd.Zq();
                else {
                    g.gb(a.A);
                    var b = g.gb(a.u);
                    a.A.length = 0;
                    a.u.length = 0;
                    a.qd.Zq(b)
                }
        },
        L6 = function(a, b, c) {
            var d = g.Xm(c);
            if ("" != d.o) b && g.Rm(d, b + "." + d.o), g.Sm(d, d.A);
            else {
                var e = window.location;
                d = jwa(e.protocol, b ? b + "." + e.hostname : e.hostname, +e.port, c)
            }
            a.nl && g.zb(a.nl, function(f, k) {
                Y5(d, k, f)
            });
            Y5(d, "VER", a.fi);
            U6(a, d);
            return d
        },
        I6 = function(a, b) {
            if (!g.Ma(a)) throw Error("Fn must not be null and must be a function");
            return g.v.setTimeout(function() {
                a()
            }, b)
        },
        D6 = function(a) {
            $6.dispatchEvent(new dxa($6, a))
        },
        qxa = function() {},
        rxa = function() {
            this.o = [];
            this.u = []
        },
        sxa = function(a, b) {
            this.action = a;
            this.params = b || {}
        },
        a7 = function(a, b) {
            g.y.call(this);
            this.o = new g.H(this.dN, 0, this);
            g.A(this, this.o);
            this.ud = 5E3;
            this.u = 0;
            if (g.Ma(a)) b && (a = (0, g.w)(a, b));
            else if (a && g.Ma(a.handleEvent)) a = (0, g.w)(a.handleEvent, a);
            else throw Error("Invalid listener argument");
            this.w = a
        },
        b7 = function(a, b, c) {
            this.O = a;
            this.C = b;
            this.w = new g.Tn;
            this.u = new a7(this.dO, this);
            this.o = null;
            this.tb = !1;
            this.B = null;
            this.H = "";
            this.G = this.A = 0;
            this.F = [];
            this.M = c || !1
        },
        txa = function(a) {
            return {
                firstTestResults: [""],
                secondTestResults: !a.o.jq,
                sessionId: a.o.w,
                arrayId: a.o.Rj
            }
        },
        uxa = function(a, b) {
            a.G = b || 0;
            a.u.stop();
            a.o && (3 == a.o.o && mxa(a.o), ixa(a.o));
            a.G = 0
        },
        c7 = function(a) {
            return !!a.o && 3 == a.o.o
        },
        vxa = function(a, b) {
            (a.C.loungeIdToken = b) || a.u.stop()
        },
        d7 = function(a) {
            this.port = this.domain = "";
            this.o = "/api/lounge";
            this.u = !0;
            a = a || document.location.href;
            var b = Number(g.nd(4, a)) || "";
            b && (this.port = ":" + b);
            this.domain = g.od(a) || "";
            a = g.Jc;
            0 <= a.search("MSIE") && (a = a.match(/MSIE ([\d.]+)/)[1], 0 > g.qc(a, "10.0") && (this.u = !1))
        },
        e7 = function(a, b) {
            var c = a.o;
            a.u && (c = "https://" + a.domain + a.port + a.o);
            return g.yd(c + b, {})
        },
        f7 = function(a, b, c, d, e) {
            a = {
                format: "JSON",
                method: "POST",
                context: a,
                timeout: 5E3,
                withCredentials: !1,
                onSuccess: g.Qa(a.A, d, !0),
                onError: g.Qa(a.w, e),
                fe: g.Qa(a.B, e)
            };
            c && (a.rb = c, a.headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            });
            return g.sq(b, a)
        },
        zxa = function() {
            var a = wxa;
            xxa();
            g7.push(a);
            yxa(g7)
        },
        h7 = function(a, b) {
            xxa();
            var c = g7,
                d = Axa(a, String(b));
            g.ab(c) ? Bxa(d) : (yxa(c), (0, g.x)(c, function(e) {
                e(d)
            }))
        },
        xxa = function() {
            g7 || (g7 = g.Ha("yt.mdx.remote.debug.handlers_") || [], g.Fa("yt.mdx.remote.debug.handlers_", g7, void 0))
        },
        Bxa = function(a) {
            var b = (i7 + 1) % 50;
            i7 = b;
            j7[b] = a;
            k7 || (k7 = 49 == b)
        },
        yxa = function(a) {
            var b = j7;
            if (b[0]) {
                var c = i7,
                    d = k7 ? c : -1;
                do {
                    d = (d + 1) % 50;
                    var e = b[d];
                    (0, g.x)(a, function(f) {
                        f(e)
                    })
                } while (d != c);
                j7 = Array(50);
                i7 = -1;
                k7 = !1
            }
        },
        Axa = function(a, b) {
            var c = ((0, g.B)() - Cxa) / 1E3;
            c.toFixed && (c = c.toFixed(3));
            var d = [];
            d.push("[", c + "s", "] ");
            d.push("[", "yt.mdx.remote", "] ");
            d.push(a + ": " + b, "\n");
            return d.join("")
        },
        l7 = function(a) {
            g.N.call(this);
            this.F = a;
            this.o = []
        },
        Dxa = function(a, b) {
            var c = a.get(b.uuid) || a.get(b.id);
            if (c) {
                var d = c.name;
                c.id = b.id || c.id;
                c.name = b.name;
                c.token = b.token;
                c.uuid = b.uuid || c.uuid;
                return c.name != d
            }
            a.o.push(b);
            return !0
        },
        Exa = function(a, b) {
            var c = a.o.length != b.length;
            a.o = (0, g.ue)(a.o, function(f) {
                return !!j6(b, f)
            });
            for (var d = 0, e = b.length; d < e; d++) c = Dxa(a, b[d]) || c;
            return c
        },
        Fxa = function(a, b) {
            var c = a.o.length;
            a.o = (0, g.ue)(a.o, function(d) {
                return !(d || b ? !d != !b ? 0 : d.id == b.id : 1)
            });
            return a.o.length < c
        },
        m7 = function(a, b, c, d) {
            g.N.call(this);
            this.C = a;
            this.A = b;
            this.B = c;
            this.w = d;
            this.u = 0;
            this.o = null;
            this.Ia = NaN
        },
        o7 = function(a) {
            l7.call(this, "LocalScreenService");
            this.w = a;
            this.u = NaN;
            n7(this);
            this.info("Initializing with " + h6(this.o))
        },
        Gxa = function(a) {
            if (a.o.length) {
                var b = (0, g.Dc)(a.o, function(d) {
                        return d.id
                    }),
                    c = e7(a.w, "/pairing/get_lounge_token_batch");
                f7(a.w, c, {
                    screen_ids: b.join(",")
                }, (0, g.w)(a.mF, a), (0, g.w)(a.lF, a))
            }
        },
        n7 = function(a) {
            var b = pwa(vwa());
            b = (0, g.ue)(b, function(c) {
                return !c.uuid
            });
            return Exa(a, b)
        },
        p7 = function(a, b) {
            xwa((0, g.Dc)(a.o, nwa));
            b && wwa()
        },
        r7 = function(a, b) {
            g.N.call(this);
            this.C = b;
            var c = g.qs("yt-remote-online-screen-ids") || "";
            c = c ? c.split(",") : [];
            for (var d = {}, e = this.C(), f = 0, k = e.length; f < k; ++f) {
                var l = e[f].id;
                d[l] = g.$a(c, l)
            }
            this.o = d;
            this.B = a;
            this.w = this.A = NaN;
            this.u = null;
            q7("Initialized with " + g.Jk(this.o))
        },
        Hxa = function(a, b, c) {
            var d = e7(a.B, "/pairing/get_screen_availability");
            f7(a.B, d, {
                lounge_token: b.token
            }, (0, g.w)(function(e) {
                e = e.screens || [];
                for (var f = 0, k = e.length; f < k; ++f)
                    if (e[f].loungeToken == b.token) {
                        c("online" == e[f].status);
                        return
                    }
                c(!1)
            }, a), (0, g.w)(function() {
                c(!1)
            }, a))
        },
        s7 = function(a, b) {
            a: if (a6(b) != a6(a.o)) var c = !1;
                else {
                    c = g.Gb(b);
                    for (var d = 0, e = c.length; d < e; ++d)
                        if (!a.o[c[d]]) {
                            c = !1;
                            break a
                        }
                    c = !0
                }c || (q7("Updated online screens: " + g.Jk(a.o)), a.o = b, a.S("screenChange"));Ixa(a)
        },
        t7 = function(a) {
            isNaN(a.w) || g.Jo(a.w);
            a.w = g.Ho((0, g.w)(a.nu, a), 0 < a.A && a.A < (0, g.B)() ? 2E4 : 1E4)
        },
        q7 = function(a) {
            h7("OnlineScreenService", a)
        },
        Jxa = function(a) {
            var b = {};
            (0, g.x)(a.C(), function(c) {
                c.token ? b[c.token] = c.id : this.Tb("Requesting availability of screen w/o lounge token.")
            });
            return b
        },
        Ixa = function(a) {
            a = g.Gb(g.Ab(a.o, function(b) {
                return b
            }));
            g.rb(a);
            a.length ? g.ps("yt-remote-online-screen-ids", a.join(","), 60) : g.rs("yt-remote-online-screen-ids")
        },
        u7 = function(a) {
            l7.call(this, "ScreenService");
            this.C = a;
            this.u = this.w = null;
            this.A = [];
            this.B = {};
            Kxa(this)
        },
        Mxa = function(a, b, c, d, e, f) {
            a.info("getAutomaticScreenByIds " + c + " / " + b);
            c || (c = a.B[b]);
            var k = a.ae();
            if (k = (c ? k6(k, c) : null) || k6(k, b)) {
                k.uuid = b;
                var l = v7(a, k);
                Hxa(a.u, l, function(m) {
                    e(m ? l : null)
                })
            } else c ? Lxa(a, c, (0, g.w)(function(m) {
                var n = v7(this, new e6({
                    name: d,
                    screenId: c,
                    loungeToken: m,
                    dialId: b || ""
                }));
                Hxa(this.u, n, function(q) {
                    e(q ? n : null)
                })
            }, a), f) : e(null)
        },
        Nxa = function(a, b) {
            for (var c = 0, d = a.o.length; c < d; ++c)
                if (a.o[c].name == b) return a.o[c];
            return null
        },
        Lxa = function(a, b, c, d) {
            a.info("requestLoungeToken_ for " + b);
            var e = {
                rb: {
                    screen_ids: b
                },
                method: "POST",
                context: a,
                onSuccess: function(f, k) {
                    var l = k && k.screens || [];
                    l[0] && l[0].screenId == b ? c(l[0].loungeToken) : d(Error("Missing lounge token in token response"))
                },
                onError: function() {
                    d(Error("Request screen lounge token failed"))
                }
            };
            g.sq(e7(a.C, "/pairing/get_lounge_token_batch"), e)
        },
        Oxa = function(a) {
            a.o = a.w.ae();
            var b = a.B,
                c = {},
                d;
            for (d in b) c[b[d]] = d;
            b = 0;
            for (d = a.o.length; b < d; ++b) {
                var e = a.o[b];
                e.uuid = c[e.id] || ""
            }
            a.info("Updated manual screens: " + h6(a.o))
        },
        Kxa = function(a) {
            w7(a);
            a.w = new o7(a.C);
            a.w.subscribe("screenChange", (0, g.w)(a.vF, a));
            Oxa(a);
            a.A = pwa(g.qs("yt-remote-automatic-screen-cache") || []);
            w7(a);
            a.info("Initializing automatic screens: " + h6(a.A));
            a.u = new r7(a.C, (0, g.w)(a.ae, a, !0));
            a.u.subscribe("screenChange", (0, g.w)(function() {
                this.S("onlineScreenChange")
            }, a))
        },
        v7 = function(a, b) {
            var c = a.get(b.id);
            c ? (c.uuid = b.uuid, b = c) : ((c = k6(a.A, b.uuid)) ? (c.id = b.id, c.token = b.token, b = c) : a.A.push(b), g.ps("yt-remote-automatic-screen-cache", (0, g.Dc)(a.A, nwa)));
            w7(a);
            a.B[b.uuid] = b.id;
            g.ps("yt-remote-device-id-map", a.B, 31536E3);
            return b
        },
        w7 = function(a) {
            a.B = g.qs("yt-remote-device-id-map") || {}
        },
        x7 = function(a, b, c) {
            g.N.call(this);
            this.R = c;
            this.H = a;
            this.u = b;
            this.w = null
        },
        y7 = function(a, b) {
            h7(a.R, b)
        },
        z7 = function(a, b) {
            x7.call(this, a, b, "CastSession");
            this.o = null;
            this.A = 0;
            this.C = (0, g.w)(this.jP, this);
            this.B = (0, g.w)(this.AN, this);
            this.A = g.Ho((0, g.w)(function() {
                Pxa(this, null)
            }, this), 12E4)
        },
        Qxa = function(a) {
            a.info("sendYoutubeMessage_: getMdxSessionStatus " + g.Jk(void 0));
            var b = {
                type: "getMdxSessionStatus"
            };
            a.o ? a.o.sendMessage("urn:x-cast:com.google.youtube.mdx", b, g.Ia, (0, g.w)(function() {
                y7(this, "Failed to send message: getMdxSessionStatus.")
            }, a)) : y7(a, "Sending yt message without session: " + g.Jk(b))
        },
        Pxa = function(a, b) {
            g.Jo(a.A);
            if (b) {
                if (a.info("onConnectedScreenId_: Received screenId: " + b), !a.w || a.w.id != b) {
                    var c = (0, g.w)(a.wp, a),
                        d = (0, g.w)(a.ee, a);
                    a.xx(b, c, d, 5)
                }
            } else a.ee(Error("Waiting for session status timed out."))
        },
        A7 = function(a, b, c) {
            x7.call(this, a, b, "DialSession");
            this.A = this.G = null;
            this.O = "";
            this.T = c;
            this.B = null;
            this.F = g.Ia;
            this.C = NaN;
            this.M = (0, g.w)(this.mP, this);
            this.o = g.Ia
        },
        Rxa = function(a) {
            a.o = a.H.RC(a.O, a.u.label, a.u.friendlyName, (0, g.w)(function(b) {
                this.o = g.Ia;
                this.wp(b)
            }, a), (0, g.w)(function(b) {
                this.o = g.Ia;
                this.ee(b)
            }, a))
        },
        Sxa = function(a) {
            var b = {};
            b.pairingCode = a.O;
            b.theme = a.T;
            if (a.B) {
                var c = a.B.currentTime || 0;
                b.v = a.B.videoId;
                b.t = c
            }
            zwa() && (b.env_useStageMdx = 1);
            return g.wd(b)
        },
        B7 = function(a, b) {
            x7.call(this, a, b, "ManualSession");
            this.o = g.Ho((0, g.w)(this.Sj, this, null), 150)
        },
        C7 = function(a, b, c, d) {
            g.N.call(this);
            this.u = a;
            this.F = b || "233637DE";
            this.C = c || "cl";
            this.G = d || !1;
            this.o = null;
            this.B = !1;
            this.w = [];
            this.A = (0, g.w)(this.oM, this)
        },
        Txa = function(a, b) {
            return b ? g.Xa(a.w, function(c) {
                return f6(b, c.label)
            }, a) : null
        },
        D7 = function(a) {
            h7("Controller", a)
        },
        wxa = function(a) {
            window.chrome && chrome.cast && chrome.cast.logMessage && chrome.cast.logMessage(a)
        },
        E7 = function(a) {
            return a.B || !!a.w.length || !!a.o
        },
        F7 = function(a, b, c) {
            b != a.o && (g.He(a.o), (a.o = b) ? (c ? a.S("yt-remote-cast2-receiver-resumed", b.u) : a.S("yt-remote-cast2-receiver-selected",
                b.u), b.subscribe("sessionScreen", (0, g.w)(a.UA, a, b)), b.w ? a.S("yt-remote-cast2-session-change", b.w) : c && a.o.Sj(null)) : a.S("yt-remote-cast2-session-change", null))
        },
        Uxa = function(a) {
            var b = a.u.QC(),
                c = a.o && a.o.u;
            a = (0, g.Dc)(b, function(d) {
                c && f6(d, c.label) && (c = null);
                var e = d.uuid ? d.uuid : d.id,
                    f = Txa(this, d);
                f ? (f.label = e, f.friendlyName = d.name) : (f = new chrome.cast.Receiver(e, d.name), f.receiverType = chrome.cast.ReceiverType.CUSTOM);
                return f
            }, a);
            c && (c.receiverType != chrome.cast.ReceiverType.CUSTOM && (c = new chrome.cast.Receiver(c.label, c.friendlyName), c.receiverType = chrome.cast.ReceiverType.CUSTOM), a.push(c));
            return a
        },
        $xa = function(a, b, c, d, e, f, k) {
            Vxa() ? Wxa(b, e, f, k) && (H7(!0), window.chrome && chrome.cast && chrome.cast.isAvailable ? Xxa(a, c) : (window.__onGCastApiAvailable = function(l, m) {
                    l ? Xxa(a, c) : (I7("Failed to load cast API: " + m), J7(!1), H7(!1), g.rs("yt-remote-cast-available"), g.rs("yt-remote-cast-receiver"), Yxa(), c(!1))
                }, d ? g.To("https://www.gstatic.com/cv/js/sender/v1/cast_sender.js") :
                0 <= window.navigator.userAgent.indexOf("Android") && 0 <= window.navigator.userAgent.indexOf("Chrome/") && window.navigator.presentation ? Gwa() : !window.chrome || !window.navigator.presentation || 0 <= window.navigator.userAgent.indexOf("Edge") ? s6() : (Fwa(), r6(Zxa.map(Dwa))))) : G7("Cannot initialize because not running Chrome")
        },
        Yxa = function() {
            G7("dispose");
            var a = K7();
            a && a.dispose();
            g.Fa("yt.mdx.remote.cloudview.instance_", null, void 0);
            aya(!1);
            g.Po(L7);
            L7.length = 0
        },
        M7 = function() {
            return !!g.qs("yt-remote-cast-installed")
        },
        bya = function() {
            var a = g.qs("yt-remote-cast-receiver");
            return a ? a.friendlyName : null
        },
        cya = function() {
            G7("clearCurrentReceiver");
            g.rs("yt-remote-cast-receiver")
        },
        dya = function() {
            return M7() ? K7() ? K7().getCastSession() : (I7("getCastSelector: Cast is not initialized."), null) : (I7("getCastSelector: Cast API is not installed!"), null)
        },
        O7 = function() {
            M7() ? K7() ? N7() ? (G7("Requesting cast selector."), K7().requestSession()) : (G7("Wait for cast API to be ready to request the session."), L7.push(g.Oo("yt-remote-cast2-api-ready", O7))) : I7("requestCastSelector: Cast is not initialized.") : I7("requestCastSelector: Cast API is not installed!")
        },
        P7 =
        function(a, b) {
            N7() ? K7().setConnectedScreenStatus(a, b) : I7("setConnectedScreenStatus called before ready.")
        },
        Vxa = function() {
            var a = 0 <= g.Jc.search(/ (CrMo|Chrome|CriOS)\//);
            return g.pt || a
        },
        eya = function(a, b) {
            K7().init(a, b)
        },
        Wxa = function(a, b, c, d) {
            var e = !1;
            K7() || (a = new C7(a, b, c, d), a.subscribe("yt-remote-cast2-availability-change", function(f) {
                g.ps("yt-remote-cast-available", f);
                c6("yt-remote-cast2-availability-change", f)
            }), a.subscribe("yt-remote-cast2-receiver-selected", function(f) {
                G7("onReceiverSelected: " + f.friendlyName);
                g.ps("yt-remote-cast-receiver", f);
                c6("yt-remote-cast2-receiver-selected", f)
            }), a.subscribe("yt-remote-cast2-receiver-resumed", function(f) {
                G7("onReceiverResumed: " + f.friendlyName);
                g.ps("yt-remote-cast-receiver", f)
            }), a.subscribe("yt-remote-cast2-session-change", function(f) {
                G7("onSessionChange: " + g6(f));
                f || g.rs("yt-remote-cast-receiver");
                c6("yt-remote-cast2-session-change", f)
            }), g.Fa("yt.mdx.remote.cloudview.instance_", a, void 0), e = !0);
            G7("cloudview.createSingleton_: " + e);
            return e
        },
        K7 = function() {
            return g.Ha("yt.mdx.remote.cloudview.instance_")
        },
        Xxa = function(a, b) {
            J7(!0);
            H7(!1);
            eya(a, function(c) {
                c ? (aya(!0), g.Qo("yt-remote-cast2-api-ready")) : (I7("Failed to initialize cast API."), J7(!1), g.rs("yt-remote-cast-available"), g.rs("yt-remote-cast-receiver"), Yxa());
                b(c)
            })
        },
        G7 = function(a) {
            h7("cloudview", a)
        },
        I7 = function(a) {
            h7("cloudview", a)
        },
        J7 = function(a) {
            G7("setCastInstalled_ " + a);
            g.ps("yt-remote-cast-installed", a)
        },
        N7 = function() {
            return !!g.Ha("yt.mdx.remote.cloudview.apiReady_")
        },
        aya = function(a) {
            G7("setApiReady_ " + a);
            g.Fa("yt.mdx.remote.cloudview.apiReady_", a, void 0)
        },
        H7 = function(a) {
            g.Fa("yt.mdx.remote.cloudview.initializing_", a, void 0)
        },
        Q7 = function(a) {
            this.index = -1;
            this.videoId = this.listId = "";
            this.volume = this.playerState = -1;
            this.muted = !1;
            this.audioTrackId = null;
            this.C = this.F = 0;
            this.o = null;
            this.hasNext = this.O = !1;
            this.H = this.G = this.u = this.B = 0;
            this.A = NaN;
            this.w = !1;
            this.reset(a)
        },
        R7 = function(a) {
            a.audioTrackId = null;
            a.o = null;
            a.playerState = -1;
            a.O = !1;
            a.hasNext = !1;
            a.F = 0;
            a.C = (0, g.B)();
            a.B = 0;
            a.u = 0;
            a.G = 0;
            a.H = 0;
            a.A = NaN;
            a.w = !1
        },
        S7 = function(a) {
            return a.bb() ? ((0, g.B)() - a.C) / 1E3 : 0
        },
        T7 = function(a, b) {
            a.F = b;
            a.C = (0, g.B)()
        },
        U7 = function(a) {
            switch (a.playerState) {
                case 1:
                case 1081:
                    return ((0, g.B)() - a.C) / 1E3 + a.F;
                case -1E3:
                    return 0
            }
            return a.F
        },
        V7 = function(a, b, c) {
            var d = a.videoId;
            a.videoId = b;
            a.index = c;
            b != d && R7(a)
        },
        W7 = function(a) {
            var b = {};
            b.index = a.index;
            b.listId = a.listId;
            b.videoId = a.videoId;
            b.playerState = a.playerState;
            b.volume = a.volume;
            b.muted = a.muted;
            b.audioTrackId = a.audioTrackId;
            b.trackData = g.Qb(a.o);
            b.hasPrevious = a.O;
            b.hasNext = a.hasNext;
            b.playerTime = a.F;
            b.playerTimeAt = a.C;
            b.seekableStart = a.B;
            b.seekableEnd = a.u;
            b.duration = a.G;
            b.loadedTime = a.H;
            b.liveIngestionTime = a.A;
            return b
        },
        Y7 = function(a, b) {
            g.N.call(this);
            this.o = 0;
            this.A = a;
            this.C = [];
            this.B = new rxa;
            this.w = this.u = null;
            this.H = (0, g.w)(this.kK, this);
            this.F = (0, g.w)(this.im, this);
            this.G = (0, g.w)(this.jK, this);
            this.O = (0, g.w)(this.vK, this);
            var c = 0;
            a ? (c = a.getProxyState(), 3 != c && (a.subscribe("proxyStateChange", this.bv, this), fya(this))) : c = 3;
            0 != c && (b ? this.bv(c) : g.Ho((0, g.w)(function() {
                this.bv(c)
            }, this), 0));
            var d = dya();
            d && X7(this, d);
            this.subscribe("yt-remote-cast2-session-change", this.O)
        },
        Z7 = function(a) {
            return new Q7(a.A.getPlayerContextData())
        },
        fya = function(a) {
            (0, g.x)("nowAutoplaying autoplayDismissed remotePlayerChange remoteQueueChange autoplayModeChange autoplayUpNext previousNextChange".split(" "), function(b) {
                this.C.push(this.A.subscribe(b, g.Qa(this.lM, b), this))
            }, a)
        },
        gya = function(a) {
            (0, g.x)(a.C, function(b) {
                this.A.unsubscribeByKey(b)
            }, a);
            a.C.length = 0
        },
        $7 = function(a, b) {
            var c = a.B;
            50 > c.o.length + c.u.length && a.B.u.push(b)
        },
        b8 = function(a, b, c) {
            var d = Z7(a);
            T7(d, c); - 1E3 != d.playerState && (d.playerState = b);
            a8(a, d)
        },
        c8 = function(a, b, c) {
            a.A.sendMessage(b, c)
        },
        a8 = function(a, b) {
            gya(a);
            a.A.setPlayerContextData(W7(b));
            fya(a)
        },
        X7 = function(a, b) {
            a.w && (a.w.removeUpdateListener(a.H), a.w.removeMediaListener(a.F), a.im(null));
            a.w = b;
            a.w && (h7("CP", "Setting cast session: " + a.w.sessionId), a.w.addUpdateListener(a.H), a.w.addMediaListener(a.F), a.w.media.length && a.im(a.w.media[0]))
        },
        hya = function(a) {
            var b = a.u.media,
                c = a.u.customData;
            if (b && c) {
                var d = Z7(a);
                b.contentId != d.videoId && h7("CP", "Cast changing video to: " + b.contentId);
                d.videoId = b.contentId;
                d.playerState = c.playerState;
                T7(d, a.u.getEstimatedTime());
                a8(a, d)
            } else h7("CP", "No cast media video. Ignoring state update.")
        },
        d8 = function(a, b, c) {
            return (0, g.w)(function(d) {
                this.Tb("Failed to " + b + " with cast v2 channel. Error code: " + d.code);
                d.code != chrome.cast.ErrorCode.TIMEOUT && (this.Tb("Retrying " + b + " using MDx browser channel."), c8(this, b, c))
            }, a)
        },
        e8 = function(a, b, c) {
            g.N.call(this);
            this.B = NaN;
            this.M = !1;
            this.G = this.F = this.H = this.O = NaN;
            this.R = [];
            this.A = this.C = this.w = this.Va = this.o = null;
            this.U = a;
            this.R.push(g.dp(window, "beforeunload", (0, g.w)(this.eF, this)));
            this.u = [];
            this.Va = new Q7;
            this.T = b.id;
            this.o = iya(this, c);
            this.o.subscribe("handlerOpened", this.oK, this);
            this.o.subscribe("handlerClosed", this.lK, this);
            this.o.subscribe("handlerError", this.mK, this);
            this.o.subscribe("handlerMessage", this.nK, this);
            vxa(this.o, b.token);
            this.subscribe("remoteQueueChange", function() {
                var d = this.Va.videoId;
                g.ts() && g.ps("yt-remote-session-video-id", d)
            }, this)
        },
        f8 = function(a) {
            h7("conn", a)
        },
        iya = function(a, b) {
            return new b7(e7(a.U, "/bc"), b)
        },
        g8 = function(a, b) {
            a.S("proxyStateChange", b)
        },
        jya = function(a) {
            a.B = g.Ho((0, g.w)(function() {
                f8("Connecting timeout");
                this.uj(1)
            }, a), 2E4)
        },
        h8 = function(a) {
            g.Jo(a.B);
            a.B = NaN
        },
        i8 = function(a) {
            g.Jo(a.O);
            a.O = NaN
        },
        kya = function(a) {
            j8(a);
            a.H = g.Ho((0, g.w)(function() {
                k8(this, "getNowPlaying")
            }, a), 2E4)
        },
        j8 = function(a) {
            g.Jo(a.H);
            a.H = NaN
        },
        mya = function(a, b) {
            b && (h8(a), i8(a));
            b == (c7(a.o) && isNaN(a.B)) ? b && (g8(a, 1), k8(a, "getSubtitlesTrack")) : b ? (a.vx() && a.Va.reset(), g8(a, 1), k8(a, "getNowPlaying"), lya(a)) : a.uj(1)
        },
        nya = function(a, b) {
            var c = b.params.videoId;
            delete b.params.videoId;
            c == a.Va.videoId && (g.Mb(b.params) ? a.Va.o = null : a.Va.o = b.params, a.S("remotePlayerChange"))
        },
        oya = function(a, b) {
            var c = b.params.videoId || b.params.video_id,
                d = parseInt(b.params.currentIndex, 10);
            a.Va.listId = b.params.listId || a.Va.listId;
            V7(a.Va, c, d);
            a.S("remoteQueueChange")
        },
        qya = function(a, b) {
            b.params = b.params || {};
            oya(a, b);
            pya(a, b);
            a.S("autoplayDismissed")
        },
        pya = function(a, b) {
            var c = parseInt(b.params.currentTime || b.params.current_time, 10);
            T7(a.Va, isNaN(c) ? 0 : c);
            c = parseInt(b.params.state, 10);
            c = isNaN(c) ? -1 : c; - 1 == c && -1E3 == a.Va.playerState && (c = -1E3);
            a.Va.playerState = c;
            c = Number(b.params.loadedTime);
            a.Va.H = isNaN(c) ? 0 : c;
            c = Number(b.params.duration);
            a.Va.G = isNaN(c) ? 0 : c;
            c = a.Va;
            var d = Number(b.params.liveIngestionTime);
            c.A = d;
            c.w = isNaN(d) ? !1 : !0;
            c = a.Va;
            d = Number(b.params.seekableStartTime);
            var e = Number(b.params.seekableEndTime);
            c.B = isNaN(d) ? 0 : d;
            c.u = isNaN(e) ? 0 : e;
            1 == a.Va.playerState ? kya(a) : j8(a);
            a.S("remotePlayerChange")
        },
        rya = function(a, b) {
            if (-1E3 !=
                a.Va.playerState) {
                var c = 1085;
                switch (parseInt(b.params.adState, 10)) {
                    case 1:
                        c = 1081;
                        break;
                    case 2:
                        c = 1084;
                        break;
                    case 0:
                        c = 1083
                }
                a.Va.playerState = c;
                c = parseInt(b.params.currentTime, 10);
                T7(a.Va, isNaN(c) ? 0 : c);
                a.S("remotePlayerChange")
            }
        },
        sya = function(a, b) {
            var c = "true" == b.params.muted;
            a.Va.volume = parseInt(b.params.volume, 10);
            a.Va.muted = c;
            a.S("remotePlayerChange")
        },
        tya = function(a, b) {
            a.C = b.params.videoId;
            a.S("nowAutoplaying", parseInt(b.params.timeout, 10))
        },
        uya = function(a, b) {
            var c = "true" == b.params.hasNext;
            a.Va.O = "true" == b.params.hasPrevious;
            a.Va.hasNext = c;
            a.S("previousNextChange")
        },
        lya = function(a) {
            g.Jo(a.G);
            a.G = g.Ho((0, g.w)(a.uj, a, 1), 864E5)
        },
        k8 = function(a, b, c) {
            c ? f8("Sending: action=" + b + ", params=" + g.Jk(c)) : f8("Sending: action=" + b);
            a.o.sendMessage(b, c)
        },
        l8 = function(a) {
            l7.call(this, "ScreenServiceProxy");
            this.td = a;
            this.u = [];
            this.u.push(this.td.$_s("screenChange", (0, g.w)(this.hP, this)));
            this.u.push(this.td.$_s("onlineScreenChange", (0, g.w)(this.NL, this)))
        },
        zya = function(a) {
            var b = {
                device: "Desktop",
                app: "youtube-desktop"
            };
            b = g.K("MDX_CONFIG") || b;
            rwa();
            o6();
            m8 || (m8 = new d7(b ? b.loungeApiHost : void 0), zwa() && (m8.o = "/api/loungedev"));
            n8 || (n8 = g.Ha("yt.mdx.remote.deferredProxies_") || [], g.Fa("yt.mdx.remote.deferredProxies_", n8, void 0));
            vya();
            var c = o8();
            if (!c) {
                var d = new u7(m8);
                g.Fa("yt.mdx.remote.screenService_", d, void 0);
                c = o8();
                var e = !1,
                    f = void 0,
                    k = void 0,
                    l = !1;
                b && (e = !!b.loadCastApiSetupScript, f = b.appId, k = b.theme, l = !!b.disableDial);
                $xa(a, d, function(m) {
                    m ? p8() && P7(p8(), "YouTube TV") : d.subscribe("onlineScreenChange",
                        function() {
                            c6("yt-remote-receiver-availability-change")
                        })
                }, e, f, k, l)
            }
            b && !g.Ha("yt.mdx.remote.initialized_") && (g.Fa("yt.mdx.remote.initialized_", !0, void 0), q8("Initializing: " + g.Jk(b)), r8.push(g.Oo("yt-remote-cast2-availability-change", function() {
                c6("yt-remote-receiver-availability-change")
            })), r8.push(g.Oo("yt-remote-cast2-receiver-selected", function() {
                s8(null);
                c6("yt-remote-auto-connect", "cast-selector-receiver")
            })), r8.push(g.Oo("yt-remote-cast2-receiver-resumed", function() {
                c6("yt-remote-receiver-resumed", "cast-selector-receiver")
            })), r8.push(g.Oo("yt-remote-cast2-session-change", wya)), r8.push(g.Oo("yt-remote-connection-change", function(m) {
                m ? P7(p8(), "YouTube TV") : t8() || (P7(null, null), cya())
            })), a = u8(), b.isAuto && (a.id += "#dial"), g.xo("desktop_enable_autoplay") && (a.capabilities = ["atp"]), a.name = b.device, a.app = b.app, (k = b.theme) && (a.theme = k), q8(" -- with channel params: " +
                g.Jk(a)), xya(a), c.start(), p8() || yya())
        },
        Bya = function() {
            var a = Aya();
            M7() && g.qs("yt-remote-cast-available") && a.push({
                key: "cast-selector-receiver",
                name: "Cast..."
            });
            return a
        },
        Aya = function() {
            var a = o8().td.$_gos();
            var b = v8();
            b && w8() && (j6(a, b) || a.push(b));
            return qwa(a)
        },
        x8 = function() {
            var a = Cya();
            !a && M7() && bya() && (a = {
                key: "cast-selector-receiver",
                name: bya()
            });
            return a
        },
        Cya = function() {
            var a = Aya(),
                b = v8();
            b || (b = t8());
            return g.Xa(a, function(c) {
                return b && f6(b, c.key) ? !0 : !1
            })
        },
        v8 = function() {
            var a = p8();
            if (!a) return null;
            var b = o8().ae();
            return k6(b, a)
        },
        wya = function(a) {
            q8("remote.onCastSessionChange_: " + g6(a));
            if (a) {
                var b = v8();
                b && b.id == a.id ? P7(b.id, "YouTube TV") : (b && y8(), z8(a, 1))
            } else w8() && y8()
        },
        y8 = function() {
            N7() ? K7().stopSession() : I7("stopSession called before API ready.");
            var a = w8();
            a && (a.disconnect(1), A8(null))
        },
        B8 = function() {
            var a = w8();
            return !!a && 3 != a.getProxyState()
        },
        q8 = function(a) {
            h7("remote", a)
        },
        o8 = function() {
            if (!C8) {
                var a = g.Ha("yt.mdx.remote.screenService_");
                C8 = a ? new l8(a) : null
            }
            return C8
        },
        p8 = function() {
            return g.Ha("yt.mdx.remote.currentScreenId_")
        },
        Dya = function(a) {
            g.Fa("yt.mdx.remote.currentScreenId_", a, void 0)
        },
        Eya = function() {
            return g.Ha("yt.mdx.remote.connectData_")
        },
        s8 = function(a) {
            g.Fa("yt.mdx.remote.connectData_", a, void 0)
        },
        w8 = function() {
            return g.Ha("yt.mdx.remote.connection_")
        },
        A8 = function(a) {
            var b = w8();
            s8(null);
            a || Dya("");
            g.Fa("yt.mdx.remote.connection_", a, void 0);
            n8 && ((0, g.x)(n8, function(c) {
                c(a)
            }), n8.length = 0);
            b && !a ? c6("yt-remote-connection-change", !1) : !b && a && c6("yt-remote-connection-change", !0)
        },
        t8 = function() {
            var a = g.ts();
            if (!a) return null;
            var b = o8();
            if (!b) return null;
            b = b.ae();
            return k6(b, a)
        },
        z8 = function(a, b) {
            p8();
            v8() && v8();
            if (D8) E8 = a;
            else {
                Dya(a.id);
                var c = new e8(m8, a, u8());
                c.connect(b, Eya());
                c.subscribe("beforeDisconnect", function(d) {
                    c6("yt-remote-before-disconnect", d)
                });
                c.subscribe("beforeDispose", function() {
                    w8() && (w8(), A8(null))
                });
                A8(c)
            }
        },
        yya = function() {
            var a = t8();
            a ? (q8("Resume connection to: " + g6(a)), z8(a, 0)) : (p6(), cya(), q8("Skipping connecting because no session screen found."))
        },
        vya = function() {
            var a = u8();
            if (g.Mb(a)) {
                a = n6();
                var b = g.qs("yt-remote-session-name") || "",
                    c = g.qs("yt-remote-session-app") || "";
                a = {
                    device: "REMOTE_CONTROL",
                    id: a,
                    name: b,
                    app: c,
                    mdxVersion: 3
                };
                g.Fa("yt.mdx.remote.channelParams_", a, void 0)
            }
        },
        u8 = function() {
            return g.Ha("yt.mdx.remote.channelParams_") || {}
        },
        xya = function(a) {
            a ? (g.ps("yt-remote-session-app", a.app), g.ps("yt-remote-session-name", a.name)) : (g.rs("yt-remote-session-app"), g.rs("yt-remote-session-name"));
            g.Fa("yt.mdx.remote.channelParams_", a, void 0)
        },
        F8 = function(a, b, c) {
            g.y.call(this);
            this.B = a;
            this.u = b;
            this.w = new g.tr(this);
            g.A(this, this.w);
            this.w.L(b, "onCaptionsTrackListChanged", this.jL);
            this.w.L(b, "captionschanged", this.iK);
            this.w.L(b, "captionssettingschanged", this.eC);
            this.w.L(b, "videoplayerreset", this.xp);
            this.w.L(b, "mdxautoplaycancel", this.YD);
            this.T = this.w.L(b, "onVolumeChange", this.uA);
            this.G = !1;
            this.o = c;
            c.fa();
            c.subscribe("proxyStateChange", this.OA, this);
            c.subscribe("remotePlayerChange", this.mm, this);
            c.subscribe("remoteQueueChange", this.xp, this);
            c.subscribe("autoplayUpNext",
                this.fA, this);
            c.subscribe("previousNextChange", this.KA, this);
            c.subscribe("nowAutoplaying", this.GA, this);
            c.subscribe("autoplayDismissed", this.eA, this);
            this.suggestion = null;
            this.H = new g.wC(64);
            this.A = new g.H(this.cC, 500, this);
            g.A(this, this.A);
            this.C = new g.H(this.dC, 1E3, this);
            g.A(this, this.C);
            this.M = new t6(this.JO, 0, this);
            g.A(this, this.M);
            this.F = {};
            this.R = new g.H(this.DC, 1E3, this);
            g.A(this, this.R);
            this.O = new u6(this.zI, 1E3, this);
            g.A(this, this.O);
            this.U = g.Ia;
            this.eC();
            this.xp();
            this.mm()
        },
        G8 = function(a,
            b) {
            var c = a.B,
                d = a.u.getVideoData().lengthSeconds;
            c.U = b || 0;
            c.player.S("progresssync", b, d)
        },
        Fya = function(a) {
            G8(a, 0);
            a.A.stop();
            H8(a, new g.wC(64))
        },
        J8 = function(a, b) {
            if (I8(a) && !a.G) {
                var c = null;
                b && (c = {
                    style: a.u.getSubtitlesUserSettings()
                }, g.Sb(c, b));
                a.o.UB(a.u.getVideoData(1).videoId, c);
                a.F = Z7(a.o).o
            }
        },
        K8 = function(a, b) {
            var c = a.u.getPlaylist();
            if (c) {
                var d = c.index;
                var e = c.listId.toString()
            }
            c = a.u.getVideoData(1);
            a.o.playVideo(c.videoId, b, d, e, c.playerParams, c.sf, dwa(c));
            H8(a, new g.wC(1))
        },
        Gya = function(a, b) {
            if (b) {
                var c = a.u.getOption("captions", "tracklist", {
                    Vx: 1
                });
                c && c.length ? (a.u.setOption("captions", "track", b), a.G = !1) : (a.u.loadModule("captions"), a.G = !0)
            } else a.u.setOption("captions", "track", {})
        },
        I8 = function(a) {
            return Z7(a.o).videoId == a.u.getVideoData(1).videoId
        },
        H8 = function(a, b) {
            a.C.stop();
            var c = a.H;
            if (!g.CC(c, b)) {
                var d = g.U(b, 2);
                d != g.U(a.H, 2) && g.LS(a.u.app, d);
                a.H = b;
                Hya(a.B, c, b)
            }
        },
        L8 = function(a) {
            g.Q.call(this, {
                D: "div",
                I: "ytp-remote",
                K: [{
                    D: "div",
                    I: "ytp-remote-display-status",
                    K: [{
                        D: "div",
                        I: "ytp-remote-display-status-icon",
                        K: [g.BM()]
                    }, {
                        D: "div",
                        I: "ytp-remote-display-status-text",
                        W: "{{statustext}}"
                    }]
                }]
            });
            this.u = new g.fN(this, 250);
            g.A(this, this.u);
            this.w = a;
            this.L(a, "presentingplayerstatechange", this.A);
            Iya(this, g.RK(a))
        },
        Iya = function(a, b) {
            if (3 == a.w.getPresentingPlayerType()) {
                var c = {
                    RECEIVER_NAME: a.w.getOption("remote", "currentReceiver").name
                };
                c = g.U(b, 128) ? g.iM("Error on $RECEIVER_NAME", c) : b.bb() || g.U(b, 4) ? g.iM("Playing on $RECEIVER_NAME", c) : g.iM("Connected to $RECEIVER_NAME", c);
                a.ma("statustext", c);
                a.u.show()
            } else a.u.hide()
        },
        M8 = function() {
            g.Q.call(this, {
                D: "div",
                I: "ytp-mdx-manual-pairing-popup-dialog",
                P: {
                    role: "dialog"
                },
                K: [{
                    D: "div",
                    I: "ytp-mdx-manual-pairing-popup-dialog-inner-content",
                    K: [{
                        D: "div",
                        I: "ytp-mdx-manual-pairing-popup-title",
                        W: "Connecting to your TV on web using a code will be going away soon"
                    }, {
                        D: "div",
                        I: "ytp-mdx-manual-pairing-popup-buttons",
                        K: [{
                            D: "button",
                            Y: ["ytp-button", "ytp-mdx-manual-pairing-popup-learn-more"],
                            W: "Learn more"
                        }, {
                            D: "button",
                            Y: ["ytp-button", "ytp-mdx-manual-pairing-popup-ok"],
                            W: "OK"
                        }]
                    }]
                }]
            });
            this.u = new g.fN(this, 250);
            this.learnMoreButton =
                this.o["ytp-mdx-manual-pairing-popup-learn-more"];
            this.okButton = this.o["ytp-mdx-manual-pairing-popup-ok"];
            g.A(this, this.u);
            this.L(this.learnMoreButton, "click", this.w);
            this.L(this.okButton, "click", this.A)
        },
        N8 = function() {
            g.Q.call(this, {
                D: "div",
                I: "ytp-mdx-popup-dialog",
                P: {
                    role: "dialog"
                },
                K: [{
                    D: "div",
                    I: "ytp-mdx-popup-dialog-inner-content",
                    K: [{
                        D: "div",
                        I: "ytp-mdx-popup-title",
                        W: "You're signed out"
                    }, {
                        D: "div",
                        I: "ytp-mdx-popup-description",
                        W: "Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer."
                    }, {
                        D: "div",
                        I: "ytp-mdx-privacy-popup-buttons",
                        K: [{
                            D: "button",
                            Y: ["ytp-button", "ytp-mdx-privacy-popup-cancel"],
                            W: "Cancel"
                        }, {
                            D: "button",
                            Y: ["ytp-button", "ytp-mdx-privacy-popup-confirm"],
                            W: "Confirm"
                        }]
                    }]
                }]
            });
            this.u = new g.fN(this, 250);
            this.cancelButton = this.o["ytp-mdx-privacy-popup-cancel"];
            this.confirmButton = this.o["ytp-mdx-privacy-popup-confirm"];
            g.A(this, this.u);
            this.L(this.cancelButton, "click", this.w);
            this.L(this.confirmButton, "click", this.A)
        },
        O8 = function(a, b) {
            g.cO.call(this, "Play on", 0, a, b);
            this.J = a;
            this.C = {};
            this.L(a, "onMdxReceiversChange", this.G);
            this.L(a, "presentingplayerstatechange", this.G);
            this.G()
        },
        P8 = function(a) {
            g.xL.call(this, a);
            this.u = {
                key: i6(),
                name: "This computer"
            };
            this.C = null;
            this.w = [];
            this.aa = this.o = null;
            this.T = [this.u];
            this.A = this.u;
            this.H = new g.wC(64);
            this.U = 0;
            this.M = -1;
            this.F = null;
            this.O = this.R = !1;
            this.G = null;
            if (!g.Py(this.player.N())) {
                a = this.player;
                var b = g.TB(a);
                b && (b = b.Yl()) && (b = new O8(a, b), g.A(this, b));
                b = new L8(a);
                g.A(this, b);
                g.kL(a, b.element, 4);
                this.G = new N8;
                g.A(this, this.G);
                g.kL(a, this.G.element, 4);
                g.O(this.player.N().experiments, "pair_servlet_deprecation_warning_enabled") && (this.F = new M8, g.A(this, this.F), g.kL(a,
                    this.F.element, 4));
                this.O = !!t8();
                this.R = !!g.qs("yt-remote-manual-pairing-warning-shown")
            }
            this.B = null
        },
        Q8 = function(a) {
            a.B && (a.player.removeEventListener("presentingplayerstatechange", a.B), a.B = null)
        },
        Hya = function(a, b, c) {
            a.H = c;
            a.player.S("presentingplayerstatechange", new g.PG(c, b))
        },
        Jya = function(a, b, c) {
            var d = !1;
            1 == b ? d = !a.O : 2 == b && (d = !a.R);
            d && g.RG(c, 8) && (a.player.pauseVideo(), Q8(a))
        },
        R8 = function(a, b) {
            if (b.key != a.A.key)
                if (b.key == a.u.key) y8();
                else {
                    if (a.F && !a.R && b != a.u && "cast-selector-receiver" != b.key && g.Yy(a.player.N())) Kya(a);
                    else {
                        var c;
                        (c = !g.O(a.player.N().experiments, "mdx_enable_privacy_disclosure_ui")) || (c = ((c = g.K("PLAYER_CONFIG")) && c.args && void 0 !== c.args.authuser ? !0 : !(!g.K("SESSION_INDEX") && !g.K("LOGGED_IN"))) || a.O || !a.G);
                        (c ? 0 : g.Yy(a.player.N()) || g.bz(a.player.N())) && Lya(a)
                    }
                    a.A = b;
                    var d = a.player.getPlaylistId();
                    c = a.player.getVideoData(1);
                    var e = c.videoId;
                    if (!d && !e || (2 == a.player.getAppState() || 1 == a.player.getAppState()) && g.O(a.player.N().experiments,
                            "should_clear_video_data_on_player_cued_unstarted")) c = null;
                    else {
                        var f = a.player.getPlaylist();
                        if (f) {
                            var k = [];
                            for (var l = 0; l < f.getLength(); l++) k[l] = f.Ba(l).videoId
                        } else k = [e];
                        f = a.player.getCurrentTime(1);
                        d = {
                            videoIds: k,
                            listId: d,
                            videoId: e,
                            playerParams: c.playerParams,
                            clickTrackingParams: c.sf,
                            index: Math.max(a.player.getPlaylistIndex(), 0),
                            currentTime: 0 == f ? void 0 : f
                        };
                        (c = dwa(c)) && (d.locationInfo = c);
                        c = d
                    }
                    q8("Connecting to: " + g.Jk(b));
                    "cast-selector-receiver" == b.key ? (s8(c || null), c = c || null, N7() ? K7().setLaunchParams(c) :
                        I7("setLaunchParams called before ready.")) : !c && B8() && p8() == b.key ? c6("yt-remote-connection-change", !0) : (y8(), s8(c || null), c = o8().ae(), (c = k6(c, b.key)) && z8(c, 1))
                }
        },
        Lya = function(a) {
            g.RK(a.player).bb() ? a.player.pauseVideo() : (a.B = function(b) {
                return Jya(a, 1, b)
            }, a.player.addEventListener("presentingplayerstatechange", a.B));
            a.G && a.G.Pb();
            w8() || (D8 = !0)
        },
        Kya = function(a) {
            g.RK(a.player).bb() ? a.player.pauseVideo() : (a.B = function(b) {
                return Jya(a, 2, b)
            }, a.player.addEventListener("presentingplayerstatechange", a.B));
            a.F && a.F.Pb();
            w8() || (D8 = !0)
        },
        Pwa = {
            "\x00": "\\0",
            "\b": "\\b",
            "\f": "\\f",
            "\n": "\\n",
            "\r": "\\r",
            "\t": "\\t",
            "\x0B": "\\x0B",
            '"': '\\"',
            "\\": "\\\\",
            "<": "\\u003C"
        },
        H6 = {
            "'": "\\'"
        },
        Mya = {},
        mwa = {
            KP: "atp",
            xS: "ska",
            iS: "que",
            BR: "mus",
            wS: "sus",
            MQ: "dsp",
            qS: "seq"
        },
        q6, m6 = "",
        Ewa = Awa("loadCastFramework") || Awa("loadCastApplicationFramework"),
        Zxa = ["pkedcjkdefgpdelpbcmbmeomcjbeemfm", "enhhojjnijigcajfphajepfemndkmdlo"];
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    g.Sa(t6, g.y);
    g.h = t6.prototype;
    g.h.aF = function(a) {
        this.A = arguments;
        this.o = !1;
        this.Ia ? this.w = (0, g.B)() + this.ud : this.Ia = g.Uf(this.B, this.ud)
    };
    g.h.stop = function() {
        this.Ia && (g.v.clearTimeout(this.Ia), this.Ia = null);
        this.w = null;
        this.o = !1;
        this.A = []
    };
    g.h.pause = function() {
        ++this.u
    };
    g.h.resume = function() {
        this.u && (--this.u, !this.u && this.o && (this.o = !1, this.C.apply(null, this.A)))
    };
    g.h.X = function() {
        this.stop();
        t6.Db.X.call(this)
    };
    g.h.bF = function() {
        this.w ? (this.Ia = g.Uf(this.B, this.w - (0, g.B)()), this.w = null) : (this.Ia = null, this.u ? this.o = !0 : (this.o = !1, this.C.apply(null, this.A)))
    };
    g.Sa(u6, g.y);
    g.h = u6.prototype;
    g.h.Dj = !1;
    g.h.xl = 0;
    g.h.Ia = null;
    g.h.Ex = function(a) {
        this.o = arguments;
        this.Ia || this.xl ? this.Dj = !0 : v6(this)
    };
    g.h.stop = function() {
        this.Ia && (g.v.clearTimeout(this.Ia), this.Ia = null, this.Dj = !1, this.o = [])
    };
    g.h.pause = function() {
        this.xl++
    };
    g.h.resume = function() {
        this.xl--;
        this.xl || !this.Dj || this.Ia || (this.Dj = !1, v6(this))
    };
    g.h.X = function() {
        u6.Db.X.call(this);
        this.stop()
    };
    g.h.cF = function() {
        this.Ia = null;
        this.Dj && !this.xl && (this.Dj = !1, v6(this))
    };
    x6.prototype.stringify = function(a) {
        return g.v.JSON.stringify(a, void 0)
    };
    x6.prototype.parse = function(a) {
        return g.v.JSON.parse(a, void 0)
    };
    y6.prototype.o = null;
    y6.prototype.getOptions = function() {
        var a;
        (a = this.o) || (a = {}, Iwa(this) && (a[0] = !0, a[1] = !0), a = this.o = a);
        return a
    };
    var S8;
    g.Sa(Hwa, y6);
    S8 = new Hwa;
    g.h = z6.prototype;
    g.h.wi = null;
    g.h.Ye = !1;
    g.h.Jk = null;
    g.h.Yu = null;
    g.h.vk = null;
    g.h.Ej = null;
    g.h.Og = null;
    g.h.Mh = null;
    g.h.Xi = null;
    g.h.Hc = null;
    g.h.Mm = 0;
    g.h.cf = null;
    g.h.lq = null;
    g.h.fh = null;
    g.h.zl = -1;
    g.h.PB = !0;
    g.h.di = !1;
    g.h.Wr = 0;
    g.h.Ep = null;
    var Nwa = {},
        C6 = {};
    g.h = z6.prototype;
    g.h.setTimeout = function(a) {
        this.B = a
    };
    g.h.PN = function(a) {
        a = a.target;
        var b = this.Ep;
        b && 3 == Q6(a) ? b.Ex() : this.LC(a)
    };
    g.h.LC = function(a) {
        try {
            if (a == this.Hc) a: {
                var b = Q6(this.Hc),
                    c = this.Hc.C,
                    d = this.Hc.getStatus();
                if (g.he && !g.Ld(10) || g.je && !g.Kd("420+")) {
                    if (4 > b) break a
                } else if (3 > b || 3 == b && !g.vh && !S6(this.Hc)) break a;this.di || 4 != b || 7 == c || (8 == c || 0 >= d ? this.o.We(3) : this.o.We(2));J6(this);
                var e = this.Hc.getStatus();this.zl = e;
                var f = S6(this.Hc);
                (this.Ye = 200 == e) ? (4 == b && F6(this), this.C ? (Owa(this, b, f), g.vh && this.Ye && 3 == b && (this.A.la(this.u, "tick", this.HN), this.u.start())) : E6(this, f), this.Ye && !this.di && (4 == b ? this.o.bo(this) : (this.Ye = !1, B6(this)))) : (400 == e && 0 < f.indexOf("Unknown SID") ? (this.fh = 3, D6(13)) : (this.fh = 0, D6(14)), F6(this), G6(this))
            }
        } catch (k) {
            this.Hc && S6(this.Hc)
        } finally {}
    };
    g.h.HN = function() {
        var a = Q6(this.Hc),
            b = S6(this.Hc);
        this.Mm < b.length && (J6(this), Owa(this, a, b), this.Ye && 4 != a && B6(this))
    };
    g.h.kN = function(a) {
        I6((0, g.w)(this.jN, this, a), 0)
    };
    g.h.jN = function(a) {
        this.di || (J6(this), E6(this, a), B6(this))
    };
    g.h.XA = function(a) {
        I6((0, g.w)(this.iN, this, a), 0)
    };
    g.h.iN = function(a) {
        this.di || (F6(this), this.Ye = a, this.o.bo(this), this.o.We(4))
    };
    g.h.cancel = function() {
        this.di = !0;
        F6(this)
    };
    g.h.sN = function() {
        this.Jk = null;
        var a = (0, g.B)();
        0 <= a - this.Yu ? (2 != this.Ej && this.o.We(3), F6(this), this.fh = 2, D6(18), G6(this)) : Rwa(this, this.Yu - a)
    };
    g.h.getLastError = function() {
        return this.fh
    };
    g.h = Uwa.prototype;
    g.h.Ur = null;
    g.h.Od = null;
    g.h.Fp = !1;
    g.h.Gx = null;
    g.h.Kn = null;
    g.h.Hs = null;
    g.h.Vr = null;
    g.h.qe = null;
    g.h.mg = -1;
    g.h.yl = null;
    g.h.Tk = null;
    g.h.connect = function(a) {
        this.Vr = a;
        a = L6(this.o, null, this.Vr);
        D6(3);
        this.Gx = (0, g.B)();
        var b = this.o.G;
        null != b ? (this.yl = b[0], (this.Tk = b[1]) ? (this.qe = 1, Vwa(this)) : (this.qe = 2, N6(this))) : ($5(a, "MODE", "init"), this.Od = new z6(this, void 0, void 0, void 0), this.Od.wi = this.Ur, A6(this.Od, a, !1, null, !0), this.qe = 0)
    };
    g.h.ZD = function(a) {
        if (a) this.qe = 2, N6(this);
        else {
            D6(4);
            var b = this.o;
            b.qf = b.Sg.mg;
            Z6(b, 9)
        }
        a && this.We(2)
    };
    g.h.kr = function(a) {
        return this.o.kr(a)
    };
    g.h.abort = function() {
        this.Od && (this.Od.cancel(), this.Od = null);
        this.mg = -1
    };
    g.h.Fx = function() {
        return !1
    };
    g.h.PA = function(a, b) {
        this.mg = a.zl;
        if (0 == this.qe)
            if (b) {
                try {
                    var c = this.u.parse(b)
                } catch (d) {
                    c = this.o;
                    c.qf = this.mg;
                    Z6(c, 2);
                    return
                }
                this.yl = c[0];
                this.Tk = c[1]
            } else c = this.o, c.qf = this.mg, Z6(c, 2);
        else if (2 == this.qe)
            if (this.Fp) D6(7), this.Hs = (0, g.B)();
            else if ("11111" == b) {
            if (D6(6), this.Fp = !0, this.Kn = (0, g.B)(), c = this.Kn - this.Gx, !g.he || g.Ld(10) || 500 > c) this.mg = 200, this.Od.cancel(), D6(12), M6(this.o, this, !0)
        } else D6(8), this.Kn = this.Hs = (0, g.B)(), this.Fp = !1
    };
    g.h.bo = function() {
        this.mg = this.Od.zl;
        if (this.Od.Ye) 0 == this.qe ? this.Tk ? (this.qe = 1, Vwa(this)) : (this.qe = 2, N6(this)) : 2 == this.qe && ((!g.he || g.Ld(10) ? !this.Fp : 200 > this.Hs - this.Kn) ? (D6(11), M6(this.o, this, !1)) : (D6(12), M6(this.o, this, !0)));
        else {
            0 == this.qe ? D6(9) : 2 == this.qe && D6(10);
            var a = this.o;
            this.Od.getLastError();
            a.qf = this.mg;
            Z6(a, 2)
        }
    };
    g.h.Cm = function() {
        return this.o.Cm()
    };
    g.h.isActive = function() {
        return this.o.isActive()
    };
    g.h.We = function(a) {
        this.o.We(a)
    };
    g.Sa(O6, g.gf);
    var $wa = /^https?$/i,
        Nya = ["POST", "PUT"];
    g.h = O6.prototype;
    g.h.send = function(a, b, c, d) {
        if (this.o) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.H + "; newUri=" + a);
        b = b ? b.toUpperCase() : "GET";
        this.H = a;
        this.A = "";
        this.C = 0;
        this.ga = b;
        this.U = !1;
        this.w = !0;
        this.o = this.T ? Jwa(this.T) : Jwa(S8);
        this.R = this.T ? this.T.getOptions() : S8.getOptions();
        this.o.onreadystatechange = (0, g.w)(this.LA, this);
        try {
            b6(R6(this, "Opening Xhr")), this.Z = !0, this.o.open(b, String(a), !0), this.Z = !1
        } catch (f) {
            b6(R6(this, "Error opening Xhr: " + f.message));
            Zwa(this, f);
            return
        }
        a = c ||
            "";
        var e = this.headers.clone();
        d && iwa(d, function(f, k) {
            e.set(k, f)
        });
        d = g.Xa(e.ne(), Xwa);
        c = g.v.FormData && a instanceof g.v.FormData;
        !g.$a(Nya, b) || d || c || e.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        e.forEach(function(f, k) {
            this.o.setRequestHeader(k, f)
        }, this);
        this.da && (this.o.responseType = this.da);
        "withCredentials" in this.o && this.o.withCredentials !== this.aa && (this.o.withCredentials = this.aa);
        try {
            bxa(this), 0 < this.F && (this.M = Wwa(this.o), b6(R6(this, "Will abort after " + this.F + "ms if incomplete, xhr2 " + this.M)), this.M ? (this.o.timeout = this.F, this.o.ontimeout = (0, g.w)(this.Hx, this)) : this.O = g.Uf(this.Hx, this.F, this)), b6(R6(this, "Sending request")), this.G = !0, this.o.send(a), this.G = !1
        } catch (f) {
            b6(R6(this, "Send error: " + f.message)), Zwa(this, f)
        }
    };
    g.h.Hx = function() {
        "undefined" != typeof g.E1 && this.o && (this.A = "Timed out after " + this.F + "ms, aborting", this.C = 8, R6(this, this.A), this.dispatchEvent("timeout"), this.abort(8))
    };
    g.h.abort = function(a) {
        this.o && this.w && (R6(this, "Aborting"), this.w = !1, this.B = !0, this.o.abort(), this.B = !1, this.C = a || 7, this.dispatchEvent("complete"), this.dispatchEvent("abort"), P6(this))
    };
    g.h.X = function() {
        this.o && (this.w && (this.w = !1, this.B = !0, this.o.abort(), this.B = !1), P6(this, !0));
        O6.Db.X.call(this)
    };
    g.h.LA = function() {
        this.fa() || (this.Z || this.G || this.B ? axa(this) : this.nM())
    };
    g.h.nM = function() {
        axa(this)
    };
    g.h.isActive = function() {
        return !!this.o
    };
    g.h.getStatus = function() {
        try {
            return 2 < Q6(this) ? this.o.status : -1
        } catch (a) {
            return -1
        }
    };
    g.h.getLastError = function() {
        return "string" === typeof this.A ? this.A : String(this.A)
    };
    g.h = T6.prototype;
    g.h.nl = null;
    g.h.Hd = null;
    g.h.ac = null;
    g.h.Tr = null;
    g.h.Nn = null;
    g.h.cw = null;
    g.h.ao = null;
    g.h.hm = 0;
    g.h.CJ = 0;
    g.h.qd = null;
    g.h.Wg = null;
    g.h.Uf = null;
    g.h.ki = null;
    g.h.Sg = null;
    g.h.jq = null;
    g.h.Rj = -1;
    g.h.ny = -1;
    g.h.qf = -1;
    g.h.wj = 0;
    g.h.oj = 0;
    g.h.fi = 8;
    var $6 = new g.gf;
    g.Sa(dxa, g.Je);
    g.Sa(exa, g.Je);
    g.Sa(fxa, g.Je);
    g.h = T6.prototype;
    g.h.connect = function(a, b, c, d, e) {
        D6(0);
        this.Tr = b;
        this.nl = c || {};
        d && void 0 !== e && (this.nl.OSID = d, this.nl.OAID = e);
        this.C ? (I6((0, g.w)(this.xw, this, a), 100), jxa(this)) : this.xw(a)
    };
    g.h.xw = function(a) {
        this.Sg = new Uwa(this);
        this.Sg.Ur = null;
        this.Sg.u = this.B;
        this.Sg.connect(a)
    };
    g.h.Fx = function() {
        return 0 == this.o
    };
    g.h.WA = function(a) {
        this.Wg = null;
        mxa(this, a)
    };
    g.h.VA = function() {
        this.Uf = null;
        this.ac = new z6(this, this.w, "rpc", this.F);
        this.ac.wi = null;
        this.ac.Wr = 0;
        var a = this.cw.clone();
        Y5(a, "RID", "rpc");
        Y5(a, "SID", this.w);
        Y5(a, "CI", this.jq ? "0" : "1");
        Y5(a, "AID", this.Rj);
        U6(this, a);
        if (!g.he || g.Ld(10)) Y5(a, "TYPE", "xmlhttp"), A6(this.ac, a, !0, this.ao, !1);
        else {
            Y5(a, "TYPE", "html");
            var b = this.ac,
                c = !!this.ao;
            b.Ej = 3;
            b.Og = Z5(a.clone());
            Qwa(b, c)
        }
    };
    g.h.PA = function(a, b) {
        if (0 != this.o && (this.ac == a || this.Hd == a))
            if (this.qf = a.zl, this.Hd == a && 3 == this.o)
                if (7 < this.fi) {
                    try {
                        var c = this.B.parse(b)
                    } catch (f) {
                        c = null
                    }
                    if (Array.isArray(c) && 3 == c.length)
                        if (0 == c[0]) a: {
                            if (!this.Uf) {
                                if (this.ac)
                                    if (this.ac.vk + 3E3 < this.Hd.vk) W6(this), this.ac.cancel(), this.ac = null;
                                    else break a;
                                Y6(this);
                                D6(19)
                            }
                        }
                    else this.ny = c[1], 0 < this.ny - this.Rj && 37500 > c[2] && this.jq && 0 == this.oj && !this.ki && (this.ki = I6((0, g.w)(this.eK, this), 6E3));
                    else Z6(this, 11)
                } else b != Mya.hQ.o && Z6(this, 11);
        else if (this.ac ==
            a && W6(this), !g.fc(b)) {
            c = this.B.parse(b);
            for (var d = 0; d < c.length; d++) {
                var e = c[d];
                this.Rj = e[0];
                e = e[1];
                2 == this.o ? "c" == e[0] ? (this.w = e[1], this.ao = e[2], e = e[3], null != e ? this.fi = e : this.fi = 6, this.o = 3, this.qd && this.qd.rw(), this.cw = L6(this, this.Cm() ? this.ao : null, this.Tr), nxa(this)) : "stop" == e[0] && Z6(this, 7) : 3 == this.o && ("stop" == e[0] ? Z6(this, 7) : "noop" != e[0] && this.qd && this.qd.qw(e), this.oj = 0)
            }
        }
    };
    g.h.eK = function() {
        null != this.ki && (this.ki = null, this.ac.cancel(), this.ac = null, Y6(this), D6(20))
    };
    g.h.bo = function(a) {
        if (this.ac == a) {
            W6(this);
            this.ac = null;
            var b = 2
        } else if (this.Hd == a) this.Hd = null, b = 1;
        else return;
        this.qf = a.zl;
        if (0 != this.o)
            if (a.Ye) 1 == b ? (b = (0, g.B)() - a.vk, $6.dispatchEvent(new exa($6, a.Xi ? a.Xi.length : 0, b, this.wj)), V6(this), this.A.length = 0) : nxa(this);
            else {
                var c = a.getLastError(),
                    d;
                if (!(d = 3 == c || 7 == c || 0 == c && 0 < this.qf)) {
                    if (d = 1 == b) this.Hd || this.Wg || 1 == this.o || 2 <= this.wj ? d = !1 : (this.Wg = I6((0, g.w)(this.WA, this, a), oxa(this, this.wj)), this.wj++, d = !0);
                    d = !(d || 2 == b && Y6(this))
                }
                if (d) switch (c) {
                    case 1:
                        Z6(this,
                            5);
                        break;
                    case 4:
                        Z6(this, 10);
                        break;
                    case 3:
                        Z6(this, 6);
                        break;
                    case 7:
                        Z6(this, 12);
                        break;
                    default:
                        Z6(this, 2)
                }
            }
    };
    g.h.wE = function(a) {
        if (!g.$a(arguments, this.o)) throw Error("Unexpected channel state: " + this.o);
    };
    g.h.AO = function(a) {
        a ? D6(2) : (D6(1), pxa(this, 8))
    };
    g.h.kr = function(a) {
        if (a) throw Error("Can't create secondary domain capable XhrIo object.");
        a = new O6;
        a.aa = !1;
        return a
    };
    g.h.isActive = function() {
        return !!this.qd && this.qd.isActive(this)
    };
    g.h.We = function(a) {
        $6.dispatchEvent(new fxa($6, a))
    };
    g.h.Cm = function() {
        return !(!g.he || g.Ld(10))
    };
    g.h = qxa.prototype;
    g.h.rw = function() {};
    g.h.qw = function() {};
    g.h.pw = function() {};
    g.h.Zq = function() {};
    g.h.ax = function() {
        return {}
    };
    g.h.isActive = function() {
        return !0
    };
    g.h = rxa.prototype;
    g.h.isEmpty = function() {
        return g.ab(this.o) && g.ab(this.u)
    };
    g.h.clear = function() {
        this.o = [];
        this.u = []
    };
    g.h.contains = function(a) {
        return g.$a(this.o, a) || g.$a(this.u, a)
    };
    g.h.remove = function(a) {
        var b = this.o;
        var c = (0, g.$qa)(b, a);
        0 <= c ? (g.cb(b, c), b = !0) : b = !1;
        return b || g.db(this.u, a)
    };
    g.h.zd = function() {
        for (var a = [], b = this.o.length - 1; 0 <= b; --b) a.push(this.o[b]);
        var c = this.u.length;
        for (b = 0; b < c; ++b) a.push(this.u[b]);
        return a
    };
    g.Sa(a7, g.y);
    g.h = a7.prototype;
    g.h.dN = function() {
        this.ud = Math.min(3E5, 2 * this.ud);
        this.w();
        this.u && this.start()
    };
    g.h.start = function() {
        var a = this.ud + 15E3 * Math.random();
        this.o.Ua(a);
        this.u = (0, g.B)() + a
    };
    g.h.stop = function() {
        this.o.stop();
        this.u = 0
    };
    g.h.isActive = function() {
        return this.o.isActive()
    };
    g.h.reset = function() {
        this.o.stop();
        this.ud = 5E3
    };
    g.Sa(b7, qxa);
    g.h = b7.prototype;
    g.h.subscribe = function(a, b, c) {
        return this.w.subscribe(a, b, c)
    };
    g.h.unsubscribe = function(a, b, c) {
        return this.w.unsubscribe(a, b, c)
    };
    g.h.Bh = function(a) {
        return this.w.xi(a)
    };
    g.h.S = function(a, b) {
        return this.w.S.apply(this.w, arguments)
    };
    g.h.dispose = function() {
        this.tb || (this.tb = !0, g.He(this.w), uxa(this), g.He(this.u), this.u = null)
    };
    g.h.fa = function() {
        return this.tb
    };
    g.h.connect = function(a, b, c) {
        if (!this.o || 2 != this.o.o) {
            this.H = "";
            this.u.stop();
            this.B = a || null;
            this.A = b || 0;
            a = this.O + "/test";
            b = this.O + "/bind";
            var d = new T6(c ? c.firstTestResults : null, c ? c.secondTestResults : null, this.M),
                e = this.o;
            e && (e.qd = null);
            d.qd = this;
            this.o = d;
            e ? this.o.connect(a, b, this.C, e.w, e.Rj) : c ? this.o.connect(a, b, this.C, c.sessionId, c.arrayId) : this.o.connect(a, b, this.C)
        }
    };
    g.h.sendMessage = function(a, b) {
        var c = {
            _sc: a
        };
        b && g.Sb(c, b);
        this.u.isActive() || 2 == (this.o ? this.o.o : 0) ? this.F.push(c) : c7(this) && kxa(this.o, c)
    };
    g.h.rw = function() {
        this.u.reset();
        this.B = null;
        this.A = 0;
        if (this.F.length) {
            var a = this.F;
            this.F = [];
            for (var b = 0, c = a.length; b < c; ++b) kxa(this.o, a[b])
        }
        this.S("handlerOpened")
    };
    g.h.pw = function(a) {
        var b = 2 == a && 401 == this.o.qf;
        4 == a || b || this.u.start();
        this.S("handlerError", a)
    };
    g.h.Zq = function(a) {
        if (!this.u.isActive()) this.S("handlerClosed");
        else if (a)
            for (var b = 0, c = a.length; b < c; ++b) {
                var d = a[b].map;
                d && this.F.push(d)
            }
    };
    g.h.ax = function() {
        var a = {
            v: 2
        };
        this.H && (a.gsessionid = this.H);
        0 != this.A && (a.ui = "" + this.A);
        0 != this.G && (a.ui = "" + this.G);
        this.B && g.Sb(a, this.B);
        return a
    };
    g.h.qw = function(a) {
        "S" == a[0] ? this.H = a[1] : "gracefulReconnect" == a[0] ? (this.u.start(), ixa(this.o)) : this.S("handlerMessage", new sxa(a[0], a[1]))
    };
    g.h.dO = function() {
        this.u.isActive();
        var a = this.o,
            b = 0;
        a.ac && b++;
        a.Hd && b++;
        0 == b && this.connect(this.B, this.A)
    };
    d7.prototype.A = function(a, b, c, d) {
        b ? a(d) : a({
            text: c.responseText
        })
    };
    d7.prototype.w = function(a, b) {
        a(Error("Request error: " + b.status))
    };
    d7.prototype.B = function(a) {
        a(Error("request timed out"))
    };
    var Cxa = (0, g.B)(),
        g7 = null,
        j7 = Array(50),
        i7 = -1,
        k7 = !1;
    g.Sa(l7, g.N);
    l7.prototype.ae = function() {
        return this.o
    };
    l7.prototype.contains = function(a) {
        return !!j6(this.o, a)
    };
    l7.prototype.get = function(a) {
        return a ? k6(this.o, a) : null
    };
    l7.prototype.info = function(a) {
        h7(this.F, a)
    };
    g.r(m7, g.N);
    g.h = m7.prototype;
    g.h.start = function() {
        !this.o && isNaN(this.Ia) && this.PC()
    };
    g.h.stop = function() {
        this.o && (this.o.abort(), this.o = null);
        isNaN(this.Ia) || (g.Jo(this.Ia), this.Ia = NaN)
    };
    g.h.X = function() {
        this.stop();
        g.N.prototype.X.call(this)
    };
    g.h.PC = function() {
        this.Ia = NaN;
        this.o = g.sq(e7(this.C, "/pairing/get_screen"), {
            method: "POST",
            rb: {
                pairing_code: this.A
            },
            timeout: 5E3,
            onSuccess: (0, g.w)(this.fP, this),
            onError: (0, g.w)(this.eP, this),
            fe: (0, g.w)(this.gP, this)
        })
    };
    g.h.fP = function(a, b) {
        this.o = null;
        var c = b.screen || {};
        c.dialId = this.B;
        c.name = this.w;
        this.S("pairingComplete", new e6(c))
    };
    g.h.eP = function(a) {
        this.o = null;
        a.status && 404 == a.status ? this.u >= Oya.length ? this.S("pairingFailed", Error("DIAL polling timed out")) : (a = Oya[this.u], this.Ia = g.Ho((0, g.w)(this.PC, this), a), this.u++) : this.S("pairingFailed", Error("Server error " + a.status))
    };
    g.h.gP = function() {
        this.o = null;
        this.S("pairingFailed", Error("Server not responding"))
    };
    var Oya = [2E3, 2E3, 1E3, 1E3, 1E3, 2E3, 2E3, 5E3, 5E3, 1E4];
    g.Sa(o7, l7);
    g.h = o7.prototype;
    g.h.start = function() {
        n7(this) && this.S("screenChange");
        !g.qs("yt-remote-lounge-token-expiration") && Gxa(this);
        g.Jo(this.u);
        this.u = g.Ho((0, g.w)(this.start, this), 1E4)
    };
    g.h.add = function(a, b) {
        n7(this);
        Dxa(this, a);
        p7(this, !1);
        this.S("screenChange");
        b(a);
        a.token || Gxa(this)
    };
    g.h.remove = function(a, b) {
        var c = n7(this);
        Fxa(this, a) && (p7(this, !1), c = !0);
        b(a);
        c && this.S("screenChange")
    };
    g.h.hq = function(a, b, c, d) {
        var e = n7(this),
            f = this.get(a.id);
        f ? (f.name != b && (f.name = b, p7(this, !1), e = !0), c(a)) : d(Error("no such local screen."));
        e && this.S("screenChange")
    };
    g.h.X = function() {
        g.Jo(this.u);
        o7.Db.X.call(this)
    };
    g.h.mF = function(a) {
        n7(this);
        var b = this.o.length;
        a = a && a.screens || [];
        for (var c = 0, d = a.length; c < d; ++c) {
            var e = a[c],
                f = this.get(e.screenId);
            f && (f.token = e.loungeToken, --b)
        }
        p7(this, !b);
        b && h7(this.F, "Missed " + b + " lounge tokens.")
    };
    g.h.lF = function(a) {
        h7(this.F, "Requesting lounge tokens failed: " + a)
    };
    g.r(r7, g.N);
    g.h = r7.prototype;
    g.h.start = function() {
        var a = parseInt(g.qs("yt-remote-fast-check-period") || "0", 10);
        (this.A = (0, g.B)() - 144E5 < a ? 0 : a) ? t7(this): (this.A = (0, g.B)() + 3E5, g.ps("yt-remote-fast-check-period", this.A), this.nu())
    };
    g.h.isEmpty = function() {
        return g.Mb(this.o)
    };
    g.h.update = function() {
        q7("Updating availability on schedule.");
        var a = this.C(),
            b = g.Ab(this.o, function(c, d) {
                return c && !!k6(a, d)
            }, this);
        s7(this, b)
    };
    g.h.X = function() {
        g.Jo(this.w);
        this.w = NaN;
        this.u && (this.u.abort(), this.u = null);
        g.N.prototype.X.call(this)
    };
    g.h.nu = function() {
        g.Jo(this.w);
        this.w = NaN;
        this.u && this.u.abort();
        var a = Jxa(this);
        if (a6(a)) {
            var b = e7(this.B, "/pairing/get_screen_availability");
            this.u = f7(this.B, b, {
                lounge_token: g.Gb(a).join(",")
            }, (0, g.w)(this.LM, this, a), (0, g.w)(this.KM, this))
        } else s7(this, {}), t7(this)
    };
    g.h.LM = function(a, b) {
        this.u = null;
        var c = g.Gb(Jxa(this));
        if (g.sb(c, g.Gb(a))) {
            c = b.screens || [];
            for (var d = {}, e = 0, f = c.length; e < f; ++e) d[a[c[e].loungeToken]] = "online" == c[e].status;
            s7(this, d);
            t7(this)
        } else this.Tb("Changing Screen set during request."), this.nu()
    };
    g.h.KM = function(a) {
        this.Tb("Screen availability failed: " + a);
        this.u = null;
        t7(this)
    };
    g.h.Tb = function(a) {
        h7("OnlineScreenService", a)
    };
    g.Sa(u7, l7);
    g.h = u7.prototype;
    g.h.start = function() {
        this.w.start();
        this.u.start();
        this.o.length && (this.S("screenChange"), this.u.isEmpty() || this.S("onlineScreenChange"))
    };
    g.h.add = function(a, b, c) {
        this.w.add(a, b, c)
    };
    g.h.remove = function(a, b, c) {
        this.w.remove(a, b, c);
        this.u.update()
    };
    g.h.hq = function(a, b, c, d) {
        this.w.contains(a) ? this.w.hq(a, b, c, d) : (a = "Updating name of unknown screen: " + a.name, h7(this.F, a), d(Error(a)))
    };
    g.h.ae = function(a) {
        return a ? this.o : g.fb(this.o, (0, g.ue)(this.A, function(b) {
            return !this.contains(b)
        }, this))
    };
    g.h.QC = function() {
        return (0, g.ue)(this.ae(!0), function(a) {
            return !!this.u.o[a.id]
        }, this)
    };
    g.h.RC = function(a, b, c, d, e) {
        this.info("getDialScreenByPairingCode " + a + " / " + b);
        var f = new m7(this.C, a, b, c);
        f.subscribe("pairingComplete", (0, g.w)(function(k) {
            g.He(f);
            d(v7(this, k))
        }, this));
        f.subscribe("pairingFailed", function(k) {
            g.He(f);
            e(k)
        });
        f.start();
        return (0, g.w)(f.stop, f)
    };
    g.h.iP = function(a, b, c, d) {
        g.sq(e7(this.C, "/pairing/get_screen"), {
            method: "POST",
            rb: {
                pairing_code: a
            },
            timeout: 5E3,
            onSuccess: (0, g.w)(function(e, f) {
                var k = new e6(f.screen || {});
                if (!k.name || Nxa(this, k.name)) {
                    a: {
                        var l = k.name;
                        for (var m = 2, n = b(l, m); Nxa(this, n);) {
                            m++;
                            if (20 < m) break a;
                            n = b(l, m)
                        }
                        l = n
                    }
                    k.name = l
                }
                c(v7(this, k))
            }, this),
            onError: (0, g.w)(function(e) {
                d(Error("pairing request failed: " + e.status))
            }, this),
            fe: (0, g.w)(function() {
                d(Error("pairing request timed out."))
            }, this)
        })
    };
    g.h.X = function() {
        g.He(this.w);
        g.He(this.u);
        u7.Db.X.call(this)
    };
    g.h.vF = function() {
        Oxa(this);
        this.S("screenChange");
        this.u.update()
    };
    u7.prototype.dispose = u7.prototype.dispose;
    g.Sa(x7, g.N);
    g.h = x7.prototype;
    g.h.wp = function(a) {
        this.w = a;
        this.S("sessionScreen", this.w)
    };
    g.h.ee = function(a) {
        this.fa() || (a && y7(this, "" + a), this.w = null, this.S("sessionScreen", null))
    };
    g.h.info = function(a) {
        h7(this.R, a)
    };
    g.h.TC = function() {
        return null
    };
    g.h.xu = function(a) {
        var b = this.u;
        a ? (b.displayStatus = new chrome.cast.ReceiverDisplayStatus(a, []), b.displayStatus.showStop = !0) : b.displayStatus = null;
        chrome.cast.setReceiverDisplayStatus(b, (0, g.w)(function() {
            this.info("Updated receiver status for " + b.friendlyName + ": " + a)
        }, this), (0, g.w)(function() {
            y7(this, "Failed to update receiver status for: " + b.friendlyName)
        }, this))
    };
    g.h.X = function() {
        this.xu("");
        x7.Db.X.call(this)
    };
    g.Sa(z7, x7);
    g.h = z7.prototype;
    g.h.wu = function(a) {
        if (this.o) {
            if (this.o == a) return;
            y7(this, "Overriding cast sesison with new session object");
            this.o.removeUpdateListener(this.C);
            this.o.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.B)
        }
        this.o = a;
        this.o.addUpdateListener(this.C);
        this.o.addMessageListener("urn:x-cast:com.google.youtube.mdx", this.B);
        Qxa(this)
    };
    g.h.Sj = function(a) {
        this.info("launchWithParams no-op for Cast: " + g.Jk(a))
    };
    g.h.stop = function() {
        this.o ? this.o.stop((0, g.w)(function() {
            this.ee()
        }, this), (0, g.w)(function() {
            this.ee(Error("Failed to stop receiver app."))
        }, this)) : this.ee(Error("Stopping cast device witout session."))
    };
    g.h.xu = g.Ia;
    g.h.X = function() {
        this.info("disposeInternal");
        g.Jo(this.A);
        this.A = 0;
        this.o && (this.o.removeUpdateListener(this.C), this.o.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.B));
        this.o = null;
        z7.Db.X.call(this)
    };
    g.h.AN = function(a, b) {
        if (!this.fa())
            if (b) {
                var c = w6(b);
                if (g.Na(c)) {
                    var d = "" + c.type;
                    c = c.data || {};
                    this.info("onYoutubeMessage_: " + d + " " + g.Jk(c));
                    switch (d) {
                        case "mdxSessionStatus":
                            Pxa(this, c.screenId);
                            break;
                        default:
                            y7(this, "Unknown youtube message: " + d)
                    }
                } else y7(this, "Unable to parse message.")
            } else y7(this, "No data in message.")
    };
    g.h.xx = function(a, b, c, d) {
        Mxa(this.H, this.u.label, a, this.u.friendlyName, (0, g.w)(function(e) {
            e ? b(e) : 0 <= d ? (y7(this, "Screen " + a + " appears to be offline. " + d + " retries left."), g.Ho((0, g.w)(this.xx, this, a, b, c, d - 1), 300)) : c(Error("Unable to fetch screen."))
        }, this), c)
    };
    g.h.TC = function() {
        return this.o
    };
    g.h.jP = function(a) {
        this.fa() || a || (y7(this, "Cast session died."), this.ee())
    };
    g.Sa(A7, x7);
    g.h = A7.prototype;
    g.h.wu = function(a) {
        this.A = a;
        this.A.addUpdateListener(this.M)
    };
    g.h.Sj = function(a) {
        this.B = a;
        this.F()
    };
    g.h.stop = function() {
        this.o();
        this.o = g.Ia;
        g.Jo(this.C);
        this.A ? this.A.stop((0, g.w)(this.ee, this, null), (0, g.w)(this.ee, this, "Failed to stop DIAL device.")) : this.ee()
    };
    g.h.X = function() {
        this.o();
        this.o = g.Ia;
        g.Jo(this.C);
        this.A && this.A.removeUpdateListener(this.M);
        this.A = null;
        A7.Db.X.call(this)
    };
    g.h.mP = function(a) {
        this.fa() || a || (y7(this, "DIAL session died."), this.o(), this.o = g.Ia, this.ee())
    };
    g.h.rs = function(a) {
        this.O = i6();
        if (this.B) {
            var b = new chrome.cast.DialLaunchResponse(!0, Sxa(this));
            a(b);
            Rxa(this)
        } else this.F = (0, g.w)(function() {
            g.Jo(this.C);
            this.F = g.Ia;
            this.C = NaN;
            var c = new chrome.cast.DialLaunchResponse(!0, Sxa(this));
            a(c);
            Rxa(this)
        }, this), this.C = g.Ho((0, g.w)(function() {
            this.F()
        }, this), 100)
    };
    g.h.PF = function(a, b, c) {
        Mxa(this.H, this.G.receiver.label, a, this.u.friendlyName, (0, g.w)(function(d) {
            d && d.token ? (this.wp(d), b(new chrome.cast.DialLaunchResponse(!1))) : this.rs(b, c)
        }, this), (0, g.w)(function(d) {
            y7(this, "Failed to get DIAL screen: " + d);
            this.rs(b, c)
        }, this))
    };
    g.Sa(B7, x7);
    B7.prototype.stop = function() {
        this.ee()
    };
    B7.prototype.wu = g.Ia;
    B7.prototype.Sj = function() {
        g.Jo(this.o);
        this.o = NaN;
        var a = k6(this.H.ae(), this.u.label);
        a ? this.wp(a) : this.ee(Error("No such screen"))
    };
    B7.prototype.X = function() {
        g.Jo(this.o);
        this.o = NaN;
        B7.Db.X.call(this)
    };
    g.Sa(C7, g.N);
    g.h = C7.prototype;
    g.h.init = function(a, b) {
        chrome.cast.timeout.requestSession = 3E4;
        var c = new chrome.cast.SessionRequest(this.F);
        this.G || (c.dialRequest = new chrome.cast.DialRequest("YouTube"));
        var d = chrome.cast.AutoJoinPolicy.TAB_AND_ORIGIN_SCOPED,
            e = a ? chrome.cast.DefaultActionPolicy.CAST_THIS_TAB : chrome.cast.DefaultActionPolicy.CREATE_SESSION,
            f = (0, g.w)(this.sM, this);
        c = new chrome.cast.ApiConfig(c, (0, g.w)(this.SA, this), f, d, e);
        c.customDialLaunchCallback = (0, g.w)(this.CK, this);
        chrome.cast.initialize(c, (0, g.w)(function() {
            this.fa() ||
                (chrome.cast.addReceiverActionListener(this.A), zxa(), this.u.subscribe("onlineScreenChange", (0, g.w)(this.SC, this)), this.w = Uxa(this), chrome.cast.setCustomReceivers(this.w, g.Ia, (0, g.w)(function(k) {
                    this.Tb("Failed to set initial custom receivers: " + g.Jk(k))
                }, this)), this.S("yt-remote-cast2-availability-change", E7(this)), b(!0))
        }, this), (0, g.w)(function(k) {
            this.Tb("Failed to initialize API: " + g.Jk(k));
            b(!1)
        }, this))
    };
    g.h.kO = function(a, b) {
        D7("Setting connected screen ID: " + a + " -> " + b);
        if (this.o) {
            var c = this.o.w;
            if (!a || c && c.id != a) D7("Unsetting old screen status: " + this.o.u.friendlyName), F7(this, null)
        }
        if (a && b) {
            if (!this.o) {
                c = k6(this.u.ae(), a);
                if (!c) {
                    D7("setConnectedScreenStatus: Unknown screen.");
                    return
                }
                var d = Txa(this, c);
                d || (D7("setConnectedScreenStatus: Connected receiver not custom..."), d = new chrome.cast.Receiver(c.uuid ? c.uuid : c.id, c.name), d.receiverType = chrome.cast.ReceiverType.CUSTOM, this.w.push(d), chrome.cast.setCustomReceivers(this.w,
                    g.Ia, (0, g.w)(function(e) {
                        this.Tb("Failed to set initial custom receivers: " + g.Jk(e))
                    }, this)));
                D7("setConnectedScreenStatus: new active receiver: " + d.friendlyName);
                F7(this, new B7(this.u, d), !0)
            }
            this.o.xu(b)
        } else D7("setConnectedScreenStatus: no screen.")
    };
    g.h.lO = function(a) {
        this.fa() ? this.Tb("Setting connection data on disposed cast v2") : this.o ? this.o.Sj(a) : this.Tb("Setting connection data without a session")
    };
    g.h.lP = function() {
        this.fa() ? this.Tb("Stopping session on disposed cast v2") : this.o ? (this.o.stop(), F7(this, null)) : D7("Stopping non-existing session")
    };
    g.h.requestSession = function() {
        chrome.cast.requestSession((0, g.w)(this.SA, this), (0, g.w)(this.QM, this))
    };
    g.h.X = function() {
        this.u.unsubscribe("onlineScreenChange", (0, g.w)(this.SC, this));
        window.chrome && chrome.cast && chrome.cast.removeReceiverActionListener(this.A);
        var a = wxa,
            b = g.Ha("yt.mdx.remote.debug.handlers_");
        g.db(b || [], a);
        g.He(this.o);
        C7.Db.X.call(this)
    };
    g.h.Tb = function(a) {
        h7("Controller", a)
    };
    g.h.UA = function(a, b) {
        this.o == a && (b || F7(this, null), this.S("yt-remote-cast2-session-change", b))
    };
    g.h.oM = function(a, b) {
        if (!this.fa())
            if (a) switch (a.friendlyName = chrome.cast.unescape(a.friendlyName), D7("onReceiverAction_ " + a.label + " / " + a.friendlyName + "-- " + b), b) {
                case chrome.cast.ReceiverAction.CAST:
                    if (this.o)
                        if (this.o.u.label != a.label) D7("onReceiverAction_: Stopping active receiver: " + this.o.u.friendlyName), this.o.stop();
                        else {
                            D7("onReceiverAction_: Casting to active receiver.");
                            this.o.w && this.S("yt-remote-cast2-session-change", this.o.w);
                            break
                        }
                    switch (a.receiverType) {
                        case chrome.cast.ReceiverType.CUSTOM:
                            F7(this,
                                new B7(this.u, a));
                            break;
                        case chrome.cast.ReceiverType.DIAL:
                            F7(this, new A7(this.u, a, this.C));
                            break;
                        case chrome.cast.ReceiverType.CAST:
                            F7(this, new z7(this.u, a));
                            break;
                        default:
                            this.Tb("Unknown receiver type: " + a.receiverType)
                    }
                    break;
                case chrome.cast.ReceiverAction.STOP:
                    this.o && this.o.u.label == a.label ? this.o.stop() : this.Tb("Stopping receiver w/o session: " + a.friendlyName)
            } else this.Tb("onReceiverAction_ called without receiver.")
    };
    g.h.CK = function(a) {
        if (this.fa()) return Promise.reject(Error("disposed"));
        var b = a.receiver;
        b.receiverType != chrome.cast.ReceiverType.DIAL && (this.Tb("Not DIAL receiver: " + b.friendlyName), b.receiverType = chrome.cast.ReceiverType.DIAL);
        var c = this.o ? this.o.u : null;
        if (!c || c.label != b.label) return this.Tb("Receiving DIAL launch request for non-clicked DIAL receiver: " + b.friendlyName), Promise.reject(Error("illegal DIAL launch"));
        if (c && c.label == b.label && c.receiverType != chrome.cast.ReceiverType.DIAL) {
            if (this.o.w) return D7("Reselecting dial screen."),
                this.S("yt-remote-cast2-session-change", this.o.w), Promise.resolve(new chrome.cast.DialLaunchResponse(!1));
            this.Tb('Changing CAST intent from "' + c.receiverType + '" to "dial" for ' + b.friendlyName);
            F7(this, new A7(this.u, b, this.C))
        }
        b = this.o;
        b.G = a;
        return b.G.appState == chrome.cast.DialAppState.RUNNING ? new Promise((0, g.w)(b.PF, b, (b.G.extraData || {}).screenId || null)) : new Promise((0, g.w)(b.rs, b))
    };
    g.h.SA = function(a) {
        if (!this.fa()) {
            D7("New cast session ID: " + a.sessionId);
            var b = a.receiver;
            if (b.receiverType != chrome.cast.ReceiverType.CUSTOM) {
                if (!this.o)
                    if (b.receiverType == chrome.cast.ReceiverType.CAST) D7("Got resumed cast session before resumed mdx connection."), b.friendlyName = chrome.cast.unescape(b.friendlyName), F7(this, new z7(this.u, b), !0);
                    else {
                        this.Tb("Got non-cast session without previous mdx receiver event, or mdx resume.");
                        return
                    }
                var c = this.o.u,
                    d = k6(this.u.ae(), c.label);
                d && f6(d, b.label) &&
                    c.receiverType != chrome.cast.ReceiverType.CAST && b.receiverType == chrome.cast.ReceiverType.CAST && (D7("onSessionEstablished_: manual to cast session change " + b.friendlyName), g.He(this.o), this.o = new z7(this.u, b), this.o.subscribe("sessionScreen", (0, g.w)(this.UA, this, this.o)), this.o.Sj(null));
                this.o.wu(a)
            }
        }
    };
    g.h.kP = function() {
        return this.o ? this.o.TC() : null
    };
    g.h.QM = function(a) {
        this.fa() || (this.Tb("Failed to estabilish a session: " + g.Jk(a)), a.code != chrome.cast.ErrorCode.CANCEL && F7(this, null))
    };
    g.h.sM = function(a) {
        D7("Receiver availability updated: " + a);
        if (!this.fa()) {
            var b = E7(this);
            this.B = a == chrome.cast.ReceiverAvailability.AVAILABLE;
            E7(this) != b && this.S("yt-remote-cast2-availability-change", E7(this))
        }
    };
    g.h.SC = function() {
        this.fa() || (this.w = Uxa(this), D7("Updating custom receivers: " + g.Jk(this.w)), chrome.cast.setCustomReceivers(this.w, g.Ia, (0, g.w)(function() {
            this.Tb("Failed to set custom receivers.")
        }, this)), this.S("yt-remote-cast2-availability-change", E7(this)))
    };
    C7.prototype.setLaunchParams = C7.prototype.lO;
    C7.prototype.setConnectedScreenStatus = C7.prototype.kO;
    C7.prototype.stopSession = C7.prototype.lP;
    C7.prototype.getCastSession = C7.prototype.kP;
    C7.prototype.requestSession = C7.prototype.requestSession;
    C7.prototype.init = C7.prototype.init;
    C7.prototype.dispose = C7.prototype.dispose;
    var L7 = [];
    g.h = Q7.prototype;
    g.h.reset = function(a) {
        this.listId = "";
        this.index = -1;
        this.videoId = "";
        R7(this);
        this.volume = -1;
        this.muted = !1;
        a && (this.index = a.index, this.listId = a.listId, this.videoId = a.videoId, this.playerState = a.playerState, this.volume = a.volume, this.muted = a.muted, this.audioTrackId = a.audioTrackId, this.o = a.trackData, this.O = a.hasPrevious, this.hasNext = a.hasNext, this.F = a.playerTime, this.C = a.playerTimeAt, this.B = a.seekableStart, this.u = a.seekableEnd, this.G = a.duration, this.H = a.loadedTime, this.A = a.liveIngestionTime, this.w = !isNaN(this.A))
    };
    g.h.bb = function() {
        return 1 == this.playerState
    };
    g.h.isAdPlaying = function() {
        return 1081 == this.playerState
    };
    g.h.getDuration = function() {
        return this.w ? this.G + S7(this) : this.G
    };
    g.h.clone = function() {
        return new Q7(W7(this))
    };
    g.r(Y7, g.N);
    g.h = Y7.prototype;
    g.h.play = function() {
        1 == this.o ? (this.u ? this.u.play(null, g.Ia, d8(this, "play")) : c8(this, "play"), b8(this, 1, U7(Z7(this))), this.S("remotePlayerChange")) : $7(this, this.play)
    };
    g.h.pause = function() {
        1 == this.o ? (this.u ? this.u.pause(null, g.Ia, d8(this, "pause")) : c8(this, "pause"), b8(this, 2, U7(Z7(this))), this.S("remotePlayerChange")) : $7(this, this.pause)
    };
    g.h.seekTo = function(a) {
        if (1 == this.o) {
            if (this.u) {
                var b = Z7(this),
                    c = new chrome.cast.media.SeekRequest;
                c.currentTime = a;
                b.bb() || 3 == b.playerState ? c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_START : c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_PAUSE;
                this.u.seek(c, g.Ia, d8(this, "seekTo", {
                    newTime: a
                }))
            } else c8(this, "seekTo", {
                newTime: a
            });
            b8(this, 3, a);
            this.S("remotePlayerChange")
        } else $7(this, g.Qa(this.seekTo, a))
    };
    g.h.stop = function() {
        if (1 == this.o) {
            this.u ? this.u.stop(null, g.Ia, d8(this, "stopVideo")) : c8(this, "stopVideo");
            var a = Z7(this);
            a.index = -1;
            a.videoId = "";
            R7(a);
            a8(this, a);
            this.S("remotePlayerChange")
        } else $7(this, this.stop)
    };
    g.h.setVolume = function(a, b) {
        if (1 == this.o) {
            var c = Z7(this);
            if (this.w) {
                if (c.volume != a) {
                    var d = Math.round(a) / 100;
                    this.w.setReceiverVolumeLevel(d, (0, g.w)(function() {
                        h7("CP", "set receiver volume: " + d)
                    }, this), (0, g.w)(function() {
                        this.Tb("failed to set receiver volume.")
                    }, this))
                }
                c.muted != b && this.w.setReceiverMuted(b, (0, g.w)(function() {
                    h7("CP", "set receiver muted: " + b)
                }, this), (0, g.w)(function() {
                    this.Tb("failed to set receiver muted.")
                }, this))
            } else {
                var e = {
                    volume: a,
                    muted: b
                }; - 1 != c.volume && (e.delta = a - c.volume);
                c8(this, "setVolume", e)
            }
            c.muted = b;
            c.volume = a;
            a8(this, c)
        } else $7(this, g.Qa(this.setVolume, a, b))
    };
    g.h.UB = function(a, b) {
        if (1 == this.o) {
            var c = Z7(this),
                d = {
                    videoId: a
                };
            b && (c.o = {
                trackName: b.name,
                languageCode: b.languageCode,
                sourceLanguageCode: b.translationLanguage ? b.translationLanguage.languageCode : "",
                languageName: b.languageName,
                kind: b.kind
            }, d.style = g.Jk(b.style), g.Sb(d, c.o));
            c8(this, "setSubtitlesTrack", d);
            a8(this, c)
        } else $7(this, g.Qa(this.UB, a, b))
    };
    g.h.setAudioTrack = function(a, b) {
        if (1 == this.o) {
            var c = b.getLanguageInfo().getId();
            c8(this, "setAudioTrack", {
                videoId: a,
                audioTrackId: c
            });
            var d = Z7(this);
            d.audioTrackId = c;
            a8(this, d)
        } else $7(this, g.Qa(this.setAudioTrack, a, b))
    };
    g.h.playVideo = function(a, b, c, d, e, f, k) {
        var l = Z7(this);
        c = c || 0;
        var m = {
            videoId: a,
            currentIndex: c
        };
        V7(l, a, c);
        void 0 !== b && (T7(l, b), m.currentTime = b);
        void 0 !== d && (m.listId = d);
        null != e && (m.playerParams = e);
        null != f && (m.clickTrackingParams = f);
        null != k && (m.locationInfo = g.Jk(k));
        c8(this, "setPlaylist", m);
        d || a8(this, l)
    };
    g.h.OC = function(a, b) {
        if (1 == this.o) {
            if (a && b) {
                var c = Z7(this);
                V7(c, a, b);
                a8(this, c)
            }
            c8(this, "previous")
        } else $7(this, g.Qa(this.OC, a, b))
    };
    g.h.nextVideo = function(a, b) {
        if (1 == this.o) {
            if (a && b) {
                var c = Z7(this);
                V7(c, a, b);
                a8(this, c)
            }
            c8(this, "next")
        } else $7(this, g.Qa(this.nextVideo, a, b))
    };
    g.h.Iw = function() {
        1 == this.o ? c8(this, "dismissAutoplay") : $7(this, this.Iw)
    };
    g.h.dispose = function() {
        if (3 != this.o) {
            var a = this.o;
            this.o = 3;
            this.S("proxyStateChange", a, this.o)
        }
        g.N.prototype.dispose.call(this)
    };
    g.h.X = function() {
        gya(this);
        this.A = null;
        this.B.clear();
        X7(this, null);
        g.N.prototype.X.call(this)
    };
    g.h.bv = function(a) {
        if ((a != this.o || 2 == a) && 3 != this.o && 0 != a) {
            var b = this.o;
            this.o = a;
            this.S("proxyStateChange", b, a);
            if (1 == a)
                for (; !this.B.isEmpty();) b = a = this.B, g.ab(b.o) && (b.o = b.u, b.o.reverse(), b.u = []), a.o.pop().apply(this);
            else 3 == a && this.dispose()
        }
    };
    g.h.lM = function(a, b) {
        this.S(a, b)
    };
    g.h.kK = function(a) {
        if (!a) this.im(null), X7(this, null);
        else if (this.w.receiver.volume) {
            a = this.w.receiver.volume;
            var b = Z7(this),
                c = Math.round(100 * a.level || 0);
            if (b.volume != c || b.muted != a.muted) h7("CP", "Cast volume update: " + a.level + (a.muted ? " muted" : "")), b.volume = c, b.muted = !!a.muted, a8(this, b)
        }
    };
    g.h.im = function(a) {
        h7("CP", "Cast media: " + !!a);
        this.u && this.u.removeUpdateListener(this.G);
        if (this.u = a) this.u.addUpdateListener(this.G), hya(this), this.S("remotePlayerChange")
    };
    g.h.jK = function(a) {
        a ? (hya(this), this.S("remotePlayerChange")) : this.im(null)
    };
    g.h.vK = function() {
        var a = dya();
        a && X7(this, a)
    };
    g.h.Tb = function(a) {
        h7("CP", a)
    };
    g.r(e8, g.N);
    g.h = e8.prototype;
    g.h.connect = function(a, b) {
        if (b) {
            var c = b.listId,
                d = b.videoId,
                e = b.playerParams,
                f = b.clickTrackingParams,
                k = b.index,
                l = {
                    videoId: d
                },
                m = b.currentTime,
                n = b.locationInfo;
            void 0 !== m && (l.currentTime = 5 >= m ? 0 : m);
            e && (l.playerParams = e);
            n && (l.locationInfo = n);
            f && (l.clickTrackingParams = f);
            c && (l.listId = c);
            void 0 !== k && (l.currentIndex = k);
            c && (this.Va.listId = c);
            this.Va.videoId = d;
            this.Va.index = k || 0;
            this.Va.state = 3;
            T7(this.Va, m);
            this.A = "UNSUPPORTED";
            f8("Connecting with setPlaylist and params: " + g.Jk(l));
            this.o.connect({
                method: "setPlaylist",
                params: g.Jk(l)
            }, a, uwa())
        } else f8("Connecting without params"), this.o.connect({}, a, uwa());
        jya(this)
    };
    g.h.dispose = function() {
        this.fa() || (this.S("beforeDispose"), g8(this, 3));
        g.N.prototype.dispose.call(this)
    };
    g.h.X = function() {
        h8(this);
        j8(this);
        i8(this);
        g.Jo(this.F);
        this.F = NaN;
        g.Jo(this.G);
        this.G = NaN;
        this.w = null;
        g.ep(this.R);
        this.R.length = 0;
        this.o.dispose();
        g.N.prototype.X.call(this);
        this.A = this.C = this.u = this.Va = this.o = null
    };
    g.h.eF = function() {
        this.uj(2)
    };
    g.h.oK = function() {
        f8("Channel opened");
        this.M && (this.M = !1, i8(this), this.O = g.Ho((0, g.w)(function() {
            f8("Timing out waiting for a screen.");
            this.uj(1)
        }, this), 15E3));
        ywa(txa(this.o), this.T)
    };
    g.h.lK = function() {
        f8("Channel closed");
        isNaN(this.B) ? p6(!0) : p6();
        this.dispose()
    };
    g.h.mK = function(a) {
        p6();
        isNaN(this.tl()) ? (f8("Channel error: " + a + " without reconnection"), this.dispose()) : (this.M = !0, f8("Channel error: " + a + " with reconnection in " + this.tl() + " ms"), g8(this, 2))
    };
    g.h.nK = function(a) {
        a.params ? f8("Received: action=" + a.action + ", params=" + g.Jk(a.params)) : f8("Received: action=" + a.action + " {}");
        switch (a.action) {
            case "loungeStatus":
                a = w6(a.params.devices);
                this.u = (0, g.Dc)(a, function(c) {
                    return new d6(c)
                });
                a = !!g.Xa(this.u, function(c) {
                    return "LOUNGE_SCREEN" == c.type
                });
                mya(this, a);
                break;
            case "loungeScreenDisconnected":
                g.eb(this.u, function(c) {
                    return "LOUNGE_SCREEN" == c.type
                });
                mya(this, !1);
                break;
            case "remoteConnected":
                var b = new d6(w6(a.params.device));
                g.Xa(this.u, function(c) {
                    return b ? c.id == b.id : !1
                }) || ewa(this.u, b);
                break;
            case "remoteDisconnected":
                b = new d6(w6(a.params.device));
                g.eb(this.u, function(c) {
                    return b ? c.id == b.id : !1
                });
                break;
            case "gracefulDisconnect":
                break;
            case "playlistModified":
                oya(this, a);
                break;
            case "nowPlaying":
                qya(this, a);
                break;
            case "onStateChange":
                pya(this, a);
                break;
            case "onAdStateChange":
                rya(this, a);
                break;
            case "onVolumeChanged":
                sya(this, a);
                break;
            case "onSubtitlesTrackChanged":
                nya(this, a);
                break;
            case "nowAutoplaying":
                tya(this, a);
                break;
            case "autoplayDismissed":
                this.S("autoplayDismissed");
                break;
            case "autoplayUpNext":
                this.C = a.params.videoId || null;
                this.S("autoplayUpNext", this.C);
                break;
            case "onAutoplayModeChanged":
                this.A =
                    a.params.autoplayMode;
                this.S("autoplayModeChange", this.A);
                "DISABLED" == this.A && this.S("autoplayDismissed");
                break;
            case "onHasPreviousNextChanged":
                uya(this, a);
                break;
            case "requestAssistedSignIn":
                this.S("assistedSignInRequested", a.params.authCode);
                break;
            default:
                f8("Unrecognized action: " + a.action)
        }
    };
    g.h.ZN = function() {
        if (this.w) {
            var a = this.w;
            this.w = null;
            this.Va.videoId != a && k8(this, "getNowPlaying")
        }
    };
    g.h.UE = function() {
        var a = 3;
        this.fa() || (a = 0, isNaN(this.tl()) ? c7(this.o) && isNaN(this.B) && (a = 1) : a = 2);
        return a
    };
    g.h.uj = function(a) {
        f8("Disconnecting with " + a);
        h8(this);
        this.S("beforeDisconnect", a);
        1 == a && p6();
        uxa(this.o, a);
        this.dispose()
    };
    g.h.TE = function() {
        var a = this.Va;
        this.w && (a = this.Va.clone(), V7(a, this.w, a.index));
        return W7(a)
    };
    g.h.mO = function(a) {
        var b = new Q7(a);
        b.videoId && b.videoId != this.Va.videoId && (this.w = b.videoId, g.Jo(this.F), this.F = g.Ho((0, g.w)(this.ZN, this), 5E3));
        var c = [];
        this.Va.listId == b.listId && this.Va.videoId == b.videoId && this.Va.index == b.index || c.push("remoteQueueChange");
        this.Va.playerState == b.playerState && this.Va.volume == b.volume && this.Va.muted == b.muted && U7(this.Va) == U7(b) && g.Jk(this.Va.o) == g.Jk(b.o) || c.push("remotePlayerChange");
        this.Va.reset(a);
        (0, g.x)(c, function(d) {
            this.S(d)
        }, this)
    };
    g.h.vx = function() {
        var a = this.o.C.id,
            b = g.Xa(this.u, function(c) {
                return "REMOTE_CONTROL" == c.type && c.id != a
            });
        return b ? b.id : ""
    };
    g.h.tl = function() {
        var a = this.o;
        return a.u.isActive() ? a.u.u - (0, g.B)() : NaN
    };
    g.h.IE = function() {
        return this.A || "UNSUPPORTED"
    };
    g.h.JE = function() {
        return this.C || ""
    };
    g.h.dP = function() {
        if (!isNaN(this.tl())) {
            var a = this.o.u;
            g.un(a.o);
            a.start()
        }
    };
    g.h.hO = function(a, b) {
        k8(this, a, b);
        lya(this)
    };
    e8.prototype.subscribe = e8.prototype.subscribe;
    e8.prototype.unsubscribeByKey = e8.prototype.Bh;
    e8.prototype.getProxyState = e8.prototype.UE;
    e8.prototype.disconnect = e8.prototype.uj;
    e8.prototype.getPlayerContextData = e8.prototype.TE;
    e8.prototype.setPlayerContextData = e8.prototype.mO;
    e8.prototype.getOtherConnectedRemoteId = e8.prototype.vx;
    e8.prototype.getReconnectTimeout = e8.prototype.tl;
    e8.prototype.getAutoplayMode = e8.prototype.IE;
    e8.prototype.getAutoplayVideoId = e8.prototype.JE;
    e8.prototype.reconnect = e8.prototype.dP;
    e8.prototype.sendMessage = e8.prototype.hO;
    g.r(l8, l7);
    g.h = l8.prototype;
    g.h.ae = function(a) {
        return this.td.$_gs(a)
    };
    g.h.contains = function(a) {
        return !!this.td.$_c(a)
    };
    g.h.get = function(a) {
        return this.td.$_g(a)
    };
    g.h.start = function() {
        this.td.$_st()
    };
    g.h.add = function(a, b, c) {
        this.td.$_a(a, b, c)
    };
    g.h.remove = function(a, b, c) {
        this.td.$_r(a, b, c)
    };
    g.h.hq = function(a, b, c, d) {
        this.td.$_un(a, b, c, d)
    };
    g.h.X = function() {
        for (var a = 0, b = this.u.length; a < b; ++a) this.td.$_ubk(this.u[a]);
        this.u.length = 0;
        this.td = null;
        l7.prototype.X.call(this)
    };
    g.h.hP = function() {
        this.S("screenChange")
    };
    g.h.NL = function() {
        this.S("onlineScreenChange")
    };
    u7.prototype.$_st = u7.prototype.start;
    u7.prototype.$_gspc = u7.prototype.iP;
    u7.prototype.$_gsppc = u7.prototype.RC;
    u7.prototype.$_c = u7.prototype.contains;
    u7.prototype.$_g = u7.prototype.get;
    u7.prototype.$_a = u7.prototype.add;
    u7.prototype.$_un = u7.prototype.hq;
    u7.prototype.$_r = u7.prototype.remove;
    u7.prototype.$_gs = u7.prototype.ae;
    u7.prototype.$_gos = u7.prototype.QC;
    u7.prototype.$_s = u7.prototype.subscribe;
    u7.prototype.$_ubk = u7.prototype.Bh;
    var E8 = null,
        D8 = !1,
        m8 = null,
        n8 = null,
        C8 = null,
        r8 = [];
    g.r(F8, g.y);
    g.h = F8.prototype;
    g.h.X = function() {
        g.y.prototype.X.call(this);
        this.A.stop();
        this.C.stop();
        this.M.stop();
        this.U();
        this.o.unsubscribe("proxyStateChange", this.OA, this);
        this.o.unsubscribe("remotePlayerChange", this.mm, this);
        this.o.unsubscribe("remoteQueueChange", this.xp, this);
        this.o.unsubscribe("autoplayUpNext", this.fA, this);
        this.o.unsubscribe("previousNextChange", this.KA, this);
        this.o.unsubscribe("nowAutoplaying", this.GA, this);
        this.o.unsubscribe("autoplayDismissed", this.eA, this);
        this.o = this.B = null
    };
    g.h.sz = function(a, b) {
        for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
        if (2 != this.o.o)
            if (I8(this)) {
                if (!Z7(this.o).isAdPlaying() || "control_seek" != a) switch (a) {
                    case "control_toggle_play_pause":
                        Z7(this.o).bb() ? this.o.pause() : this.o.play();
                        break;
                    case "control_play":
                        this.o.play();
                        break;
                    case "control_pause":
                        this.o.pause();
                        break;
                    case "control_seek":
                        this.O.Ex(c[0], c[1]);
                        break;
                    case "control_subtitles_set_track":
                        J8(this, c[0]);
                        break;
                    case "control_set_audio_track":
                        c = c[0], I8(this) && this.o.setAudioTrack(this.u.getVideoData(1).videoId,
                            c)
                }
            } else switch (a) {
                case "control_toggle_play_pause":
                case "control_play":
                case "control_pause":
                    c = this.u.getCurrentTime();
                    K8(this, 0 == c ? void 0 : c);
                    break;
                case "control_seek":
                    K8(this, c[0]);
                    break;
                case "control_subtitles_set_track":
                    J8(this, c[0]);
                    break;
                case "control_set_audio_track":
                    c = c[0], I8(this) && this.o.setAudioTrack(this.u.getVideoData(1).videoId, c)
            }
    };
    g.h.iK = function(a) {
        this.M.aF(a)
    };
    g.h.JO = function(a) {
        this.sz("control_subtitles_set_track", g.Mb(a) ? null : a)
    };
    g.h.eC = function() {
        var a = this.u.getOption("captions", "track");
        g.Mb(a) || J8(this, a)
    };
    g.h.uA = function(a) {
        if (I8(this)) {
            this.o.unsubscribe("remotePlayerChange", this.mm, this);
            var b = Math.round(a.volume);
            a = !!a.muted;
            var c = Z7(this.o);
            if (b != c.volume || a != c.muted) this.o.setVolume(b, a), this.R.start();
            this.o.subscribe("remotePlayerChange", this.mm, this)
        }
    };
    g.h.jL = function() {
        g.Mb(this.F) || Gya(this, this.F);
        this.G = !1
    };
    g.h.OA = function(a, b) {
        this.C.stop();
        2 == b && this.dC()
    };
    g.h.mm = function() {
        if (I8(this)) {
            this.A.stop();
            var a = Z7(this.o);
            switch (a.playerState) {
                case 1080:
                case 1081:
                case 1084:
                case 1085:
                    this.B.M = 1;
                    break;
                case 1082:
                case 1083:
                    this.B.M = 0;
                    break;
                default:
                    this.B.M = -1
            }
            switch (a.playerState) {
                case 1081:
                case 1:
                    H8(this, new g.wC(8));
                    this.cC();
                    break;
                case 1085:
                case 3:
                    H8(this, new g.wC(9));
                    break;
                case 1083:
                case 0:
                    H8(this, new g.wC(2));
                    this.O.stop();
                    G8(this, this.u.getVideoData().lengthSeconds);
                    break;
                case 1084:
                    H8(this, new g.wC(4));
                    break;
                case 2:
                    H8(this, new g.wC(4));
                    G8(this, U7(a));
                    break;
                case -1:
                    H8(this, new g.wC(64));
                    break;
                case -1E3:
                    H8(this, new g.wC(128, {
                        errorCode: "mdx.remoteerror",
                        errorMessage: "This video is not available for remote playback."
                    }))
            }
            a = Z7(this.o).o;
            var b = this.F;
            (a || b ? a && b && a.trackName == b.trackName && a.languageCode == b.languageCode && a.languageName == b.languageName && a.kind == b.kind : 1) || (this.F = a, Gya(this, a));
            a = Z7(this.o); - 1 == a.volume || Math.round(this.u.getVolume()) == a.volume && this.u.isMuted() == a.muted || this.R.isActive() || this.DC()
        } else Fya(this)
    };
    g.h.KA = function() {
        this.u.S("mdxpreviousnextchange")
    };
    g.h.xp = function() {
        I8(this) || Fya(this)
    };
    g.h.YD = function() {
        this.o.Iw()
    };
    g.h.fA = function() {};
    g.h.GA = function(a) {
        isNaN(a) || this.u.S("mdxnowautoplaying", a)
    };
    g.h.eA = function() {
        this.u.S("mdxautoplaycanceled")
    };
    g.h.zI = function(a, b) {
        -1 == Z7(this.o).playerState ? K8(this, a) : b && this.o.seekTo(a)
    };
    g.h.DC = function() {
        if (I8(this)) {
            var a = Z7(this.o);
            this.w.ab(this.T);
            a.muted ? this.u.mute() : this.u.unMute();
            this.u.setVolume(a.volume);
            this.T = this.w.L(this.u, "onVolumeChange", this.uA)
        }
    };
    g.h.cC = function() {
        this.A.stop();
        if (!this.o.fa()) {
            var a = Z7(this.o);
            a.bb() && H8(this, new g.wC(8));
            G8(this, U7(a));
            this.A.start()
        }
    };
    g.h.dC = function() {
        this.C.stop();
        this.A.stop();
        var a = this.o.A.getReconnectTimeout();
        2 == this.o.o && !isNaN(a) && this.C.start()
    };
    g.r(L8, g.Q);
    L8.prototype.A = function(a) {
        Iya(this, a.state)
    };
    g.r(M8, g.Q);
    M8.prototype.Pb = function() {
        this.u.show()
    };
    M8.prototype.w = function() {
        g.AN("https://support.google.com/youtube/answer/7640706")
    };
    M8.prototype.A = function() {
        c6("mdx-manual-pairing-popup-ok");
        this.u.hide()
    };
    g.r(N8, g.Q);
    N8.prototype.Pb = function() {
        this.u.show()
    };
    N8.prototype.w = function() {
        c6("mdx-privacy-popup-cancel");
        this.u.hide()
    };
    N8.prototype.A = function() {
        c6("mdx-privacy-popup-confirm");
        this.u.hide()
    };
    g.r(O8, g.cO);
    O8.prototype.G = function() {
        var a = this.J.getOption("remote", "receivers");
        a && 1 < a.length && !this.J.getOption("remote", "quickCast") ? (this.C = g.vb(a, this.w, this), g.eO(this, (0, g.Dc)(a, this.w)), a = this.J.getOption("remote", "currentReceiver"), this.Bb(this.w(a)), this.enable(!0)) : this.enable(!1)
    };
    O8.prototype.w = function(a) {
        return a.key
    };
    O8.prototype.Ue = function(a) {
        return "cast-selector-receiver" === a ? "Cast..." : this.C[a].name
    };
    O8.prototype.bd = function(a) {
        g.cO.prototype.bd.call(this, a);
        this.J.setOption("remote", "currentReceiver", this.C[a]);
        this.u.gb()
    };
    g.r(P8, g.xL);
    g.h = P8.prototype;
    g.h.create = function() {
        zya(g.Fy(this.player.N()));
        this.w.push(g.Oo("yt-remote-before-disconnect", this.fK, this));
        this.w.push(g.Oo("yt-remote-connection-change", this.tM, this));
        this.w.push(g.Oo("yt-remote-receiver-availability-change", this.MA, this));
        this.w.push(g.Oo("yt-remote-auto-connect", this.rM, this));
        this.w.push(g.Oo("yt-remote-receiver-resumed", this.qM, this));
        this.w.push(g.Oo("mdx-privacy-popup-confirm", this.LN, this));
        this.w.push(g.Oo("mdx-privacy-popup-cancel", this.KN, this));
        this.w.push(g.Oo("mdx-manual-pairing-popup-ok",
            this.jG, this));
        this.MA()
    };
    g.h.load = function() {
        this.player.cancelPlayback();
        g.xL.prototype.load.call(this);
        this.C = new F8(this, this.player, this.o);
        var a = (a = Eya()) ? a.currentTime : 0;
        var b = B8() ? new Y7(w8(), void 0) : null;
        0 == a && b && (a = U7(Z7(b)));
        0 != a && (this.U = a || 0, this.player.S("progresssync", a, void 0));
        Hya(this, this.H, this.H);
        g.SS(this.player.app, 6)
    };
    g.h.unload = function() {
        this.player.S("mdxautoplaycanceled");
        this.A = this.u;
        g.Ie(this.C, this.o);
        this.o = this.C = null;
        g.xL.prototype.unload.call(this);
        g.SS(this.player.app, 5);
        Q8(this)
    };
    g.h.X = function() {
        g.Po(this.w);
        g.xL.prototype.X.call(this)
    };
    g.h.Rl = function(a, b) {
        for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
        this.loaded && this.C.sz.apply(this.C, [a].concat(g.la(c)))
    };
    g.h.getAdState = function() {
        return this.M
    };
    g.h.WE = function() {
        return this.loaded ? this.C.suggestion : null
    };
    g.h.Ky = function() {
        return this.o ? Z7(this.o).O : !1
    };
    g.h.hasNext = function() {
        return this.o ? Z7(this.o).hasNext : !1
    };
    g.h.getCurrentTime = function() {
        return this.U
    };
    g.h.getProgressState = function() {
        var a = Z7(this.o),
            b = this.player.getVideoData();
        return {
            allowSeeking: g.O(this.player.N().experiments, "web_player_mdx_allow_seeking_change_killswitch") ? this.player.Mc() : !a.isAdPlaying() && this.player.Mc(),
            clipEnd: b.clipEnd,
            clipStart: b.clipStart,
            current: this.getCurrentTime(),
            displayedStart: -1,
            duration: a.getDuration(),
            ingestionTime: a.w ? a.A + S7(a) : a.A,
            isAtLiveHead: 1 >= (a.w ? a.u + S7(a) : a.u) - this.getCurrentTime(),
            loaded: a.H,
            seekableEnd: a.w ? a.u + S7(a) : a.u,
            seekableStart: 0 < a.B ? a.B + S7(a) : a.B
        }
    };
    g.h.nextVideo = function() {
        this.o && this.o.nextVideo()
    };
    g.h.rG = function() {
        this.o && this.o.OC()
    };
    g.h.fK = function(a) {
        1 == a && (this.aa = this.o ? Z7(this.o) : null)
    };
    g.h.tM = function() {
        var a = B8() ? new Y7(w8(), void 0) : null;
        if (a) {
            var b = this.A;
            this.loaded && this.unload();
            this.o = a;
            this.aa = null;
            b.key != this.u.key && (this.A = b, this.load())
        } else g.He(this.o), this.o = null, this.loaded && (this.unload(), (a = this.aa) && a.videoId == this.player.getVideoData().videoId && this.player.cueVideoById(a.videoId, U7(a)));
        this.player.S("videodatachange", "newdata", this.player.getVideoData(), 3)
    };
    g.h.MA = function() {
        this.T = [this.u].concat(Bya());
        var a = x8() || this.u;
        R8(this, a);
        this.player.oa("onMdxReceiversChange")
    };
    g.h.rM = function() {
        var a = x8();
        R8(this, a)
    };
    g.h.qM = function() {
        this.A = x8()
    };
    g.h.LN = function() {
        this.O = !0;
        Q8(this);
        D8 = !1;
        E8 && z8(E8, 1);
        E8 = null
    };
    g.h.KN = function() {
        this.O = !1;
        Q8(this);
        R8(this, this.u);
        this.A = this.u;
        D8 = !1;
        E8 = null;
        this.player.playVideo()
    };
    g.h.jG = function() {
        this.R = !0;
        Q8(this);
        g.ps("yt-remote-manual-pairing-warning-shown", !0, 2592E3);
        D8 = !1;
        E8 && z8(E8, 1);
        E8 = null
    };
    g.h.Kc = function(a, b) {
        switch (a) {
            case "casting":
                return this.loaded;
            case "receivers":
                return this.T;
            case "currentReceiver":
                return b && ("cast-selector-receiver" == b.key ? O7() : R8(this, b)), this.loaded ? this.A : this.u;
            case "quickCast":
                return 2 == this.T.length && "cast-selector-receiver" == this.T[1].key ? (b && O7(), !0) : !1
        }
    };
    g.h.sG = function() {
        c8(this.o, "sendDebugCommand", {
            debugCommand: "stats4nerds "
        })
    };
    g.h.If = function() {
        return !1
    };
    g.h.getOptions = function() {
        return ["casting", "receivers", "currentReceiver", "quickCast"]
    };
    g.ML.remote = P8;
})(_yt_player);