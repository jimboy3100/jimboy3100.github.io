(function(g) {
    var window = this;
    var Oua = function(a, b) {
            var c = (b - a.o) / (a.u - a.o);
            if (0 >= c) return 0;
            if (1 <= c) return 1;
            for (var d = 0, e = 1, f = 0, k = 0; 8 > k; k++) {
                f = g.Nn(a, c);
                var l = (g.Nn(a, c + 1E-6) - f) / 1E-6;
                if (1E-6 > Math.abs(f - b)) return c;
                if (1E-6 > Math.abs(l)) break;
                else f < b ? d = c : e = c, c -= (f - b) / l
            }
            for (k = 0; 1E-6 < Math.abs(f - b) && 8 > k; k++) f < b ? (d = c, c = (c + e) / 2) : (e = c, c = (c + d) / 2), f = g.Nn(a, c);
            return c
        },
        Pua = function() {
            return g.W ? {
                D: "div",
                Y: ["ytp-icon", "ytp-icon-small-close"]
            } : {
                D: "svg",
                P: {
                    height: "100%",
                    viewBox: "0 0 16 16",
                    width: "100%"
                },
                K: [{
                    D: "path",
                    P: {
                        d: "M13 4L12 3 8 7 4 3 3 4 7 8 3 12 4 13 8 9 12 13 13 12 9 8z",
                        fill: "#fff"
                    }
                }]
            }
        },
        C4 = function() {
            return g.W ? {
                D: "div",
                Y: ["ytp-icon", "ytp-icon-watermark"]
            } : {
                D: "svg",
                P: {
                    height: "100%",
                    version: "1.1",
                    viewBox: "0 0 110 26",
                    width: "100%"
                },
                K: [{
                    D: "path",
                    Oa: !0,
                    I: "ytp-svg-fill",
                    P: {
                        d: "M 16.68,.99 C 13.55,1.03 7.02,1.16 4.99,1.68 c -1.49,.4 -2.59,1.6 -2.99,3 -0.69,2.7 -0.68,8.31 -0.68,8.31 0,0 -0.01,5.61 .68,8.31 .39,1.5 1.59,2.6 2.99,3 2.69,.7 13.40,.68 13.40,.68 0,0 10.70,.01 13.40,-0.68 1.5,-0.4 2.59,-1.6 2.99,-3 .69,-2.7 .68,-8.31 .68,-8.31 0,0 .11,-5.61 -0.68,-8.31 -0.4,-1.5 -1.59,-2.6 -2.99,-3 C 29.11,.98 18.40,.99 18.40,.99 c 0,0 -0.67,-0.01 -1.71,0 z m 72.21,.90 0,21.28 2.78,0 .31,-1.37 .09,0 c .3,.5 .71,.88 1.21,1.18 .5,.3 1.08,.40 1.68,.40 1.1,0 1.99,-0.49 2.49,-1.59 .5,-1.1 .81,-2.70 .81,-4.90 l 0,-2.40 c 0,-1.6 -0.11,-2.90 -0.31,-3.90 -0.2,-0.89 -0.5,-1.59 -1,-2.09 -0.5,-0.4 -1.10,-0.59 -1.90,-0.59 -0.59,0 -1.18,.19 -1.68,.49 -0.49,.3 -1.01,.80 -1.21,1.40 l 0,-7.90 -3.28,0 z m -49.99,.78 3.90,13.90 .18,6.71 3.31,0 0,-6.71 3.87,-13.90 -3.37,0 -1.40,6.31 c -0.4,1.89 -0.71,3.19 -0.81,3.99 l -0.09,0 c -0.2,-1.1 -0.51,-2.4 -0.81,-3.99 l -1.37,-6.31 -3.40,0 z m 29.59,0 0,2.71 3.40,0 0,17.90 3.28,0 0,-17.90 3.40,0 c 0,0 .00,-2.71 -0.09,-2.71 l -9.99,0 z m -53.49,5.12 8.90,5.18 -8.90,5.09 0,-10.28 z m 89.40,.09 c -1.7,0 -2.89,.59 -3.59,1.59 -0.69,.99 -0.99,2.60 -0.99,4.90 l 0,2.59 c 0,2.2 .30,3.90 .99,4.90 .7,1.1 1.8,1.59 3.5,1.59 1.4,0 2.38,-0.3 3.18,-1 .7,-0.7 1.09,-1.69 1.09,-3.09 l 0,-0.5 -2.90,-0.21 c 0,1 -0.08,1.6 -0.28,2 -0.1,.4 -0.5,.62 -1,.62 -0.3,0 -0.61,-0.11 -0.81,-0.31 -0.2,-0.3 -0.30,-0.59 -0.40,-1.09 -0.1,-0.5 -0.09,-1.21 -0.09,-2.21 l 0,-0.78 5.71,-0.09 0,-2.62 c 0,-1.6 -0.10,-2.78 -0.40,-3.68 -0.2,-0.89 -0.71,-1.59 -1.31,-1.99 -0.7,-0.4 -1.48,-0.59 -2.68,-0.59 z m -50.49,.09 c -1.09,0 -2.01,.18 -2.71,.68 -0.7,.4 -1.2,1.12 -1.49,2.12 -0.3,1 -0.5,2.27 -0.5,3.87 l 0,2.21 c 0,1.5 .10,2.78 .40,3.78 .2,.9 .70,1.62 1.40,2.12 .69,.5 1.71,.68 2.81,.78 1.19,0 2.08,-0.28 2.78,-0.68 .69,-0.4 1.09,-1.09 1.49,-2.09 .39,-1 .49,-2.30 .49,-3.90 l 0,-2.21 c 0,-1.6 -0.2,-2.87 -0.49,-3.87 -0.3,-0.89 -0.8,-1.62 -1.49,-2.12 -0.7,-0.5 -1.58,-0.68 -2.68,-0.68 z m 12.18,.09 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.18,-0.70 -0.18,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .18,2.39 .68,3.09 .49,.7 1.21,1 2.21,1 1.4,0 2.48,-0.69 3.18,-2.09 l .09,0 .31,1.78 2.59,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 17.31,0 0,11.90 c -0.1,.3 -0.29,.48 -0.59,.68 -0.2,.2 -0.51,.31 -0.81,.31 -0.3,0 -0.58,-0.10 -0.68,-0.40 -0.1,-0.3 -0.21,-0.70 -0.21,-1.40 l 0,-10.99 -3.40,0 0,11.21 c 0,1.4 .21,2.39 .71,3.09 .5,.7 1.18,1 2.18,1 1.39,0 2.51,-0.69 3.21,-2.09 l .09,0 .28,1.78 2.62,0 0,-14.99 c 0,0 -3.40,.00 -3.40,-0.09 z m 20.90,2.09 c .4,0 .58,.11 .78,.31 .2,.3 .30,.59 .40,1.09 .1,.5 .09,1.21 .09,2.21 l 0,1.09 -2.5,0 0,-1.09 c 0,-1 -0.00,-1.71 .09,-2.21 0,-0.4 .11,-0.8 .31,-1 .2,-0.3 .51,-0.40 .81,-0.40 z m -50.49,.12 c .5,0 .8,.18 1,.68 .19,.5 .28,1.30 .28,2.40 l 0,4.68 c 0,1.1 -0.08,1.90 -0.28,2.40 -0.2,.5 -0.5,.68 -1,.68 -0.5,0 -0.79,-0.18 -0.99,-0.68 -0.2,-0.5 -0.31,-1.30 -0.31,-2.40 l 0,-4.68 c 0,-1.1 .11,-1.90 .31,-2.40 .2,-0.5 .49,-0.68 .99,-0.68 z m 39.68,.09 c .3,0 .61,.10 .81,.40 .2,.3 .27,.67 .37,1.37 .1,.6 .12,1.51 .12,2.71 l .09,1.90 c 0,1.1 .00,1.99 -0.09,2.59 -0.1,.6 -0.19,1.08 -0.49,1.28 -0.2,.3 -0.50,.40 -0.90,.40 -0.3,0 -0.51,-0.08 -0.81,-0.18 -0.2,-0.1 -0.39,-0.29 -0.59,-0.59 l 0,-8.5 c .1,-0.4 .29,-0.7 .59,-1 .3,-0.3 .60,-0.40 .90,-0.40 z"
                    }
                }]
            }
        },
        Qua = function() {
            return g.W ? {
                D: "div",
                Y: ["ytp-icon", "ytp-icon-youtube-logo-redirect"]
            } : {
                D: "svg",
                P: {
                    fill: "#fff",
                    height: "100%",
                    viewBox: "0 0 24 24",
                    width: "100%"
                },
                K: [{
                    D: "path",
                    P: {
                        d: "M0 0h24v24H0V0z",
                        fill: "none"
                    }
                }, {
                    D: "path",
                    P: {
                        d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                    }
                }]
            }
        },
        D4 = function(a) {
            g.y.call(this);
            this.B = a;
            this.A = new g.Mn(0, 0, .4, 0, .2, 1, 1, 1);
            this.u = new g.rn(this.w, window, this);
            g.A(this, this.u)
        },
        E4 = function(a) {
            g.Q.call(this, {
                D: "div",
                I: "ytp-related-on-error-overlay"
            });
            this.T = this.A = 0;
            this.u = a;
            this.aa = new g.tr(this);
            g.A(this, this.aa);
            a = a.N();
            this.C = [];
            this.w = [];
            this.F = 0;
            this.ba = a.u;
            this.R = new g.Q({
                D: "h2",
                I: "ytp-related-title",
                W: "{{title}}"
            });
            g.A(this, this.R);
            this.R.ca(this.element);
            this.G = new g.Q({
                D: "div",
                I: "ytp-suggestions"
            });
            g.A(this, this.G);
            this.G.ca(this.element);
            this.M = new g.Q({
                D: "button",
                Y: ["ytp-button", "ytp-previous"],
                P: {
                    "aria-label": "Show previous suggested videos"
                },
                K: [g.DM()]
            });
            g.A(this, this.M);
            this.M.ca(this.element);
            this.M.la("click", this.vI, this);
            this.da = new D4((0, g.w)(this.pz, this));
            g.A(this, this.da);
            this.Z = this.B = 0;
            this.U = !0;
            for (var b = 0; 16 > b; b++) {
                var c = new g.Q({
                    D: "a",
                    I: "ytp-suggestion-link",
                    P: {
                        href: "{{link}}",
                        target: a.C,
                        "aria-label": "{{aria_label}}"
                    },
                    K: [{
                        D: "div",
                        I: "ytp-suggestion-image",
                        K: [{
                            D: "div",
                            P: {
                                "data-is-live": "{{is_live}}"
                            },
                            I: "ytp-suggestion-duration",
                            W: "{{duration}}"
                        }]
                    }, {
                        D: "div",
                        I: "ytp-suggestion-title",
                        P: {
                            title: "{{hover_title}}"
                        },
                        W: "{{title}}"
                    }, {
                        D: "div",
                        I: "ytp-suggestion-author",
                        W: "{{views_or_author}}"
                    }]
                });
                g.A(this, c);
                c.ca(this.G.element);
                var d = c.o["ytp-suggestion-link"];
                g.sh(d, "transitionDelay", b / 20 + "s");
                this.aa.L(d, "click", g.Qa(this.wI, b));
                this.C.push(c)
            }
            this.H = new g.Q({
                D: "button",
                Y: ["ytp-button", "ytp-next"],
                P: {
                    "aria-label": "Show more suggested videos"
                },
                K: [g.EM()]
            });
            g.A(this, this.H);
            this.H.ca(this.element);
            this.H.la("click", this.uI, this);
            this.aa.L(this.u, "videodatachange", this.oz);
            Rua(this, g.SK(this.u).getPlayerSize());
            this.oz();
            this.show()
        },
        Rua = function(a, b, c) {
            var d = a.u.N(),
                e = 16 / 9,
                f = 650 <= b.width,
                k = 480 > b.width || 290 > b.height,
                l = Math.min(a.w.length, a.C.length);
            if (150 >= Math.min(b.width, b.height) || 0 == l || !d.xa) a.hide();
            else {
                var m;
                if (f) {
                    var n = m = 28;
                    a.A = 16
                } else n = m = 8, a.A = 8;
                if (k) {
                    var q = 6;
                    f = 14;
                    var t = 12;
                    k = 24;
                    d = 12
                } else q = 8, f = 18, t = 16, k = 36, d = 16;
                b = b.width - (48 + m + n);
                m = Math.ceil(b / 150);
                m = Math.min(3, m);
                m = b / m - a.A;
                n = Math.floor(m / e);
                c && n + 100 > c && 50 < m && (n = Math.max(c, 50 / e), m = Math.ceil(b / (e * (n - 100) + a.A)), m = b / m - a.A, n = Math.floor(m / e));
                50 > m || g.UK(a.u) ? a.hide() : a.show();
                for (c = 0; c < l; c++) {
                    e = a.C[c];
                    var u = e.o["ytp-suggestion-image"];
                    u.style.width = m + "px";
                    u.style.height = n + "px";
                    e.o["ytp-suggestion-title"].style.width =
                        m + "px";
                    e.o["ytp-suggestion-author"].style.width = m + "px";
                    e = e.o["ytp-suggestion-duration"];
                    e.style.display = e && 100 > m ? "none" : ""
                }
                l = f + q + t + 4;
                a.T = l + d + (n - k) / 2;
                a.G.element.style.height = n + l + "px";
                a.Z = m;
                a.F = b;
                a.B = 0;
                a.pz(0);
                F4(a)
            }
        },
        Sua = function(a, b) {
            var c = g.Md(b, a.F - a.w.length * (a.Z + a.A), 0);
            a.da.start(a.B, c, 1E3);
            a.B = c;
            F4(a)
        },
        F4 = function(a) {
            a.H.element.style.bottom = a.T + "px";
            a.M.element.style.bottom = a.T + "px";
            var b = a.B,
                c = a.F - a.w.length * (a.Z + a.A);
            g.J(a.element, "ytp-scroll-min", 0 <= b);
            g.J(a.element, "ytp-scroll-max", b <= c)
        },
        Tua = function(a) {
            for (var b = 0; b < a.w.length; b++) {
                var c = b,
                    d = a.w[b].Ba();
                c = a.C[c];
                var e = d.shortViewCount ? d.shortViewCount : d.author,
                    f = d.eh();
                g.zy(a.u.N()) && (f = g.yd(f, g.sH({}, "emb_rel_err")));
                c.element.style.display = "";
                var k = c.o["ytp-suggestion-title"];
                g.Kn.test(d.title) ? k.dir = "rtl" : g.cra.test(d.title) && (k.dir = "ltr");
                k = c.o["ytp-suggestion-author"];
                g.Kn.test(e) ? k.dir = "rtl" : g.cra.test(e) && (k.dir = "ltr");
                k = void 0;
                d.ya ? k = "Live" : k = d.lengthSeconds ? g.jM(d.lengthSeconds) : "";
                c.update({
                    views_or_author: e,
                    duration: k,
                    link: f,
                    hover_title: d.title,
                    title: d.title,
                    aria_label: d.Rk || null,
                    is_live: d.ya
                });
                c = c.o["ytp-suggestion-image"];
                d = d.oc();
                c.style.backgroundImage = d ? "url(" + d + ")" : ""
            }
            for (; b < a.C.length; b++) a.C[b].element.style.display = "none";
            F4(a)
        },
        G4 = function(a) {
            g.RP.call(this, a);
            a = a.N();
            a = new g.Q({
                D: "a",
                I: "ytp-small-redirect",
                P: {
                    href: g.iz(a),
                    target: a.C,
                    "aria-label": "Visit YouTube to search for more videos"
                },
                K: [Qua()]
            });
            a.ca(this.element);
            g.A(this, a);
            this.w = new E4(this.api);
            this.w.ca(this.element);
            g.A(this, this.w);
            this.B = 1;
            this.u(g.SK(this.api).getPlayerSize())
        },
        Uua = function(a, b) {
            a.o["ytp-error-content"].style.paddingTop = "0px";
            var c = a.o["ytp-error-content"],
                d = c.clientHeight;
            Rua(a.w, b, b.height - d);
            if (a.api.N().F) {
                var e = g.MM(),
                    f = g.W ? {
                        D: "div",
                        Y: ["ytp-icon", "ytp-icon-youtube-logo-redirect-large"]
                    } : {
                        D: "svg",
                        P: {
                            fill: "#fff",
                            viewBox: "0 0 24 24"
                        },
                        K: [{
                            D: "path",
                            P: {
                                d: "M0 0h24v24H0V0z",
                                fill: "none"
                            }
                        }, {
                            D: "path",
                            P: {
                                d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                            }
                        }]
                    },
                    k = 1;
                480 > b.width || 290 > b.height ? (e = {
                    D: "div",
                    Y: ["ytp-icon", "ytp-icon-error-exclamation-small"]
                }, f = Qua(), k = 0) : 650 <= b.width && (e = {
                        D: "div",
                        Y: ["ytp-icon", "ytp-icon-error-exclamation-large"]
                    }, f = g.W ? {
                        D: "div",
                        Y: ["ytp-icon", "ytp-icon-youtube-logo-redirect-extra-large"]
                    } : {
                        D: "svg",
                        P: {
                            fill: "#fff",
                            height: "100%",
                            viewBox: "0 0 24 24",
                            width: "100%"
                        },
                        K: [{
                            D: "path",
                            P: {
                                d: "M0 0h24v24H0V0z",
                                fill: "none"
                            }
                        }, {
                            D: "path",
                            P: {
                                d: "M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81zM10 15V9l5.2 3-5.2 3z"
                            }
                        }]
                    },
                    k = 2);
                if (k !== a.B) {
                    e = {
                        "ytp-error-icon-container": e,
                        "ytp-small-redirect": f
                    };
                    f = g.p(Object.keys(e));
                    for (var l = f.next(); !l.done; l = f.next()) {
                        l = l.value;
                        var m = g.ce(l, a.element);
                        g.re(m);
                        (new g.Q(e[l])).ca(m)
                    }
                    a.B = k
                }
            }
            c.style.paddingTop = (b.height - a.w.element.clientHeight) / 2 - d / 2 + "px"
        },
        H4 = function(a, b) {
            var c = a.N();
            g.Q.call(this, {
                D: "button",
                Y: ["ytp-impression-link", "ytp-button"]
            });
            this.hide();
            this.u = a;
            this.B = b;
            this.A = !1;
            g.mL(a, this.element, this, 96714);
            var d = this.u.N(),
                e = this.u.getVideoData().jc,
                f = d.za,
                k = d.Rf;
            d = !d.xa;
            var l = this.B.Kd();
            f || k || l || e || d || (g.O(c.experiments, "embeds_impression_link_call_to_action") && (g.I(this.element, "show-cta-button"), (new g.Q({
                    D: "div",
                    I: "ytp-impression-link-content",
                    K: [{
                        D: "div",
                        I: "ytp-impression-link-text",
                        W: "Watch on"
                    }, {
                        D: "div",
                        I: "ytp-impression-link-logo",
                        K: [C4()]
                    }]
                })).ca(this.element),
                this.show()), g.O(c.experiments, "embeds_impression_link_video_thumbnail") && Vua(this), g.O(c.experiments, "embeds_impression_link_channel_thumbnail") && Wua(this), g.O(c.experiments, "embeds_impression_link_occlusion") && Xua(this), g.O(c.experiments, "embeds_impression_link_hover") && Yua(this), this.L(a, "presentingplayerstatechange", this.F), this.L(a, "videoplayerreset", this.G), this.L(this.element, "click", this.C))
        },
        Vua = function(a) {
            var b, c, d, e, f;
            g.Aa(function(k) {
                if (1 == k.o) return b = a.u.getVideoData(), g.sa(k, I4(a, b), 2);
                c = k.u;
                if (!c) return k["return"]();
                d = c[0];
                a.w = d;
                g.I(a.element, "show-video-thumbnail-button");
                e = new g.Q({
                    D: "div",
                    I: "ytp-impression-link-header",
                    W: "More from YouTube"
                });
                e.ca(a.element);
                f = new g.Q({
                    D: "div",
                    I: "ytp-impression-link-content",
                    K: [{
                        D: "div",
                        I: "ytp-impression-link-metadata",
                        K: [{
                            D: "div",
                            I: "ytp-impression-link-title",
                            W: d.title
                        }, {
                            D: "div",
                            I: "ytp-impression-link-views-and-duration",
                            W: "{{views_and_duration}}"
                        }]
                    }, {
                        D: "div",
                        I: "ytp-impression-link-thumbnail"
                    }]
                });
                f.ca(a.element);
                J4(a, f, d);
                K4(a, f, d);
                a.show();
                k.o = 0
            })
        },
        Wua = function(a) {
            var b, c, d;
            g.Aa(function(e) {
                if (1 == e.o) return g.sa(e, Zua(a), 2);
                b = e.u;
                if (!b) return e["return"]();
                a.w = b;
                g.I(a.element, "show-channel-thumbnail-button");
                c = new g.Q({
                    D: "div",
                    I: "ytp-impression-link-header",
                    W: "More from YouTube"
                });
                c.ca(a.element);
                d = new g.Q({
                    D: "div",
                    I: "ytp-impression-link-content",
                    K: [{
                        D: "div",
                        I: "ytp-impression-link-metadata",
                        K: [{
                            D: "div",
                            I: "ytp-impression-link-title",
                            W: b.ll
                        }, {
                            D: "div",
                            I: "ytp-impression-link-subscribers",
                            W: b.expandedSubtitle
                        }]
                    }, {
                        D: "div",
                        I: "ytp-impression-link-thumbnail"
                    }]
                });
                d.ca(a.element);
                J4(a, d, b);
                a.show();
                e.o = 0
            })
        },
        Xua = function(a) {
            var b, c, d, e, f, k, l, m, n, q;
            g.Aa(function(t) {
                if (1 == t.o) return b = a.u.getVideoData(), g.sa(t, I4(a, b), 2);
                c = t.u;
                if (!c) return t["return"]();
                d = c[0];
                a.w = d;
                g.I(a.element, "show-occlusion-video-thumbnail-button");
                e = new g.Q({
                    D: "div",
                    I: "ytp-impression-link-header",
                    W: "More from YouTube"
                });
                e.ca(a.element);
                f = new g.Q({
                    D: "div",
                    I: "ytp-impression-link-content",
                    K: [{
                        D: "div",
                        I: "ytp-impression-link-metadata",
                        K: [{
                            D: "div",
                            I: "ytp-impression-link-title",
                            W: d.title
                        }, {
                            D: "div",
                            I: "ytp-impression-link-author",
                            W: d.author
                        }, {
                            D: "div",
                            I: "ytp-impression-link-views",
                            W: "{{views}}"
                        }]
                    }, {
                        D: "div",
                        I: "ytp-impression-link-thumbnail-and-duration",
                        K: [{
                            D: "div",
                            I: "ytp-impression-link-thumbnail"
                        }, {
                            D: "div",
                            I: "ytp-impression-link-duration",
                            W: "{{duration}}"
                        }]
                    }]
                });
                f.ca(a.element);
                J4(a, f, d);
                K4(a, f, d);
                k = new g.Q({
                    D: "button",
                    Y: ["ytp-button", "ytp-impression-link-close"],
                    K: [{
                        D: "div",
                        Y: ["ytp-impression-link-close-icon"],
                        K: [Pua()]
                    }]
                });
                k.ca(a.element);
                k.la("click", function(u) {
                    a.hide();
                    g.qL(a.u, a.element, !1);
                    u.stopPropagation()
                }, a);
                l = function(u) {
                    !g.p(u).next().value.isIntersecting && a.element && a.show()
                };
                try {
                    m = {
                        threshold: .8
                    }, n = new IntersectionObserver(l, m), q = document.querySelector("body"), n.observe(q)
                } catch (u) {
                    g.L(u)
                }
                t.o = 0
            })
        },
        Yua = function(a) {
            var b, c, d, e, f;
            g.Aa(function(k) {
                if (1 == k.o) return b = a.u.getVideoData(), g.sa(k, I4(a, b), 2);
                c = k.u;
                if (!c) return k["return"]();
                d = c[0];
                a.w = d;
                g.I(a.element, "show-video-thumbnail-expanding-button");
                a.L(a.element, "mouseenter", function() {
                    g.I(a.element, "show-expanded-metadata");
                    g.Dn(a.element, "show-collapsed-metadata")
                });
                a.L(a.element, "mouseleave", function() {
                    g.Dn(a.element, "show-expanded-metadata");
                    g.I(a.element, "show-collapsed-metadata")
                });
                e = new g.Q({
                    D: "div",
                    I: "ytp-impression-link-header",
                    W: "More videos"
                });
                e.ca(a.element);
                f = new g.Q({
                    D: "div",
                    I: "ytp-impression-link-content",
                    K: [{
                        D: "div",
                        I: "ytp-impression-link-metadata",
                        K: [{
                            D: "div",
                            I: "ytp-impression-link-title",
                            W: d.title
                        }, {
                            D: "div",
                            I: "ytp-impression-link-views-and-duration",
                            W: "{{views_and_duration}}"
                        }]
                    }, {
                        D: "div",
                        I: "ytp-impression-link-thumbnail"
                    }]
                });
                f.ca(a.element);
                J4(a, f, d);
                K4(a, f, d);
                a.show();
                k.o = 0
            })
        },
        J4 = function(a, b, c) {
            a = g.O(a.u.N().experiments, "embeds_impression_link_channel_thumbnail") ?
                c.Cd : c.oc();
            b.o["ytp-impression-link-thumbnail"].style.backgroundImage = a ? "url(" + a + ")" : ""
        },
        K4 = function(a, b, c) {
            a = a.u.N();
            var d = "";
            c.ya ? d = "Live" : c.lengthSeconds && (d = g.jM(c.lengthSeconds));
            c = c.shortViewCount ? c.shortViewCount : "";
            var e = "";
            c && d ? e = c + " \u2022 " + d : c ? e = c : d && (e = d);
            g.O(a.experiments, "embeds_impression_link_occlusion") ? b.update({
                views: c,
                duration: d
            }) : b.update({
                views_and_duration: e
            })
        },
        $ua = function(a, b) {
            var c, d, e, f, k, l, m, n;
            return g.Aa(function(q) {
                return 1 == q.o ? (c = a.u.N(), d = {
                        format: "RAW",
                        method: "GET",
                        withCredentials: !0,
                        timeout: 3E4
                    }, e = {}, c.sendVisitorIdHeader && b.visitorData && (e["X-Goog-Visitor-Id"] = b.visitorData), (f = g.mt(c.experiments, "debug_dapper_trace_id")) && (e["X-Google-DapperTraceInfo"] = f), (k = g.mt(c.experiments, "debug_sherlog_username")) && (e["X-Youtube-Sherlog-Username"] = k), 0 < Object.keys(e).length && (d.headers = e), l = g.qH(c, b, g.SK(a.u).getPlayerSize(), a.u.getVisibilityState(), 0, ""), l = g.yd(l, {
                        is_embed_preview: "1"
                    }),
                    m = function(t) {
                        return g.L(t)
                    }, g.sa(q, g.yx(g.Vq, l, d).then(void 0, m), 2)) : (n = q.u) && n.responseText ? q["return"](n) : q["return"](null)
            })
        },
        I4 = function(a, b) {
            var c, d, e, f, k, l;
            return g.Aa(function(m) {
                if (1 == m.o) return g.sa(m, $ua(a, b), 2);
                c = m.u;
                if (!c) return m["return"](null);
                d = g.Zp(c.responseText);
                e = g.$p(d.rvs);
                f = (0, g.ue)(e, function(n) {
                    return n && !n.list
                });
                k = a.u.N();
                return (l = (0, g.Dc)(f, function(n) {
                    n = g.lM(k, n);
                    g.A(a, n);
                    return n
                })) && 0 != l.length ? m["return"](l) : m["return"](null)
            })
        },
        Zua = function(a) {
            var b, c, d, e, f, k, l, m;
            return g.Aa(function(n) {
                if (1 == n.o) return b = a.u.getVideoData(), g.sa(n, I4(a, b), 2);
                if (3 != n.o) {
                    c = n.u;
                    if (!c) return n["return"](null);
                    d = b.ll;
                    e = c.filter(function(q) {
                        return null !== q && q.author !== d
                    });
                    return (f = e[0]) ? g.sa(n, $ua(a, f), 3) : n["return"](null)
                }
                k = n.u;
                if (!k) return n["return"](null);
                l = g.Zp(k.responseText);
                m = new g.QA(a.u.N(), l);
                return n["return"](m)
            })
        },
        L4 = function(a) {
            g.Q.call(this, {
                D: "div",
                I: "ytp-muted-autoplay-endscreen-overlay",
                K: [{
                    D: "div",
                    I: "ytp-muted-autoplay-end-panel",
                    K: [{
                        D: "div",
                        I: "ytp-muted-autoplay-end-text",
                        W: "{{text}}"
                    }]
                }]
            });
            this.u = a;
            this.A = this.o["ytp-muted-autoplay-end-panel"];
            this.w = new g.hN(a);
            g.A(this, this.w);
            this.w.ca(this.A, 0);
            g.mL(a, this.element, this, 52428);
            this.L(a, "presentingplayerstatechange", this.C);
            this.la("click", this.B);
            this.hide()
        },
        M4 = function(a) {
            g.Q.call(this, {
                D: "div",
                I: "ytp-muted-autoplay-overlay",
                K: [{
                    D: "div",
                    I: "ytp-muted-autoplay-bottom-buttons",
                    K: [{
                        D: "button",
                        Y: ["ytp-muted-autoplay-equalizer", "ytp-button"],
                        K: [{
                            D: "div",
                            Y: ["ytp-muted-autoplay-equalizer-icon"],
                            K: [g.W ? {
                                D: "div",
                                Y: ["ytp-icon", "ytp-icon-equalizer-animation"]
                            } : {
                                D: "svg",
                                P: {
                                    height: "100%",
                                    version: "1.1",
                                    viewBox: "-4 -4 24 24",
                                    width: "100%"
                                },
                                K: [{
                                    D: "g",
                                    P: {
                                        fill: "#fff"
                                    },
                                    K: [{
                                        D: "rect",
                                        I: "ytp-equalizer-bar-left",
                                        P: {
                                            height: "9",
                                            width: "4",
                                            x: "1",
                                            y: "7"
                                        }
                                    }, {
                                        D: "rect",
                                        I: "ytp-equalizer-bar-middle",
                                        P: {
                                            height: "14",
                                            width: "4",
                                            x: "6",
                                            y: "2"
                                        }
                                    }, {
                                        D: "rect",
                                        I: "ytp-equalizer-bar-right",
                                        P: {
                                            height: "12",
                                            width: "4",
                                            x: "11",
                                            y: "4"
                                        }
                                    }]
                                }]
                            }]
                        }]
                    }]
                }]
            });
            this.u = a;
            this.bottomButtons = this.o["ytp-muted-autoplay-bottom-buttons"];
            this.A = this.o["ytp-muted-autoplay-equalizer"];
            this.B = new g.H(this.C, 4E3, this);
            g.mL(a, this.element, this, 39306);
            this.L(a, "presentingplayerstatechange", this.w);
            this.L(a, "onMutedAutoplayStarts", this.w);
            this.la("click", this.F);
            this.hide()
        },
        N4 = function(a, b) {
            g.Q.call(this, {
                D: "div",
                I: "ytp-pause-overlay"
            });
            this.u = a;
            this.ba = b;
            this.A = new g.tr(this);
            g.A(this, this.A);
            this.U = new g.fN(this, 1E3, !1, 100);
            g.A(this, this.U);
            var c = a.N();
            "0" == c.controlsType && g.I(a.getRootNode(), "ytp-pause-overlay-controls-hidden");
            this.C = [];
            this.w = [];
            this.F = 0;
            this.da = c.u;
            this.Z = !1;
            this.na = 0;
            this.T = new g.Q({
                D: "h2",
                I: "ytp-related-title",
                W: "{{title}}"
            });
            g.A(this, this.T);
            this.T.ca(this.element);
            this.G = new g.Q({
                D: "div",
                I: "ytp-suggestions"
            });
            g.A(this, this.G);
            this.G.ca(this.element);
            this.R = new g.Q({
                D: "button",
                Y: ["ytp-button",
                    "ytp-previous"
                ],
                P: {
                    "aria-label": "Show previous suggested videos"
                },
                K: [g.DM()]
            });
            g.A(this, this.R);
            this.R.ca(this.element);
            this.R.la("click", this.qI, this);
            var d = g.pt || g.vh ? {
                style: "will-change: opacity"
            } : null;
            this.ea = new D4((0, g.w)(this.nz, this));
            g.A(this, this.ea);
            for (var e = this.ia = this.aa = this.B = 0; 16 > e; e++) {
                var f = new g.Q({
                    D: "a",
                    I: "ytp-suggestion-link",
                    P: {
                        href: "{{link}}",
                        target: c.C,
                        "aria-label": "{{aria_label}}"
                    },
                    K: [{
                        D: "div",
                        I: "ytp-suggestion-image"
                    }, {
                        D: "div",
                        I: "ytp-suggestion-overlay",
                        P: d,
                        K: [{
                            D: "div",
                            I: "ytp-suggestion-title",
                            W: "{{title}}"
                        }, {
                            D: "div",
                            I: "ytp-suggestion-author",
                            W: "{{author_and_views}}"
                        }, {
                            D: "div",
                            P: {
                                "data-is-live": "{{is_live}}"
                            },
                            I: "ytp-suggestion-duration",
                            W: "{{duration}}"
                        }]
                    }]
                });
                g.A(this, f);
                f.ca(this.G.element);
                var k = f.o["ytp-suggestion-link"];
                g.sh(k, "transitionDelay", e / 20 + "s");
                this.A.L(k, "click", g.Qa(this.rI, e));
                this.C.push(f)
            }
            this.M = new g.Q({
                D: "button",
                Y: ["ytp-button", "ytp-next"],
                P: {
                    "aria-label": "Show more suggested videos"
                },
                K: [g.EM()]
            });
            g.A(this, this.M);
            this.M.ca(this.element);
            this.M.la("click", this.pI, this);
            c = new g.Q({
                D: "button",
                Y: ["ytp-button", "ytp-collapse"],
                P: {
                    "aria-label": "Hide more videos"
                },
                K: [Pua()]
            });
            g.A(this, c);
            c.ca(this.element);
            c.la("click", this.rK, this);
            this.H = new g.Q({
                D: "button",
                Y: ["ytp-button", "ytp-expand"],
                W: "More videos"
            });
            g.A(this, this.H);
            this.H.ca(this.element);
            this.H.la("click", this.sK, this);
            this.A.L(this.u, "appresize", this.ot);
            this.A.L(this.u, "fullscreentoggled", this.sI);
            this.A.L(this.u, "presentingplayerstatechange", this.tI);
            this.A.L(this.u, "videodatachange",
                this.mz);
            this.ot(g.SK(this.u).getPlayerSize());
            this.mz()
        },
        ava = function(a, b) {
            var c = g.Md(b, a.F - a.w.length * (a.aa + 8), 0);
            a.ea.start(a.B, c, 1E3);
            a.B = c;
            O4(a)
        },
        O4 = function(a) {
            var b = a.ba.hc();
            b = a.ia / 2 + (b ? 32 : 16);
            a.M.element.style.bottom = b + "px";
            a.R.element.style.bottom = b + "px";
            b = a.B;
            var c = a.F - a.w.length * (a.aa + 8);
            g.J(a.element, "ytp-scroll-min", 0 <= b);
            g.J(a.element, "ytp-scroll-max", b <= c)
        },
        bva = function(a) {
            for (var b = 0; b < a.w.length; b++) {
                var c = a.w[b].Ba(),
                    d = a.C[b],
                    e = c.shortViewCount ? c.author + " \u2022 " + c.shortViewCount : c.author;
                d.element.style.display = "";
                g.bra.test(c.title) && (d.o["ytp-suggestion-title"].dir = "rtl");
                g.bra.test(e) && (d.o["ytp-suggestion-author"].dir = "rtl");
                var f = void 0;
                c.ya ? f = "Live" : f = c.lengthSeconds ? g.jM(c.lengthSeconds) : "";
                var k = c.eh();
                g.zy(a.u.N()) && (k = g.yd(k, g.sH({}, "emb_rel_pause")));
                d.update({
                    author_and_views: e,
                    duration: f,
                    link: k,
                    title: c.title,
                    aria_label: c.Rk || null,
                    is_live: c.ya
                });
                d = d.o["ytp-suggestion-image"];
                c = c.oc();
                d.style.backgroundImage = c ? "url(" + c + ")" : ""
            }
            for (; b < a.C.length; b++) a.C[b].element.style.display =
                "none";
            O4(a)
        },
        P4 = function(a) {
            var b = a.N();
            g.Q.call(this, {
                D: "a",
                Y: ["ytp-watermark", "yt-uix-sessionlink"],
                P: {
                    target: b.C,
                    href: "{{url}}",
                    "aria-label": g.iM("Watch on $WEBSITE", {
                        WEBSITE: g.Uy(b)
                    }),
                    "data-sessionlink": "feature=player-watermark"
                },
                K: [C4()]
            });
            this.u = a;
            this.A = null;
            this.B = !1;
            this.w = g.RK(a);
            g.mL(a, this.element, this, 76758);
            this.L(a, "videodatachange", this.qt);
            this.L(a, "videodatachange", this.rz);
            this.L(a, "presentingplayerstatechange", this.yI);
            this.L(a, "appresize", this.qz);
            b = this.w;
            this.w != b && (this.w = b);
            this.qt();
            this.rz();
            this.qz(g.SK(a).getPlayerSize())
        },
        Q4 = function(a) {
            g.xL.call(this, a);
            this.o = a;
            this.B = new g.tr(this);
            g.A(this, this.B);
            this.load()
        },
        cva = function(a, b) {
            g.U(b, 128) ? (a.u || (a.u = new G4(a.o), g.A(a, a.u), g.kL(a.o, a.u.element, 4)), a.u.A(b.u), a.u.show(), g.I(a.o.getRootNode(), "ytp-embed-error")) : a.u && (a.u.dispose(), a.u = null, g.Dn(a.o.getRootNode(), "ytp-embed-error"))
        };
    g.r(D4, g.y);
    D4.prototype.start = function(a, b, c) {
        this.o = a;
        this.G = b;
        this.C = c;
        this.F = (0, g.M)();
        this.w()
    };
    D4.prototype.w = function() {
        var a = (0, g.M)() - this.F;
        var b = this.A;
        a = Oua(b, a / this.C);
        if (0 == a) b = b.B;
        else if (1 == a) b = b.G;
        else {
            var c = g.Od(b.B, b.C, a),
                d = g.Od(b.C, b.F, a);
            b = g.Od(b.F, b.G, a);
            c = g.Od(c, d, a);
            d = g.Od(d, b, a);
            b = g.Od(c, d, a)
        }
        b = g.Md(b, 0, 1);
        this.B((this.G - this.o) * b + this.o);
        1 > b && this.u.start()
    };
    g.r(E4, g.Q);
    g.h = E4.prototype;
    g.h.hide = function() {
        this.U = !0;
        g.Q.prototype.hide.call(this)
    };
    g.h.show = function() {
        this.U = !1;
        g.Q.prototype.show.call(this)
    };
    g.h.isHidden = function() {
        return this.U
    };
    g.h.uI = function() {
        Sua(this, this.B - this.F)
    };
    g.h.vI = function() {
        Sua(this, this.B + this.F)
    };
    g.h.wI = function(a, b) {
        var c = this.w[a],
            d = c.Nb;
        if (g.CN(b, this.u, this.ba, d || void 0)) {
            var e = c.Ba().videoId;
            c = c.getPlaylistId();
            g.jT(this.u.app, e, d, c, void 0, void 0)
        }
    };
    g.h.oz = function() {
        var a = this,
            b = this.u.getVideoData(),
            c = this.u.N();
        this.ba = b.jc ? !1 : c.u;
        if (b.suggestions) {
            var d = (0, g.ue)(b.suggestions, function(e) {
                return e && !e.list
            });
            this.w = (0, g.Dc)(d, function(e) {
                e = g.lM(c, e);
                g.A(a, e);
                return e
            })
        } else this.w.length = 0;
        Tua(this);
        b.jc ? this.R.update({
            title: g.iM("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: b.author
            })
        }) : this.R.update({
            title: "More videos on YouTube"
        })
    };
    g.h.pz = function(a) {
        this.G.element.scrollLeft = -a
    };
    g.r(G4, g.RP);
    G4.prototype.show = function() {
        g.RP.prototype.show.call(this);
        Uua(this, g.SK(this.api).getPlayerSize())
    };
    G4.prototype.u = function(a) {
        g.RP.prototype.u.call(this, a);
        Uua(this, a);
        g.J(this.element, "related-on-error-overlay-visible", !this.w.isHidden())
    };
    G4.prototype.A = function(a) {
        g.RP.prototype.A.call(this, a);
        var b = this.api.getVideoData(),
            c = g.O(this.api.N().experiments, "embeds_enable_sg_misinfo"),
            d;
        if (a.Vg) {
            if (b.Mn) {
                a: {
                    a = b.Mn;
                    if (a.runs)
                        for (var e = 0; e < a.runs.length; e++)
                            if (a.runs[e].navigationEndpoint) {
                                a = !0;
                                break a
                            }
                    a = !1
                }
                a ? d = g.Nz(b.Mn) : d = g.SP(g.S(b.Mn))
            }
            else d = g.SP(a.Vg);
            this.ob(d, "subreason")
        }(b = b.Lw) && c && (c = b.embeddedPlayerErrorMessageRenderer, c.reason && (b = g.Nz(c.reason), this.ob(b, "content")), c.subreason && (c = g.Nz(c.subreason), this.ob(c, "subreason")))
    };
    g.r(H4, g.Q);
    H4.prototype.F = function() {
        g.RK(this.u).isCued() || (this.hide(), g.qL(this.u, this.element, !1))
    };
    H4.prototype.G = function() {
        this.A = !0;
        this.hide();
        g.qL(this.u, this.element, !1)
    };
    H4.prototype.C = function(a) {
        var b = this.u.N();
        b = g.O(b.experiments, "embeds_impression_link_channel_thumbnail") ? g.iz(b) + this.w.kf : g.O(b.experiments, "embeds_impression_link_call_to_action") ? this.u.getVideoUrl() : this.w.eh();
        var c = this.u.N();
        c = g.O(c.experiments, "embeds_impression_link_call_to_action") ? "emb_imp_woyt" : g.O(c.experiments, "embeds_impression_link_video_thumbnail") ? "emb_imp_rv" : g.O(c.experiments, "embeds_impression_link_channel_thumbnail") ? "emb_imp_rc" : g.O(c.experiments, "embeds_impression_link_occlusion") ?
            "emb_imp_rv_oc" : "emb_imp_rv_ex";
        b = g.yd(b, g.sH({}, c));
        g.DN(b, this.u, a);
        g.pL(this.u, this.element)
    };
    H4.prototype.show = function() {
        g.RK(this.u).isCued() && !this.A && (g.Q.prototype.show.call(this), g.rL(this.u, this.element) && g.qL(this.u, this.element, !0))
    };
    g.r(L4, g.Q);
    L4.prototype.C = function() {
        var a = g.RK(this.u),
            b = this.u.getVideoData();
        g.O(this.u.N().experiments, "embeds_enable_muted_autoplay") && b.mutedAutoplay && (g.U(a, 2) && !this.Ka() ? (this.show(), this.w.show(), a = this.u.getVideoData(), this.ma("text", a.Qz), g.J(this.element, "ytp-muted-autoplay-show-end-panel", !0), g.qL(this.u, this.element, this.Ka()), this.u.oa("onMutedAutoplayEnds")) : this.hide())
    };
    L4.prototype.B = function() {
        var a = this.u.getVideoData(),
            b = this.u.getCurrentTime();
        a.mutedAutoplay = !1;
        a.endSeconds = NaN;
        a.Dd();
        this.u.loadVideoById(a.videoId, b);
        g.pL(this.u, this.element);
        this.hide()
    };
    g.r(M4, g.Q);
    M4.prototype.w = function() {
        var a = g.RK(this.u),
            b = this.u.getVideoData(),
            c = this.u.N();
        b = g.O(c.experiments, "embeds_enable_muted_autoplay") && b.mutedAutoplay;
        c = !c.F;
        !b || g.U(a, 2) ? this.hide() : this.Ka() || (g.Q.prototype.show.call(this), c || (this.A.style.display = "none"), this.B.start(), g.qL(this.u, this.element, this.Ka()))
    };
    M4.prototype.C = function() {
        g.J(this.element, "ytp-muted-autoplay-hide-watermark", !0)
    };
    M4.prototype.F = function() {
        var a = this.u.getVideoData(),
            b = this.u.getCurrentTime();
        a.mutedAutoplay = !1;
        a.endSeconds = NaN;
        a.Dd();
        this.u.loadVideoById(a.videoId, b);
        g.pL(this.u, this.element)
    };
    g.r(N4, g.Q);
    g.h = N4.prototype;
    g.h.hide = function() {
        g.Dn(this.u.getRootNode(), "ytp-expand-pause-overlay");
        g.Q.prototype.hide.call(this)
    };
    g.h.rK = function() {
        this.Z = !0;
        g.Dn(this.u.getRootNode(), "ytp-expand-pause-overlay");
        this.H.focus()
    };
    g.h.sK = function() {
        this.Z = !1;
        g.I(this.u.getRootNode(), "ytp-expand-pause-overlay")
    };
    g.h.pI = function() {
        ava(this, this.B - this.F)
    };
    g.h.qI = function() {
        ava(this, this.B + this.F)
    };
    g.h.rI = function(a, b) {
        if (1E3 > (0, g.M)() - this.na) g.jp(b), document.activeElement.blur();
        else {
            var c = this.w[a],
                d = c.Nb;
            if (g.CN(b, this.u, this.da, d || void 0)) {
                var e = c.Ba().videoId;
                c = c.getPlaylistId();
                g.jT(this.u.app, e, d, c, void 0, void 0)
            }
        }
    };
    g.h.sI = function() {
        this.ot(g.SK(this.u).getPlayerSize())
    };
    g.h.tI = function(a) {
        if (!(g.U(a.state, 1) || g.U(a.state, 16) || g.U(a.state, 32))) {
            var b = !g.O(this.u.N().experiments, "embeds_disable_pauseoverlay_on_autoplay_blocked_killswitch") && g.U(a.state, 2048);
            !g.U(a.state, 4) || g.U(a.state, 2) || b ? this.U.hide() : this.w.length && (this.Z || (g.I(this.u.getRootNode(), "ytp-expand-pause-overlay"), O4(this)), this.U.show(), this.na = (0, g.M)())
        }
    };
    g.h.ot = function(a) {
        var b = 16 / 9,
            c = this.ba.hc();
        a = a.width - (c ? 112 : 58);
        c = Math.ceil(a / (c ? 320 : 192));
        c = (a - 8 * c) / c;
        b = Math.floor(c / b);
        for (var d = 0; d < this.C.length; d++) {
            var e = this.C[d].o["ytp-suggestion-image"];
            e.style.width = c + "px";
            e.style.height = b + "px"
        }
        this.G.element.style.height = b + "px";
        this.aa = c;
        this.ia = b;
        this.F = a;
        this.B = 0;
        this.nz(0);
        O4(this)
    };
    g.h.mz = function() {
        var a = this,
            b = this.u.N(),
            c = this.u.getVideoData();
        this.da = c.jc ? !1 : b.u;
        if (c.suggestions) {
            var d = (0, g.ue)(c.suggestions, function(e) {
                return e && !e.list
            });
            this.w = (0, g.Dc)(d, function(e) {
                e = g.lM(b, e);
                g.A(a, e);
                return e
            })
        } else this.w.length = 0;
        bva(this);
        c.jc ? this.T.update({
            title: g.iM("More videos from $DNI_RELATED_CHANNEL", {
                DNI_RELATED_CHANNEL: c.author
            })
        }) : this.T.update({
            title: "More videos"
        })
    };
    g.h.nz = function(a) {
        this.G.element.scrollLeft = -a
    };
    g.r(P4, g.Q);
    g.h = P4.prototype;
    g.h.qt = function() {
        var a = this.u.getVideoData(),
            b = this.u.N();
        a = a.mutedAutoplay || b.za && !g.U(this.w, 2);
        g.Eu(this, a);
        g.qL(this.u, this.element, a)
    };
    g.h.yI = function(a) {
        a = a.state;
        this.w != a && (this.w = a);
        this.qt()
    };
    g.h.rz = function() {
        if (this.u.getVideoData().videoId) {
            var a = this.u.getVideoUrl(!0, !1, !1, !0);
            this.ma("url", a);
            this.A || (this.A = this.la("click", this.xI))
        } else this.A && (this.ma("url", null), this.ab(this.A), this.A = null)
    };
    g.h.xI = function(a) {
        var b = this.u.getVideoUrl(!g.kM(a), !1, !0, !0);
        g.DN(b, this.u, a);
        g.pL(this.u, this.element)
    };
    g.h.qz = function(a) {
        var b = this.u.N(),
            c = 480 > a.width;
        if (c && !this.B || !c && this.B) a = 480 > a.width && b.F ? {
            D: "div",
            Y: ["ytp-icon", "ytp-icon-watermark-small"]
        } : C4(), a = new g.Q(a), b = this.o["ytp-watermark"], g.J(b, "ytp-watermark-small", c), g.re(b), a.ca(b), this.B = c
    };
    g.r(Q4, g.xL);
    g.h = Q4.prototype;
    g.h.If = function() {
        return !1
    };
    g.h.create = function() {
        var a = this.o.N(),
            b = g.TB(this.o);
        a.xa && (this.G = new N4(this.o, b), g.A(this, this.G), g.kL(this.o, this.G.element, 4));
        g.O(a.experiments, "embeds_enable_muted_autoplay") && (this.w = new M4(this.o), g.A(this, this.w), g.kL(this.o, this.w.element, 4), this.F = new L4(this.o), g.A(this, this.F), g.kL(this.o, this.F.element, 4));
        if (a.za || this.w) this.A = new P4(this.o), g.A(this, this.A), g.kL(this.o, this.A.element, 7);
        g.O(a.experiments, "embeds_impression_link") && (this.C = new H4(this.o, b), g.A(this, this.C), g.kL(this.o,
            this.C.element, 7));
        this.B.L(this.o, "appresize", this.mI);
        this.B.L(this.o, "presentingplayerstatechange", this.lI);
        this.B.L(this.o, "videodatachange", this.NO);
        this.B.L(this.o, "onMutedAutoplayStarts", this.GL);
        cva(this, g.RK(this.o));
        g.hL(this.player, "embed")
    };
    g.h.mI = function() {
        var a = g.SK(this.o).getPlayerSize();
        this.u && this.u.u(a)
    };
    g.h.lI = function(a) {
        cva(this, a.state)
    };
    g.h.GL = function() {
        this.o.getVideoData().mutedAutoplay && this.w && this.A && this.A.ca(this.w.bottomButtons, 0)
    };
    g.h.NO = function() {
        var a = this.o.getVideoData();
        this.A && this.w && !a.mutedAutoplay && g.xe(this.w.element, this.A.element) && g.kL(this.o, this.A.element, 7)
    };
    g.ML.embed = Q4;
})(_yt_player);